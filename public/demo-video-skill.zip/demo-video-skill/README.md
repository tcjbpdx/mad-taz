# Demo Video: a Claude skill that makes a demo video of your web app

You tell Claude **"Make a demo video of my app"**, and you get a narrated video of your own app.
It shows your real screens, with a camera that moves in on what matters, a pointer that clicks
your buttons, captions, and a title and end card in your colours.

You stay in charge of the words: **nothing is recorded until you approve the script.**

**How long it takes:** the first time, allow about an hour. That covers installing things, a
one-time download, a few questions, and reading the script. After that, a new video takes about
fifteen minutes, and most of that is you reading and approving the words.

What you get each time:

- **A video file** (MP4, 1920×1080, the size YouTube, LinkedIn and most websites want)
- **Captions**, shown in the video and also as a separate captions file for sites that take one
- **A poster picture** for the thumbnail
- **A contact sheet**: one picture every few seconds, so you can check the whole video at a glance
- **A short report** saying what was checked

Every new version is saved next to the last one (cut 1, cut 2, …). Nothing is ever overwritten.

---

## Two words used below

- **The skill folder** is the folder called `demo-video` inside the download. It holds the
  instructions Claude follows. It goes *inside* your project, tucked away in a hidden folder.
- **Your video folder** is a new folder Claude makes at the top of your project, also called
  `demo-video`. It holds your settings, your script and your finished videos.

They share a name, but you never need to touch the skill folder after you've put it in place.

## Opening Claude Code in a folder

You'll need this a few times, so here it is once.

- **In the Terminal:** type `cd` and a space, drag the folder from Finder onto the Terminal
  window, and press Return. Then type `claude` and press Return.
- **In the Claude desktop app or VS Code:** choose the folder when you start a new Claude Code
  session (in VS Code: *File → Open Folder*).
- **Starting fresh**, so Claude notices something new: in the Terminal, type `/exit` and press
  Return, then type `claude` and press Return. Anywhere else, close the session and start a new
  one in the same folder.

Not sure you're in the right place? Ask Claude: *"What folder are we in? Is my app here?"*

---

## What you need first

1. **A Mac.** It doesn't work on Windows yet.
2. **Claude Code**, opened in your app's project folder (the one you normally work on your app in).
3. **Node**, the free program the tools run on. If your app runs on your computer, you almost
   certainly have it already. Ask Claude: *"Do I have Node installed?"* If not:
   - go to **nodejs.org** and click **Download**, then choose the **macOS Installer**
   - open the file from your **Downloads** folder and click **Continue** through each screen
   - it asks for your **Mac's own password**. That's normal: it's your Mac asking, not a website.
   - then start Claude Code fresh (see above)
4. **Your app's address.** If it runs on your computer, Claude finds the address and starts the
   app for you when it's needed. If it's online, have its web address ready.
5. **A test account in your app, with tidy, made-up data.** This matters most. A robot browser
   really signs in and really clicks around. Anything in that account can end up in the video.
   - **To make one:** sign up to your own app again with a second email. If you use Gmail, an
     address like *yourname+demo@gmail.com* works and lands in your normal inbox. Then add a few
     made-up items so the screens look lived-in. Claude can help you think of some.
   - **Use a simple password** of just letters and numbers.
   - **Never use your real account** or anything with real customers' details. This matters even
     more if your app is live on the internet: the robot really changes whatever it clicks.
     It refuses delete, pay, send and similar buttons, but it can't know every app.

**The one-time download:** the first time, Claude downloads about **300 MB**: helpers that go
into the skill folder, and a private, hidden web browser that goes in a shared folder on your
Mac. It takes a few minutes and about 650 MB of disk space. If your project is on your Desktop or
in Documents (which often sync to iCloud without you noticing) or in Google Drive, the helpers
and your videos will sync there too.

---

## Voices and cost

Claude asks which voice you want, so here's the difference:

- **The Mac voice is free.** It's built into your Mac and works straight away. It sounds clear
  but a little robotic. Good for practising.
  - **It's only for practice and private videos.** Apple's licence allows its built-in voices
    for personal, non-commercial use, so they can't go in a video you publish, share publicly
    or use for a business. Each video's report reminds you.
- **A Google voice is much more natural,** and you can describe the style you want ("warm and
  unhurried"). It needs your own **key**, a secret code like a password, from Google AI Studio
  (aistudio.google.com → *Get API key*).
  - Google may ask you to pick a project or add a card before the voice works.
  - It should cost pennies per video, and only changed lines are re-recorded. Your AI Studio page
    shows what you've used.
  - Claude opens a private file for you to paste the key into. **Paste it there, never into
    the chat.**

The rest runs on your Mac for free, apart from your usual Claude plan.

**Not sure? Practise with the Mac voice, then switch to a Google voice for the video you
post.** Only the voice changes; the script and pictures stay the same.

---

## Put the skill in your project

1. If you downloaded a **.zip** file, double-click it in Downloads to unzip it first. You'll get
   a folder called `demo-video-skill`.
2. Open Claude Code in your app's project folder and say this. If you didn't leave the
   download in Downloads, change *"my Downloads folder"* to where you put it.

   > Copy the demo-video skill folder from the demo-video-skill folder in my Downloads folder
   > into this project's .claude/skills folder.

3. **Start Claude Code fresh**, so it notices the new skill (see *Opening Claude Code in a
   folder* above).
4. **Check it worked.** Ask Claude: *"Do you have the demo-video skill?"* It should say yes.
   If it says no, ask it to check the skill folder is at `.claude/skills/demo-video` in this
   project, then start fresh again.

(By hand instead: only if your project already has a `.claude` folder. In Finder, press **Cmd,
Shift and the full-stop key** together to show hidden folders, open `.claude`, make a `skills`
folder inside it, and **hold Option while you drag** the `demo-video` folder in, so it's copied
rather than moved. Finder won't let you make the `.claude` folder yourself, so if it's missing,
use the steps above.)

---

## Try it on the practice app first (optional, about 15 minutes)

The download has a tiny made-up plant-care app called **Fernhouse**, with its settings and an
approved script already filled in, so you can watch the whole thing work before it touches your
own app.

1. Ask Claude, in your usual project: *"Make a new empty folder called fernhouse-practice in my
   home folder."*
2. Open Claude Code in that new folder (see above) and say:

   > Set up the Fernhouse practice example here, from the demo-video-skill folder in my
   > Downloads folder: copy example/sample-app and example/demo-video into this folder, rename
   > demo-video/private.env.example to private.env, and copy the demo-video skill folder into
   > .claude/skills.

3. Start Claude Code fresh, then say: *"Start the Fernhouse app, then make its demo video."*

The practice script is already approved, so it goes straight to making the video.

---

## Make your first video

In your app's project, say to Claude:

> Make a demo video of my app.

Claude asks before it runs each step. The steps all start with
`node .claude/skills/demo-video/scripts/demo.mjs`, and those are safe to allow.

Here's what happens:

1. **Claude checks your setup** and fixes or explains anything missing, one thing at a time.
2. **It asks a few questions** with pop-up choices: what the video is for, what to show off, how
   long, which voice. It fills in your settings for you.
3. **It asks for your test account** by opening a small private file in TextEdit. It looks like
   this:
   ```
   APP_TEST_EMAIL=
   APP_TEST_PASSWORD=
   ```
   Type the email straight after the first `=` and the password straight after the second, with
   no spaces. Press **Cmd+S** to save, close the window, and tell Claude *"saved"*.
   **Claude never reads that file. Never paste a password into the chat.**
4. **It looks around your app** with the hidden browser, so the script uses your real button names.
5. **It writes the script** and opens a **storyboard** in your web browser: every scene with its
   picture, its words and how long it will take.
6. **You read it.** Tell Claude anything you'd change, in your own words. When every line sounds
   right, tell Claude **"approved"**.
7. **It records the narration, films the video and checks it.** Usually a minute or two of
   waiting on a recent Mac. An older Mac takes a few minutes.
8. **It opens the video for you.** Tell Claude what you'd change, and it makes the next cut.
   Only lines whose words changed get re-recorded.

Your finished videos are in your video folder, under `output`: `cut-01`, then `cut-02`, and so
on. Ask Claude *"Show me my latest demo video"* any time.

---

## Keep your private details private

Your video folder holds a private file (your test password and any voice key) and, if you signed
in by hand, a saved sign-in. Both stay on your Mac. Claude keeps them out of the copies it saves
of your project's history.

**Don't zip up, share or upload your whole project folder** while they're in it. To share a
video, share just the video file from the cut folder.

---

## What it can't do (yet)

- **"Sign in with Google / Apple", text-message codes and captchas** can't be typed by the robot.
  Instead, a browser window opens and you sign in once yourself; it's remembered.
- **Phone apps from the App Store** aren't covered. It films web apps. (It can show your web app
  at phone size, in a phone outline.)
- **Live motion** (scrolling, typing, animations) isn't filmed. The video is made from still
  pictures of your screens, with smooth camera moves and a pointer over them.
- **Dates and numbers** show whatever is in the test account on the day.
- **Mac only.** Windows isn't built.

---

## If something goes wrong

- **Tell Claude what you see.** Every step explains problems in plain words and names the one
  thing to fix. To see the checks yourself, ask Claude to *"run the demo video doctor"*.
- **Claude doesn't seem to know about the skill:** ask *"Do you have the demo-video skill?"*.
  If not, go back to *Put the skill in your project*.
- **You stopped halfway,** or closed Claude Code: open it in your project again and say
  *"Carry on with my demo video."* Your settings, script and recordings are all kept.
- **Your app stopped** after you restarted Claude Code: ask Claude to start it again.

## Tell us how it went

After your first video, ask Claude *"Help me fill in the demo video feedback form"*. It asks a
few short questions (what was confusing, what broke, what you wished it did) and saves your
answers in your video folder. Send that file back to whoever gave you this skill. It decides
what goes into version 2.

---

## What's in this folder

```
README.md      this guide
demo-video/    THE SKILL FOLDER: the one that goes into your project
example/       Fernhouse, the practice app, with its settings and an approved script
```

Inside the skill folder, `SKILL.md` is the step-by-step that Claude follows and `FEEDBACK.md`
is the feedback form. You never need to open the rest.
