# Feedback: Demo Video skill, version 1

Thank you for trying it. Fill in whatever you can after your first video. Short answers are
perfect. Anything you write here decides what changes in version 2.

**The easy way:** ask Claude *"Help me fill in the demo video feedback form"*. It asks you the
questions a few at a time and saves your answers as `feedback.md` in your video folder.

When it's done, send that file back to whoever gave you this skill.

---

**Date:**

**What your app is (one line):**

**How long the whole thing took, start to finished video (roughly):**

## Getting set up

1. Installing Node: did it go smoothly? (Skip if you already had it.)

2. Putting the skill in your project: did Claude find it straight away?

3. The test account and the private file: was it clear what to type, and where?

4. Was any other step confusing, or did Claude ask you something you didn't know how to answer?

## The script and storyboard

5. Did the first script sound like your app? What did you change?

6. Was the storyboard page useful for checking the words? Anything missing from it?

7. Was it clear how to approve the script?

## The video

8. How did the finished video look, out of 10? What looked off?

9. Which voice did you use? Did it say anything wrong (a name, a word)?

10. Did the pointer and camera land on the right things?

11. Was anything in the video you didn't want shown (private details, an error, an empty screen)?

12. How many cuts did it take to get one you'd post?

## Wishes

13. What do you wish it did that it doesn't?

14. If you could change one thing, what would it be?

15. Would you use it again for your next video? Why or why not?

---

**If something broke**, paste the message Claude showed you here. Before you send it, check it
doesn't show your email address, a password, or a long string of random letters and numbers
(that could be a key). Delete any you find.

```

```
