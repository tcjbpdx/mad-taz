// The private file: values are read by name, placeholders count as empty, nothing private is
// ever printed, and the file is refused when git could share it.

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { mkdirSync, mkdtempSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { SKILL_DIR } from '../scripts/lib/project.mjs'
import { isPlaceholder, loadPrivateEnv, looksLikeSecret, neverShowWords, PRIVATE_LINES, privateFileProtection, redact, secret, tightenPrivateFile, whichIsSet, writePrivateLine } from '../scripts/lib/secrets.mjs'

// Built from pieces so this file itself never holds anything key-shaped.
const FAKE_GOOGLE = 'AIza' + 'Sy' + 'A'.repeat(33)
const FAKE_STRIPE = 'sk_' + 'live_' + 'b'.repeat(24)

function privateFile(text) {
  const dir = mkdtempSync(join(tmpdir(), 'dv-private-'))
  const file = join(dir, 'private.env')
  writeFileSync(file, text)
  return { dir, file }
}

test('values are read by name; quotes, comments and placeholders are handled', () => {
  delete process.env.APP_TEST_EMAIL
  delete process.env.GOOGLE_VOICE_KEY
  delete process.env.GEMINI_API_KEY
  const { file } = privateFile([
    '# a comment',
    'APP_TEST_EMAIL = sam@example.com   # the test account',
    'APP_TEST_PASSWORD="a pass # with a hash"',
    'GOOGLE_VOICE_KEY=paste your key here',
    'export OTHER=1',
    'not a line',
  ].join('\n'))
  const v = loadPrivateEnv(file)
  assert.equal(v.APP_TEST_EMAIL, 'sam@example.com')
  assert.equal(v.APP_TEST_PASSWORD, 'a pass # with a hash')
  assert.equal(v.GOOGLE_VOICE_KEY, '', '"paste…" counts as empty')
  assert.equal(v.OTHER, '1')
  assert.equal(secret('APP_TEST_EMAIL'), 'sam@example.com')
  assert.equal(whichIsSet(['GOOGLE_VOICE_KEY', 'GEMINI_API_KEY']), null)
})

test('the shell environment wins over the file, and either key name works', () => {
  const { file } = privateFile('GOOGLE_VOICE_KEY=\n')
  loadPrivateEnv(file)
  process.env.GEMINI_API_KEY = FAKE_GOOGLE
  try {
    assert.equal(whichIsSet(['GOOGLE_VOICE_KEY', 'GEMINI_API_KEY']), 'GEMINI_API_KEY')
    assert.equal(secret(['GOOGLE_VOICE_KEY', 'GEMINI_API_KEY']), FAKE_GOOGLE)
    assert.ok(!redact(`key is ${FAKE_GOOGLE}`).includes(FAKE_GOOGLE), 'a value from the shell is hidden too')
  } finally {
    delete process.env.GEMINI_API_KEY
  }
})

test('private never-show words join the settings list and are hidden from everything printed', () => {
  delete process.env.NEVER_SHOW
  const { file } = privateFile('NEVER_SHOW = jane.doe@example.com, Doeberg ,\n')
  loadPrivateEnv(file)
  assert.deepEqual(neverShowWords({ never_show: ['Lorem ipsum'] }), ['Lorem ipsum', 'jane.doe@example.com', 'Doeberg'])
  const out = redact('"jane.doe@example.com" is on your never_show list, and so is Doeberg')
  assert.ok(!out.includes('jane.doe@example.com') && !out.includes('Doeberg'), out)
  assert.match(out, /\[NEVER_SHOW_1\]/)

  loadPrivateEnv(privateFile('NEVER_SHOW=\n').file)
  assert.deepEqual(neverShowWords({ never_show: [] }), [], 'an empty line adds nothing')
  assert.deepEqual(neverShowWords(null), [])
})

// A password with everything that breaks a hand-written sed line: & | / \ $ quotes and " #".
const AWKWARD = `p&a|s/s\\w$1'o"r d #x`

test('set-private: one line is written without the file being read back to anyone', () => {
  const { file } = privateFile('# keep me\nAPP_TEST_EMAIL=sam@example.com\nAPP_TEST_PASSWORD=\nGOOGLE_VOICE_KEY=\n')
  execFileSync('chmod', ['644', file])
  assert.equal(writePrivateLine(file, 'APP_TEST_PASSWORD', `${AWKWARD}\n`), 'replaced')
  assert.equal(loadPrivateEnv(file).APP_TEST_PASSWORD, AWKWARD, 'reads back exactly, trailing newline dropped')
  const text = readFileSync(file, 'utf8')
  assert.match(text, /^# keep me\nAPP_TEST_EMAIL=sam@example\.com\n/, 'the other lines are untouched')
  assert.equal(statSync(file).mode & 0o777, 0o600, 'only its owner can read it')

  assert.equal(writePrivateLine(file, 'NEVER_SHOW', 'Doeberg'), 'added')
  assert.equal(loadPrivateEnv(file).NEVER_SHOW, 'Doeberg')
  assert.equal(writePrivateLine(file, 'APP_TEST_PASSWORD', 'plain'), 'replaced')
  assert.equal(readFileSync(file, 'utf8').match(/APP_TEST_PASSWORD/g).length, 1, 'replaced, not added twice')

  assert.throws(() => writePrivateLine(file, 'APP_TEST_PASWORD', 'x'), /not a line the private file uses/)
  assert.throws(() => writePrivateLine(file, 'APP_TEST_PASSWORD', 'two\nlines'), /more than one line/)
  assert.throws(() => writePrivateLine(join(tmpdir(), 'no-such-dir-dv', 'private.env'), 'APP_TEST_PASSWORD', 'x'), /no private file yet/)
  for (const n of ['APP_TEST_EMAIL', 'APP_TEST_PASSWORD', 'GOOGLE_VOICE_KEY', 'NEVER_SHOW']) assert.ok(PRIVATE_LINES.includes(n), n)
})

test('set-private through the real command: piped in, written, never printed', () => {
  const project = mkdtempSync(join(tmpdir(), 'dv-setprivate-'))
  mkdirSync(join(project, 'demo-video'))
  const file = join(project, 'demo-video', 'private.env')
  writeFileSync(file, 'APP_TEST_PASSWORD=\n')
  const demo = join(SKILL_DIR, 'scripts', 'demo.mjs')
  const r = spawnSync(process.execPath, [demo, 'set-private', 'app_test_password', '--project', project], { input: `${AWKWARD}\n`, encoding: 'utf8' })
  assert.equal(r.status, 0, r.stderr)
  assert.match(r.stdout, /Replaced the APP_TEST_PASSWORD line/)
  for (const out of [r.stdout, r.stderr]) assert.ok(!out.includes('s/s') && !out.includes('o"r d'), 'no part of the value is printed')
  assert.equal(loadPrivateEnv(file).APP_TEST_PASSWORD, AWKWARD)

  const empty = spawnSync(process.execPath, [demo, 'set-private', 'APP_TEST_PASSWORD', '--project', project], { input: '', encoding: 'utf8' })
  assert.equal(empty.status, 1)
  assert.match(empty.stderr, /Nothing was piped in/)
  assert.equal(loadPrivateEnv(file).APP_TEST_PASSWORD, AWKWARD, 'an empty pipe leaves the line alone')
})

test('placeholders', () => {
  for (const v of ['', 'paste it here', 'your-key', 'put_key_here', 'xxxx', 'changeme', '<key>', '...']) assert.ok(isPlaceholder(v), v)
  for (const v of ['hunter2', 'sam@example.com', 'abc']) assert.ok(!isPlaceholder(v), v)
})

test('redact hides every private value and anything shaped like a key', () => {
  const { file } = privateFile('APP_TEST_PASSWORD=water-the-ferns\nAPP_TEST_EMAIL=sam@example.com\n')
  loadPrivateEnv(file)
  const out = redact(`Signed in as sam@example.com with water-the-ferns; ${FAKE_GOOGLE} ${FAKE_STRIPE} https://x.example/?access_token=abc.def&y=1 password: "zzz"`)
  assert.ok(!out.includes('water-the-ferns'))
  assert.ok(!out.includes('sam@example.com'))
  assert.ok(out.includes('[APP_TEST_PASSWORD]') && out.includes('[APP_TEST_EMAIL]'))
  assert.ok(!out.includes(FAKE_GOOGLE) && !out.includes(FAKE_STRIPE))
  assert.ok(!out.includes('abc.def'), 'tokens in links are hidden')
  assert.ok(!out.includes('zzz'), 'password fields are hidden')
  assert.equal(redact('nothing private here'), 'nothing private here')
})

test('key-shaped strings are recognised; ordinary settings are not', () => {
  assert.ok(looksLikeSecret(FAKE_GOOGLE))
  assert.ok(looksLikeSecret(FAKE_STRIPE))
  assert.ok(looksLikeSecret('a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8'), 'a long run of letters and digits')
  for (const v of ['http://localhost:3000', 'Warm, friendly and unhurried.', '#2E7D5B', 'logo.svg', 'Plant care without the guesswork', '']) {
    assert.ok(!looksLikeSecret(v), v)
  }
})

test('the private file is tightened so only its owner can read it', () => {
  const { file } = privateFile('APP_TEST_PASSWORD=x\n')
  execFileSync('chmod', ['644', file])
  assert.equal(tightenPrivateFile(file), true)
  assert.equal(statSync(file).mode & 0o777, 0o600)
  assert.equal(tightenPrivateFile(file), false, 'already tight: nothing to do')
})

test('git protection: refused when not ignored or already added, fine when ignored or not under git', () => {
  const git = (dir, ...args) => execFileSync('git', args, { cwd: dir, stdio: 'ignore' })

  const plain = privateFile('X=1\n')
  assert.equal(privateFileProtection(plain.file, plain.dir).ok, true, 'a folder not under git is fine')

  const open = privateFile('X=1\n')
  git(open.dir, 'init', '-q')
  const r1 = privateFileProtection(open.file, open.dir)
  assert.equal(r1.ok, false)
  assert.match(r1.why, /not on the project's ignore list/)

  writeFileSync(join(open.dir, '.gitignore'), 'private.env\n')
  assert.equal(privateFileProtection(open.file, open.dir).ok, true, 'ignored and never added')

  git(open.dir, 'add', '-f', 'private.env')
  const r2 = privateFileProtection(open.file, open.dir)
  assert.equal(r2.ok, false, 'ignored now, but already added: it would still be shared')
  assert.match(r2.why, /already been added to git/)
})
