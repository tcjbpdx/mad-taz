// The small parts: the command line, cut folders, the "new" step, the risky-button rule, the
// never_show search, the check readers, the Google voice's request and answers, sound files,
// the report, and the skill file itself.

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { EXIT, nextCutDir, parseArgs, pathsFor, shown, SKILL_DIR, suggest } from '../scripts/lib/project.mjs'
import { IGNORE_LINES, missingIgnoreLines, newProject } from '../scripts/lib/newproject.mjs'
import { fileSlug, latestCut, reportMarkdown } from '../scripts/lib/make.mjs'
import { isRisky } from '../scripts/lib/browser.mjs'
import { neverShowHits, textSources } from '../scripts/lib/capture.mjs'
import { parseSpans } from '../scripts/lib/checks.mjs'
import { googleRefusal, rateFromMime, readTtsAudio, ttsRequest } from '../scripts/lib/voices/google.mjs'
import { pcmToWav, readWav, seconds, trimSilence, writeWav } from '../scripts/lib/wav.mjs'
import { appAnswers, checkNode, doctorStop } from '../scripts/lib/doctor.mjs'
import { spokenParts } from '../scripts/lib/narrate.mjs'
import { stripNotes } from '../scripts/lib/speech.mjs'
import { parseScript } from '../scripts/lib/script.mjs'
import { estimate, starterLeftovers, storyboardHtml } from '../scripts/lib/storyboard.mjs'

const tmp = (name) => mkdtempSync(join(tmpdir(), `dv-${name}-`))

test('the command line: steps, --flag value, --flag=value, and bare flags', () => {
  assert.deepEqual(parseArgs(['storyboard', '--scene', '3', '--no-open']), { words: ['storyboard'], flags: { scene: '3', 'no-open': true } })
  assert.deepEqual(parseArgs(['look', '--pages=5', '--start', '/home']), { words: ['look'], flags: { pages: '5', start: '/home' } })
  assert.deepEqual(parseArgs(['doctor', '--voice-test', 'extra']), { words: ['doctor', 'extra'], flags: { 'voice-test': true } }, 'only known flags take a value')
  assert.deepEqual(EXIT, { ok: 0, error: 1, needsYou: 2, checkFailed: 3 })
})

test('typos get a suggestion, nonsense does not', () => {
  assert.equal(suggest('stroyboard', ['storyboard', 'make', 'look']), 'storyboard')
  assert.equal(suggest('banana', ['storyboard', 'make', 'look']), null)
})

test('cut folders count up and are never reused', () => {
  const out = tmp('cuts')
  assert.match(nextCutDir(out), /cut-01$/)
  mkdirSync(join(out, 'cut-01'))
  mkdirSync(join(out, 'cut-07'))
  mkdirSync(join(out, 'cut-x'))
  assert.match(nextCutDir(out), /cut-08$/)
  assert.match(nextCutDir(join(out, 'missing')), /cut-01$/)
})

test('the newest cut is the highest one with a report', () => {
  const project = tmp('latest')
  const paths = pathsFor(project)
  assert.equal(latestCut(paths), null)
  for (const n of ['01', '02', '03']) mkdirSync(join(paths.output, `cut-${n}`), { recursive: true })
  writeFileSync(join(paths.output, 'cut-01', 'report.json'), '{}')
  writeFileSync(join(paths.output, 'cut-02', 'report.json'), '{}')
  assert.match(latestCut(paths), /cut-02$/, 'cut-03 has no report yet (it failed half way)')
  assert.match(latestCut(paths, 1), /cut-01$/)
  assert.equal(latestCut(paths, 3), null)
})

test('paths are shown relative to the project', () => {
  assert.equal(shown('/a/project/demo-video/output', '/a/project'), 'demo-video/output')
  assert.equal(shown('/somewhere/else/file.mp4', '/a/project'), 'file.mp4')
})

test('video file names', () => {
  assert.equal(fileSlug('Fern House!'), 'fern-house')
  assert.equal(fileSlug('Café Ünïcode'), 'cafe-unicode')
  assert.equal(fileSlug('   '), 'app')
  assert.ok(fileSlug('x'.repeat(100)).length <= 40)
})

test('the ignore list: what is missing, in any spelling', () => {
  assert.deepEqual(missingIgnoreLines(''), IGNORE_LINES)
  assert.deepEqual(missingIgnoreLines('/demo-video/private.env\ndemo-video/output\n'), ['.claude/skills/demo-video/node_modules/'])
  assert.deepEqual(missingIgnoreLines(IGNORE_LINES.join('\n')), [])
})

test('the "new" step makes the folder once, never overwrites, and protects the private file', () => {
  const project = tmp('new')
  writeFileSync(join(project, '.gitignore'), 'node_modules') // no newline at the end on purpose
  const paths = pathsFor(project)
  const first = newProject(paths)
  assert.equal(first.made.length, 3)
  assert.equal(first.ignore, 'added')
  assert.equal(statSync(paths.privateEnv).mode & 0o777, 0o600)
  const gi = readFileSync(join(project, '.gitignore'), 'utf8')
  assert.ok(gi.startsWith('node_modules\n'), 'the existing last line is not run into')
  for (const l of IGNORE_LINES) assert.ok(gi.includes(`\n${l}\n`), l)

  writeFileSync(paths.script, 'MY OWN SCRIPT')
  const again = newProject(paths)
  assert.equal(again.made.length, 0)
  assert.equal(again.kept.length, 3)
  assert.equal(again.ignore, 'already')
  assert.equal(readFileSync(paths.script, 'utf8'), 'MY OWN SCRIPT')
  assert.equal(readFileSync(join(project, '.gitignore'), 'utf8'), gi, 'the ignore lines are added once')
})

test('the "new" step makes a .gitignore when there is none', () => {
  const project = tmp('new2')
  newProject(pathsFor(project))
  assert.equal(readFileSync(join(project, '.gitignore'), 'utf8').split('\n')[0], '# Demo video: private details and big files stay off git')
})

test('risky buttons are never clicked unless named in ok_to_click', () => {
  const settings = { safety: { ok_to_click: ['Send invoice'] } }
  for (const t of ['Delete plant', 'Pay now', 'Sign out', 'Log out', 'Invite people', 'Checkout', 'Remove', 'Cancel my subscription', 'Share']) assert.ok(isRisky(t, settings), t)
  for (const t of ['Water now', 'Search plants', 'Postcode', 'Sending times', 'Send invoice', 'Cancel']) assert.ok(!isRisky(t, settings), t)
})

test('never_show words are found in the pictures, the words and the cards, in any case', () => {
  const settings = { app_name: 'Sample', tagline: 'Made by Jo Example', look: { end_card: '' } }
  const script = parseScript('# T\n## Title card\nSay: Hello.\n## 1. One\nShow: /\nSay: Signed in as JO@example.com [not shown].\n')
  const sources = textSources({ settings, script, cap: { texts: { 'scene-1-after': 'jo@example.com saved' } }, spokenParts, stripNotes })
  assert.deepEqual(Object.keys(sources), ['the picture for scene 1 (after the click)', "the title card's words", "scene 1's words", 'the title and end cards'])
  const hits = neverShowHits(['jo@example.com', 'jo example', ''], sources)
  assert.deepEqual(hits.map((h) => `${h.word} @ ${h.where}`), [
    'jo@example.com @ the picture for scene 1 (after the click)',
    "jo@example.com @ scene 1's words",
    'jo example @ the title and end cards',
  ])
})

test('the check readers turn the video maker\'s notes into stretches', () => {
  const black = '[blackdetect @ 0x1] black_start:4.0333 black_end:7 black_duration:2.9667\n[blackdetect @ 0x1] black_start:11.9 black_end:12 black_duration:0.1'
  assert.deepEqual(parseSpans(black, 'black'), [{ from: 4.0333, to: 7 }, { from: 11.9, to: 12 }])
  const freeze = '[freezedetect @ 0x2] lavfi.freezedetect.freeze_start: 1.5\n[freezedetect @ 0x2] lavfi.freezedetect.freeze_duration: 10.5\n[freezedetect @ 0x2] lavfi.freezedetect.freeze_end: 12'
  assert.deepEqual(parseSpans(freeze, 'freeze'), [{ from: 1.5, to: 12 }])
  const silence = '[silencedetect @ 0x3] silence_start: -0.02\n[silencedetect @ 0x3] silence_end: 9.5 | silence_duration: 9.52\n[silencedetect @ 0x3] silence_start: 40'
  assert.deepEqual(parseSpans(silence, 'silence'), [{ from: 0, to: 9.5 }, { from: 40, to: null }], 'a silence that runs to the end stays open')
  assert.deepEqual(parseSpans('', 'black'), [])
})

test('the Google voice request carries the words, the voice and the style', () => {
  const r = ttsRequest({ model: ' some-tts-model ', voice: 'Kore', text: 'Hello.', style: 'Warm.' })
  assert.equal(r.model, 'some-tts-model')
  assert.deepEqual(r.input[0].content[0], { type: 'text', text: 'Hello.', annotations: [{ type: 'speech_metadata', style: 'Warm.' }] })
  assert.deepEqual(r.generation_config, { speech_config: [{ voice: 'Kore' }] })
  assert.equal(ttsRequest({ model: 'm', voice: 'v', text: 'x', style: '' }).input[0].content[0].annotations, undefined, 'no style, no annotation')
})

test('the Google voice answers: sound, no sound, and each kind of refusal in plain words', () => {
  const ok = { steps: [{ type: 'thought' }, { type: 'model_output', content: [{ type: 'audio', data: 'AAAA', mime_type: 'audio/L16;rate=24000', sample_rate: 24000 }] }] }
  assert.deepEqual(readTtsAudio(ok), { base64: 'AAAA', mime: 'audio/L16;rate=24000', sampleRate: 24000 })
  assert.deepEqual(readTtsAudio({ interaction: ok }).base64, 'AAAA', 'the answer may be wrapped')
  assert.match(readTtsAudio({ steps: [] }).error, /sent no sound back/)
  const refusal = (message, status = '') => googleRefusal({ error: { message, status } })
  assert.match(refusal('API key not valid. Please pass a valid API key.'), /refused the voice key/)
  assert.match(refusal('Quota exceeded for requests per day'), /used up today's allowance/)
  assert.match(refusal('Too many', 'RESOURCE_EXHAUSTED'), /busy/)
  assert.match(refusal('models/x is not found for API version v1beta'), /does not know that voice model/)
  const fake = 'AIza' + 'Sy' + 'Q'.repeat(33)
  assert.ok(!refusal(`Something odd about ${fake} at https://example.com/x`).includes(fake), 'Google\'s own message is shown with keys hidden')
  assert.equal(googleRefusal({}), '')
  assert.equal(rateFromMime('audio/L16;codec=pcm;rate=44100'), 44100)
  assert.equal(rateFromMime('audio/wav'), 24000)
})

test('sound files: written, read back, and trimmed of quiet ends', () => {
  const dir = tmp('wav')
  const rate = 24000
  const samples = new Int16Array(rate) // 1 s: quiet, a tone in the middle, quiet
  for (let i = rate * 0.4; i < rate * 0.6; i++) samples[i] = Math.round(8000 * Math.sin(i / 5))
  const file = join(dir, 'a.wav')
  writeWav(file, { sampleRate: rate, samples })
  const back = readWav(file)
  assert.equal(back.sampleRate, rate)
  assert.equal(back.channels, 1)
  assert.equal(seconds(back), 1)
  const trimmed = trimSilence(back)
  assert.ok(seconds(trimmed) > 0.2 && seconds(trimmed) < 0.35, `trimmed to ${seconds(trimmed)} s`)
  assert.equal(pcmToWav(Buffer.alloc(4), 48000).readUInt32LE(24), 48000)
  writeFileSync(join(dir, 'bad.wav'), 'not a wav')
  assert.throws(() => readWav(join(dir, 'bad.wav')), /not a WAV file/)
})

test('the setup check: Node versions, the app answering, and the right kind of stop', async () => {
  assert.equal(checkNode('20.1.0').ok, true)
  assert.equal(checkNode('18.19.0').ok, false)
  assert.equal((await appAnswers('http://x', { fetchImpl: async () => ({ status: 500 }) })).ok, true, 'any reply counts, even an error page')
  const down = await appAnswers('http://x', { fetchImpl: async () => { throw new Error('ECONNREFUSED') } })
  assert.equal(down.ok, false)
  assert.match(down.why, /nothing is answering/)
  assert.equal(doctorStop({ say: 'A', fix: 'B', kind: 'needsYou' }).exitCode, 2)
  assert.equal(doctorStop({ say: 'A', fix: 'B', kind: 'error' }).exitCode, 1)
})

test('the report reads in plain words', () => {
  const r = {
    app: 'Sample', cut: 2, made: 'Jan 1, 2027, 9:00 AM', video: 'sample-demo.mp4', duration: 47.2, size: '1920×1080', bytes: 5 * 1048576,
    voice: 'Mac voice Samantha (free)', recorded: 1, reused: 5, renderSeconds: 75, usedCustomDirector: false,
    checks: { ok: true, failures: [], warnings: ['A small thing.'] },
    scenes: [{ n: 1, name: 'Welcome | intro', from: 2.4, to: 9 }],
  }
  const md = reportMarkdown(r)
  assert.match(md, /^# Sample demo: cut 2/)
  assert.match(md, /47\.2 s, 1920×1080, 5\.0 MB/)
  assert.match(md, /1 line recorded, 5 reused/)
  assert.match(md, /Time to make:\*\* 1 min 15 s/)
  assert.match(md, /✓ Every check passed/)
  assert.match(md, /Worth a look:\n\n- A small thing\./)
  assert.match(md, /\| 1 \| Welcome \/ intro \| 2\.4 s \| 9 s \|/, 'a | in a name cannot break the table')
  assert.ok(!md.includes('null'))
  const bad = reportMarkdown({ ...r, checks: { ok: false, failures: ['The picture is black.'], warnings: [] } })
  assert.match(bad, /✗ Some checks did not pass:\n\n- The picture is black\./)
})

test("a Mac-voice cut says Apple's licence keeps it to practice; a Google-voice cut doesn't", () => {
  const r = {
    app: 'Sample', cut: 1, made: 'Jan 1, 2027, 9:00 AM', video: 'sample-demo.mp4', duration: 30, size: '1920×1080', bytes: 1048576,
    recorded: 4, reused: 0, renderSeconds: 20, usedCustomDirector: false,
    checks: { ok: true, failures: [], warnings: [] }, scenes: [],
  }
  const mac = reportMarkdown({ ...r, voice: 'Mac voice Samantha (free)', macVoice: true })
  assert.match(mac, /Before you post it:\*\* the free Mac voice is for practice/)
  assert.match(mac, /Apple's licence/)
  const google = reportMarkdown({ ...r, voice: 'Google voice Algieba', macVoice: false })
  assert.ok(!/Before you post it|Apple's licence/.test(google))
})

test('SKILL.md has the name and description Claude needs to find it', () => {
  const text = readFileSync(join(SKILL_DIR, 'SKILL.md'), 'utf8')
  const fm = /^---\n([\s\S]*?)\n---\n/.exec(text)
  assert.ok(fm, 'it starts with a --- block')
  const name = /^name: (.+)$/m.exec(fm[1])
  const description = /^description: (.+)$/m.exec(fm[1])
  assert.equal(name && name[1], 'demo-video')
  assert.ok(description && /^Use when/.test(description[1]))
  assert.ok(description[1].length < 1024, 'descriptions over 1024 characters are cut off')
  for (const step of ['setup', 'new', 'doctor', 'look', 'storyboard', 'make', 'watch', 'set-private']) assert.ok(text.includes(`demo ${step}`), step)
  assert.ok(existsSync(join(SKILL_DIR, 'FEEDBACK.md')), 'the feedback form it points to travels with the skill')
})

test('every template the "new" step copies is there', () => {
  for (const f of ['settings.yaml', 'script.md', 'private.env.example']) assert.ok(existsSync(join(SKILL_DIR, 'templates', f)), f)
  assert.match(readFileSync(join(SKILL_DIR, 'templates', 'private.env.example'), 'utf8'), /^NEVER_SHOW=$/m, 'the private file has a line for private never-show words')
})

test('the untouched starter script is refused by the storyboard; a written one is not', () => {
  const starter = parseScript(readFileSync(join(SKILL_DIR, 'templates', 'script.md'), 'utf8'))
  const left = starterLeftovers(starter)
  assert.equal(left.length, 2, left.join('\n'))
  assert.match(left[0], /^The title card still has the blank starter's words/)
  assert.match(left[1], /^Scene 1 still has the blank starter's words/)

  const written = parseScript('# Demo script: T\nStatus: DRAFT\n\n## Title card\nSay: Meet Tally.\n\n## 1. Home\nShow: /\nSay: Every bill in one place.\n\n## End card\nSay: Try it today.\n')
  assert.deepEqual(starterLeftovers(written), [], 'the starter end line is a fine thing to keep')
})

test('the storyboard says when the camera will move in on the pointer\'s target', () => {
  const settings = { app_name: 'T', tagline: '', screen: 'desktop', video_length_seconds: 30, voice: { service: 'mac', name: 'Samantha' }, look: { accent_color: '#112233', end_card: '' }, say_it_like: {} }
  const page = (zoomLine) => {
    const script = parseScript(`# Demo script: T\nStatus: DRAFT\n\n## 1. Home\nShow: /\nPoint at: "Go" when I say "start"\n${zoomLine}Say: Press go to start.\n`)
    return storyboardHtml({ settings, script, cap: null, layout: estimate(script), problems: [], warnings: [] })
  }
  assert.match(page(''), /camera moves in on the pointer’s target/)
  assert.doesNotMatch(page('Zoom: none\n'), /camera moves in on the pointer’s target/)
  assert.doesNotMatch(page('Zoom: "Go"\n'), /camera moves in on the pointer’s target/)
})
