// The settings checks: a good file reads with sensible defaults, and every mistake is named in
// plain words: all of them in one go, never just the first.

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { pageUrl, parseSettings } from '../scripts/lib/settings.mjs'
import { SKILL_DIR } from '../scripts/lib/project.mjs'

const GOOD = `
app_name: Sample
tagline: The short line
app_url: http://localhost:3000/
screen: desktop
sign_in:
  method: form
  page: /login
  email_box: Email
  password_box: Password
  button: Sign in
  done_when_you_see: Dashboard
features_to_show:
  - One
  - Two
video_length_seconds: 45
voice:
  service: google
  style: Warm.
say_it_like:
  Sample: Sam-pull
look:
  accent_color: "#2E7D5B"
captions: no
never_show: someone@example.com
safety:
  block_saves: yes
  ok_to_click: Send
`

/** The list of problems a settings text gives (empty when it reads fine). */
async function problems(src) {
  try { await parseSettings(src); return [] } catch (e) { return e.problems || [e.message] }
}

test('a good settings file reads, with defaults filled in', async () => {
  const s = await parseSettings(GOOD)
  assert.equal(s.app_name, 'Sample')
  assert.equal(s.app_url, 'http://localhost:3000', 'the trailing slash is dropped')
  assert.equal(s.sign_in.method, 'form')
  assert.deepEqual(s.features_to_show, ['One', 'Two'])
  assert.equal(s.video_length_seconds, 45)
  assert.equal(s.voice.service, 'google')
  assert.equal(s.voice.name, 'Algieba', 'the Google voice has a default name')
  assert.ok(s.voice.model, 'and a default model')
  assert.deepEqual(s.say_it_like, { Sample: 'Sam-pull' })
  assert.equal(s.look.accent_color, '#2E7D5B')
  assert.equal(s.captions, false)
  assert.deepEqual(s.never_show, ['someone@example.com'], 'a single word becomes a list')
  assert.equal(s.safety.block_saves, true)
  assert.deepEqual(s.safety.ok_to_click, ['Send'])
  assert.equal(s.output_folder, 'output')
})

test('the smallest file that works: a name and an address', async () => {
  const s = await parseSettings('app_name: Tiny\napp_url: https://tiny.example\n')
  assert.equal(s.screen, 'desktop')
  assert.equal(s.sign_in.method, 'none')
  assert.equal(s.video_length_seconds, 60)
  assert.equal(s.voice.service, 'mac')
  assert.equal(s.voice.name, 'Samantha')
  assert.equal(s.captions, true)
  assert.equal(s.safety.block_saves, false)
})

test('every mistake is listed at once', async () => {
  const p = await problems('app_url: localhost:3000\nscreen: tablet\nvideo_length_seconds: 2000\n')
  assert.equal(p.length, 4, p.join('\n'))
  assert.ok(p.some((x) => /app_name is empty/.test(x)))
  assert.ok(p.some((x) => /is not a web address/.test(x)))
  assert.ok(p.some((x) => /screen should be desktop or phone/.test(x)))
  assert.ok(p.some((x) => /from 10 to 600/.test(x)))
})

test('each kind of mistake is named in plain words', async () => {
  const base = 'app_name: A\napp_url: http://localhost:3000\n'
  const cases = [
    [`${base}sign_in:\n  method: form\n`, /sign_in → page is empty, and it is needed when method is form/],
    [`${base}sign_in:\n  method: magic\n`, /method should be form, by-hand or none/],
    [`${base}sign_in:\n  method: by-hand\n`, /done_when_you_see is empty/],
    [`${base}voice:\n  service: alexa\n`, /service should be mac or google/],
    [`${base}look:\n  accent_color: green\n`, /accent_color should look like "#2E7D5B"/],
    [`${base}captions: maybe\n`, /captions should be yes or no/],
    [`${base}output_folder: ../elsewhere\n`, /output_folder should be a folder name inside demo-video/],
    [`${base}vioce:\n  name: Kore\n`, /vioce is not a setting I know \(did you mean voice\?\)/],
    [`${base}sign_in:\n  methd: none\n`, /sign_in → methd is not a setting I know \(did you mean method\?\)/],
    [`app_name: A\napp_url: http://me:pw@localhost:3000\n`, /must not hold a name or password/],
    [`${base}voice: Samantha\n`, /voice should be a group of settings/],
    [`${base}say_it_like:\n  - one\n`, /say_it_like should be lines of/],
  ]
  for (const [src, want] of cases) {
    const p = await problems(src)
    assert.ok(p.some((x) => want.test(x)), `expected ${want} in:\n${p.join('\n') || '(no problems)'}`)
  }
})

test('a colour without quote marks is caught, not silently lost', async () => {
  const p = await problems('app_name: A\napp_url: http://localhost:3000\nlook:\n  accent_color: #2E7D5B\n')
  assert.ok(p.some((x) => /needs quote marks/.test(x)), p.join('\n'))
})

test('passwords and keys are refused in the settings file', async () => {
  const base = 'app_name: A\napp_url: http://localhost:3000\n'
  const fakeKey = 'AIza' + 'Sy0fake0fake0fake0fake0fake0fake0fak'
  for (const src of [
    `${base}sign_in:\n  method: none\n  password: hunter2\n`,
    `${base}api_key: abc\n`,
    `${base}tagline: ${fakeKey}\n`,
  ]) {
    const p = await problems(src)
    assert.ok(p.some((x) => /go in private.env, never in settings.yaml/.test(x)), `${src}\n→ ${p.join('\n')}`)
  }
  // …but the names of the sign-in boxes are fine.
  assert.deepEqual(await problems(`${base}sign_in:\n  method: form\n  page: /login\n  email_box: Email\n  password_box: Password\n  button: Go\n  done_when_you_see: Home\n`), [])
})

test('a file YAML cannot read says where and why', async () => {
  const p = await problems('app_name: A\n  app_url: [oops\n')
  assert.match(p[0], /could not be read near line \d+\. Usually this is a missing space after a colon/)
})

test('page addresses: a path joins the app address, a whole address is kept', () => {
  const s = { app_url: 'http://localhost:3000' }
  assert.equal(pageUrl(s, '/plants'), 'http://localhost:3000/plants')
  assert.equal(pageUrl(s, 'plants'), 'http://localhost:3000/plants')
  assert.equal(pageUrl(s, ''), 'http://localhost:3000/')
  assert.equal(pageUrl(s, 'https://other.example/x'), 'https://other.example/x')
})

test('the blank template only asks for the app name', async () => {
  const p = await problems(readFileSync(join(SKILL_DIR, 'templates', 'settings.yaml'), 'utf8'))
  assert.equal(p.length, 1, p.join('\n'))
  assert.match(p[0], /app_name is empty/)
})

const EXAMPLE = join(SKILL_DIR, '..', 'example', 'demo-video', 'settings.yaml')
test('the Fernhouse example settings read cleanly', { skip: !existsSync(EXAMPLE) && 'the example folder is not beside the skill here' }, async () => {
  const s = await parseSettings(readFileSync(EXAMPLE, 'utf8'))
  assert.equal(s.app_name, 'Fernhouse')
  assert.equal(s.sign_in.method, 'form')
})
