// The timing maths: how long words take, where each word lands, how the scenes are laid out,
// the captions, the length verdict, and the plan the film page reads.

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseScript } from '../scripts/lib/script.mjs'
import { buildCaptions, captionPieces, displayWords, estimateSeconds, notesOf, spokenText, stripNotes, toSrt, wordTimes, WORDS_PER_MINUTE } from '../scripts/lib/speech.mjs'
import { directionFor, LAYOUT, layOut, spokenParts, timelineFrom } from '../scripts/lib/narrate.mjs'
import { estimate, lengthVerdict, sayHtml } from '../scripts/lib/storyboard.mjs'
import { planFor } from '../scripts/lib/filmpage.mjs'
import { secondsText } from '../scripts/lib/project.mjs'

const close = (a, b, msg) => assert.ok(Math.abs(a - b) < 1e-6, `${msg || ''} ${a} should be ${b}`)

const script = (title, end) => parseScript(`# Demo script: T
Status: APPROVED
${title === null ? '' : `## Title card\n${title ? `Say: ${title}` : ''}\n`}
## 1. One
Show: /
Say: First scene words here.

## 2. Two
Show: /two
Point at: "Go" when I say "second"
Say: The second scene, with a pointer.
${end === null ? '' : `## End card\n${end ? `Say: ${end}` : ''}\n`}`)

test('notes are found, stripped and never spoken', () => {
  assert.deepEqual(notesOf('Hello [warmly] there [ ] [slow down].'), ['warmly', 'slow down'])
  assert.equal(stripNotes('Hello [warmly] there , friend [pause].'), 'Hello there, friend.')
  assert.deepEqual(displayWords('One [beat] two.'), ['One', 'two.'])
})

test('say_it_like swaps whole words only, longest first, any case', () => {
  const like = { Fernhouse: 'Fern-house', 'Fernhouse Pro': 'Fern-house Pro', UI: 'you eye' }
  assert.equal(spokenText('Fernhouse Pro beats fernhouse. GUI? UI!', like), 'Fern-house Pro beats Fern-house. GUI? you eye!')
})

test('the length estimate is words at the measured pace plus a beat per sentence', () => {
  assert.equal(estimateSeconds(''), 0)
  const say = 'one two three four five six seven eight nine ten.'
  close(estimateSeconds(say), (10 / WORDS_PER_MINUTE) * 60 + 0.25)
})

test('word times run in order, inside the clip, longer words taking longer', () => {
  const w = wordTimes('A quick look, then a remarkably thorough demonstration.', 10, 14)
  assert.equal(w.length, 8)
  assert.equal(w[0].s, 10)
  close(w.at(-1).e, 14, 'the last word ends at the clip end')
  for (let i = 1; i < w.length; i++) assert.ok(w[i].s >= w[i - 1].e, 'no word starts before the last one ends')
  const dur = (x) => x.e - x.s
  assert.ok(dur(w[6]) > dur(w[0]), '"thorough" takes longer than "A"')
  assert.ok(w[3].s - w[2].e > 0, 'a comma leaves a pause')
})

test('a lone dash joins the word before it instead of getting its own time', () => {
  assert.deepEqual(wordTimes('Wait — then go', 0, 3).map((x) => x.text), ['Wait —', 'then', 'go'])
  assert.deepEqual(wordTimes('—', 0, 1), [])
})

test('captions: one sentence at a time, long ones split, never overlapping', () => {
  const words = wordTimes('Short one. This second sentence is quite a lot longer than the first, so it has to be split somewhere sensible near a comma or a gap.', 1, 13)
  const pieces = captionPieces(words)
  assert.equal(pieces[0].text, 'Short one.')
  for (const p of pieces) assert.ok(p.text.length <= 84, `"${p.text}" is too long for one caption`)
  const caps = buildCaptions([{ words }])
  for (let i = 1; i < caps.length; i++) assert.ok(caps[i].from >= caps[i - 1].to, 'captions never overlap')
  assert.ok(caps[0].from < words[0].s, 'a caption appears just before its first word')
})

test('captions file: numbered blocks with hours:minutes:seconds,milliseconds', () => {
  assert.equal(toSrt([{ text: 'Hi.', from: 0.5, to: 61.25 }, { text: 'Bye.', from: 3661, to: 3662.0004 }]),
    '1\n00:00:00,500 --> 00:01:01,250\nHi.\n\n2\n01:01:01,000 --> 01:01:02,000\nBye.\n')
})

test('layout: spoken title and end cards, scenes laid end to end with steady gaps', () => {
  const s = script('Meet T.', 'Try T.')
  const L = LAYOUT
  const lay = layOut(s, { title: 2, s1: 5, s2: 4, end: 2 })
  close(lay.clips.title.start, L.titleLead)
  close(lay.clips.s1.start, L.titleLead + 2 + L.gap)
  close(lay.clips.s2.start, lay.clips.s1.end + L.gap)
  close(lay.scenes[0].from, lay.clips.s1.start - L.shotLead, 'the picture arrives just before the words')
  close(lay.title.to, lay.scenes[0].from)
  close(lay.scenes[0].to, lay.scenes[1].from, 'scenes meet with no hole')
  close(lay.clips.end.start, lay.clips.s2.end + L.gap)
  close(lay.scenes[1].to, lay.end.from)
  close(lay.duration, lay.clips.end.end + L.spokenEndTail)
  close(lay.end.to, lay.duration)
})

test('layout: a silent title card holds, and no end card ends with a short tail', () => {
  const s = script('', null)
  assert.equal(s.endCard, null)
  const lay = layOut(s, { s1: 5, s2: 4 })
  close(lay.title.to, LAYOUT.silentTitle)
  close(lay.clips.s1.start, LAYOUT.silentTitle + LAYOUT.shotLead)
  assert.equal(lay.end, null)
  close(lay.duration, lay.clips.s2.end + LAYOUT.noEndTail)
})

test('layout: no title card starts on the first scene at once; a silent end card holds', () => {
  const lay = layOut(script(null, ''), { s1: 5, s2: 4 })
  assert.equal(lay.title, null)
  assert.equal(lay.scenes[0].from, 0)
  close(lay.clips.s1.start, LAYOUT.firstLead)
  close(lay.end.from, lay.clips.s2.end + LAYOUT.silentEndGap)
  close(lay.duration, lay.end.from + LAYOUT.silentEnd)
})

test('the parts that speak skip silent cards', () => {
  assert.deepEqual(spokenParts(script('Hi.', 'Bye.')).map((p) => p.id), ['title', 's1', 's2', 'end'])
  assert.deepEqual(spokenParts(script('', null)).map((p) => p.id), ['s1', 's2'])
})

test('the timeline puts every word inside its own clip', () => {
  const s = script('Meet T.', 'Try T.')
  const lay = layOut(s, { title: 2, s1: 5, s2: 4, end: 2 })
  const { lines } = timelineFrom(s, lay)
  assert.deepEqual(lines.map((l) => l.id), ['title', 's1', 's2', 'end'])
  for (const l of lines) {
    const c = lay.clips[l.id]
    assert.ok(l.start >= c.start && l.end <= c.end, `${l.id} stays inside its clip`)
  }
  assert.equal(lines[2].n, 2)
})

test('the storyboard estimate and the length verdict', () => {
  const lay = estimate(script('Meet T.', 'Try T.'))
  assert.ok(lay.duration > 5 && lay.duration < 20, `estimate ${lay.duration}`)
  assert.equal(lengthVerdict(61, 60).ok, true)
  assert.match(lengthVerdict(61, 60).text, /right around/)
  assert.equal(lengthVerdict(80, 60).ok, false)
  assert.match(lengthVerdict(80, 60).text, /20 s longer/)
  assert.equal(lengthVerdict(40, 60).ok, true, 'shorter is fine')
  assert.match(lengthVerdict(40, 60).text, /shorter/)
})

test('the storyboard marks the pointer phrase in the words and escapes the rest', () => {
  const html = sayHtml('Tap <b>here</b> to water it [warmly].', [{ phrase: 'to water', cls: 'aim' }])
  assert.ok(!html.includes('<b>'), 'words are escaped')
  assert.match(html, /class="aim"/)
})

test('the voice direction joins the style, the tone and the notes', () => {
  const settings = { voice: { style: 'Warm and calm.' } }
  assert.equal(directionFor(settings, { tone: 'brighter', say: 'Hi [smile] there.' }), 'Warm and calm. For this line: brighter. Notes: smile.')
  assert.equal(directionFor({ voice: { style: '' } }, { tone: '', say: 'Hi.' }), '')
})

test('the film plan: cards, scenes, pointer, zoom and captions', () => {
  const s = script('Meet T.', 'Try T.')
  const lay = layOut(s, { title: 2, s1: 5, s2: 4, end: 2 })
  const settings = { app_name: 'T', tagline: 'The tagline', screen: 'desktop', captions: true, look: { accent_color: '#112233', end_card: '' } }
  const cap = { scenes: [
    { id: 's1', stills: ['scene-1'], target: null, zoom: false },
    { id: 's2', stills: ['scene-2'], target: { box: [1, 2, 3, 4], scale: 1.5, phrase: 'second', click: false }, zoom: null },
  ] }
  const plan = planFor({ settings, script: s, cap, layout: lay, timeline: timelineFrom(s, lay), logoFile: '/x/My Logo.SVG' })
  assert.equal(plan.device, 'desk')
  assert.equal(plan.accent, '#112233')
  assert.equal(plan.duration, lay.duration)
  assert.deepEqual(plan.cards.map((c) => c.id), ['title', 'end'])
  assert.equal(plan.cards[1].line, 'The tagline', 'an empty end_card falls back to the tagline')
  assert.equal(plan.cards[0].logo, 'assets/logo.svg')
  assert.equal(plan.scenes[0].zoom, false)
  assert.deepEqual(plan.scenes[1].target, { box: [1, 2, 3, 4], scale: 1.5, phrase: 'second', click: false })
  assert.ok(plan.captions.length >= 4)
  assert.equal(plan.title, 'T')

  const noCaps = planFor({ settings: { ...settings, captions: false, screen: 'phone' }, script: s, cap, layout: lay, timeline: timelineFrom(s, lay), logoFile: null })
  assert.deepEqual(noCaps.captions, [])
  assert.equal(noCaps.device, 'phone')
  assert.equal(noCaps.cards[0].logo, null)

  assert.throws(() => planFor({ settings, script: s, cap: { scenes: [cap.scenes[0]] }, layout: lay, timeline: timelineFrom(s, lay) }), /Scene 2 has no picture/)
})

test('seconds read naturally, and never as "1 min 60 s"', () => {
  assert.equal(secondsText(7.44), '7.4 s')
  assert.equal(secondsText(59.96), '1 min 0 s')
  assert.equal(secondsText(72.4), '1 min 12 s')
  assert.equal(secondsText(119.7), '2 min 0 s')
  assert.equal(secondsText(NaN), '?')
})
