// The script reader: good scripts read cleanly, every kind of mistake is named with its line
// number, and nothing is recorded from a script that is not APPROVED.

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { allWords, loadScript, parseScript, parseSteps, phraseCount } from '../scripts/lib/script.mjs'
import { SKILL_DIR } from '../scripts/lib/project.mjs'

const GOOD = `# Demo script: Sample
Status: DRAFT

<!-- A note for the writer.
     It runs over two lines and is ignored. -->

## Title card
Say: Meet Sample.

## 1. Welcome
Show: /home
Point at: "Get started" when I say "one place"
Say: Everything you need, in one place.

## 2. Search
Show: /items
Do: click "Search", then type "fig" into "Search items", press "Enter"
Click: “Fiddle leaf fig” when I say “the fig”
Zoom: none
Tone: a little brighter
Say: Find anything fast. [smile]
  Type a word and the fig is right there.

## End card
Say: Try Sample today.
`

const problemsOf = (src) => parseScript(src).problems

test('a good script reads with no problems', () => {
  const s = parseScript(GOOD)
  assert.deepEqual(s.problems, [])
  assert.equal(s.title, 'Sample')
  assert.equal(s.status, 'DRAFT')
  assert.equal(s.approved, false)
  assert.equal(s.scenes.length, 2)
  assert.equal(s.titleCard.say, 'Meet Sample.')
  assert.equal(s.endCard.say, 'Try Sample today.')
})

test('scenes get their ids, pages, steps, pointer and zoom', () => {
  const [one, two] = parseScript(GOOD).scenes
  assert.equal(one.id, 's1')
  assert.equal(one.name, 'Welcome')
  assert.equal(one.show, '/home')
  assert.deepEqual(one.target, { text: 'Get started', phrase: 'one place', click: false, line: 12 })
  assert.equal(one.zoom, null)

  assert.equal(two.id, 's2')
  assert.deepEqual(two.steps.map((s) => s.kind), ['click', 'type', 'press'])
  assert.equal(two.steps[1].value, 'fig')
  assert.equal(two.steps[1].target, 'Search items')
  assert.equal(two.target.click, true)
  assert.equal(two.target.text, 'Fiddle leaf fig', 'curly quotes are straightened')
  assert.equal(two.zoom, false, 'Zoom: none keeps the camera still')
  assert.equal(two.tone, 'a little brighter')
})

test('a Say line can run on over the next lines, and [notes] are never spoken', () => {
  const two = parseScript(GOOD).scenes[1]
  assert.equal(two.say, 'Find anything fast. [smile] Type a word and the fig is right there.')
  assert.equal(two.spoken, 'Find anything fast. Type a word and the fig is right there.')
  assert.ok(!two.words.includes('[smile]'))
})

test('Status: APPROVED (any case) approves; anything else is a problem', () => {
  assert.equal(parseScript(GOOD.replace('Status: DRAFT', 'Status: approved')).approved, true)
  assert.equal(parseScript(GOOD.replace('Status: DRAFT', '')).approved, false, 'no Status line means draft')
  const p = problemsOf(GOOD.replace('Status: DRAFT', 'Status: ready'))
  assert.match(p[0], /^Line 2: Status should be DRAFT or APPROVED/)
})

test('the approval lock: a DRAFT script is refused when approval is required', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dv-script-'))
  const paths = { script: join(dir, 'script.md') }
  writeFileSync(paths.script, GOOD)
  assert.ok(loadScript(paths), 'a draft is fine for the storyboard')
  assert.throws(() => loadScript(paths, { requireApproved: true }), (e) => e.exitCode === 2 && /Status: DRAFT/.test(e.message))
  writeFileSync(paths.script, GOOD.replace('Status: DRAFT', 'Status: APPROVED'))
  assert.equal(loadScript(paths, { requireApproved: true }).approved, true)
})

test('a script with mistakes stops with every mistake listed', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dv-script-'))
  const paths = { script: join(dir, 'script.md') }
  writeFileSync(paths.script, GOOD.replace('Show: /home', 'Shwo: /home'))
  assert.throws(() => loadScript(paths), (e) => e.exitCode === 3 && /needs 2 fixes/.test(e.message))
})

test('a missing script asks for one to be written', () => {
  assert.throws(() => loadScript({ script: join(tmpdir(), 'no-such-dir-dv', 'script.md') }), (e) => e.exitCode === 2)
})

test('mistakes are named with their line numbers', () => {
  const cases = [
    [GOOD.replace('Show: /home', 'Shwo: /home'), /^Line 11: "Shwo:" is not a keyword \(did you mean Show:\?\)/],
    [GOOD.replace('Show: /home', 'Show: the home page'), /Show should be just the page's address/],
    [GOOD.replace('Show: /home\n', ''), /scene 1 has no Show line/],
    [GOOD.replace('when I say "one place"', 'when I say "two places"'), /"two places" is not in scene 1's Say words/],
    [GOOD.replace('in one place.', 'in one place, one place.'), /appears 2 times in scene 1's Say words/],
    [GOOD.replace('when I say “the fig”', 'when I say “smile”'), /"smile" is not in scene 2's Say words.*\[notes\] do not count/],
    [GOOD.replace('Point at: "Get started" when I say "one place"', 'Point at: Get started'), /Point at should be written as/],
    [GOOD.replace('Zoom: none', 'Zoom: the list'), /Zoom should be written as.*or Zoom: none/],
    [GOOD.replace('## 2. Search', '## 3. Search'), /this is scene 2 but it is numbered 3/],
    [GOOD.replace('## Title card\nSay: Meet Sample.', '## Title card\nShow: /\nSay: Meet Sample.'), /a title card can only have Say and Tone, not Show/],
    [GOOD.replace('Tone: a little brighter', 'Tone: a little brighter\nTone: again'), /already has a Tone line/],
    [GOOD.replace('Say: Everything you need, in one place.', 'Say: Everything you need, in one place.\nShow: /x'), /already has a Show line/],
    [GOOD.replace('Say: Everything you need, in one place.', 'Say: —'), /scene 1 has nothing to say/],
    [GOOD.replace('Say: Try Sample today.', 'Say: —'), /end card's Say has no words to speak/],
    [GOOD.replace('Do: click "Search"', 'Do: drag "Search"'), /Do: I don't understand "drag/],
    [GOOD.replace('press "Enter"', 'wait 45 seconds'), /a wait can be at most 30 seconds/],
    [GOOD.replace('## 1. Welcome', 'Status: APPROVED\n## 1. Welcome'), /the Status line goes at the top/],
    [GOOD.replace('Click: “Fiddle leaf fig” when I say “the fig”', 'Click: “Fiddle leaf fig” when I say “the fig”\nPoint at: "Search"'), /Point at or Click, not both/],
    [GOOD.replace('## End card', '## End card\n## End card'), /more than one end card/],
    [GOOD.replace('## Title card\nSay: Meet Sample.\n', '').replace('## End card', '## Title card\n\n## End card'), /title card has to come before the first scene/],
    ['# Demo script: Empty\nStatus: DRAFT\n', /The script has no scenes yet/],
  ]
  for (const [src, want] of cases) {
    const p = problemsOf(src)
    assert.ok(p.some((x) => want.test(x)), `expected ${want} in:\n${p.join('\n') || '(no problems)'}`)
  }
})

test('a stray line inside a scene is pointed out rather than dropped', () => {
  const src = GOOD.replace('Show: /home', 'Show: /home\nremember to smile')
  assert.match(problemsOf(src)[0], /"remember to smile" is not part of any line I know/)
})

test('silent cards: a title or end card with no Say is allowed and has no words', () => {
  const s = parseScript(GOOD.replace('Say: Meet Sample.', '').replace('Say: Try Sample today.', 'Tone: calm'))
  assert.deepEqual(s.problems, [])
  assert.deepEqual(s.titleCard.words, [])
  assert.deepEqual(s.endCard.words, [])
})

test('Windows line endings read the same', () => {
  assert.deepEqual(parseScript(GOOD.replace(/\n/g, '\r\n')).problems, [])
})

test('Do steps: every kind reads, and joining words are optional', () => {
  const r = parseSteps('click "A" and then type "b c" into "Box"; choose "Big" from "Size", hover over "Help", scroll to "Footer", scroll down 600, wait 2 seconds, wait for "Done"')
  assert.equal(r.error, undefined)
  assert.deepEqual(r.steps.map((s) => s.kind), ['click', 'type', 'choose', 'hover', 'scrollTo', 'scroll', 'wait', 'waitFor'])
  assert.equal(r.steps[5].amount, 600)
  assert.equal(r.steps[6].seconds, 2)
})

test('phrases match whole words, ignoring case and punctuation', () => {
  const words = ['One', 'tap,', 'and', "it's", 'done.', 'One', 'more?']
  assert.equal(phraseCount(words, 'one tap'), 1)
  assert.equal(phraseCount(words, 'its done'), 1)
  assert.equal(phraseCount(words, 'one'), 2)
  assert.equal(phraseCount(words, 'on'), 0, 'part of a word does not count')
  assert.equal(phraseCount(words, ''), 0)
})

test('allWords changes when (and only when) spoken words change', () => {
  const a = allWords(parseScript(GOOD))
  assert.equal(allWords(parseScript(GOOD.replace('Tone: a little brighter', 'Tone: calm'))), a)
  assert.notEqual(allWords(parseScript(GOOD.replace('Find anything fast.', 'Find it fast.'))), a)
})

test('the blank template reads cleanly and starts as a draft', () => {
  const template = parseScript(readFileSync(join(SKILL_DIR, 'templates', 'script.md'), 'utf8'))
  assert.deepEqual(template.problems, [])
  assert.equal(template.approved, false, 'a new script always starts as a draft')
})

// The example lives beside the skill in its own folder; once the skill is copied into a project it
// is not there, so this one only runs in the skill's own folder.
const EXAMPLE_SCRIPT = join(SKILL_DIR, '..', 'example', 'demo-video', 'script.md')
test('the Fernhouse example script reads cleanly', { skip: !existsSync(EXAMPLE_SCRIPT) && 'the example folder is not beside the skill here' }, () => {
  const example = parseScript(readFileSync(EXAMPLE_SCRIPT, 'utf8'))
  assert.deepEqual(example.problems, [])
  assert.equal(example.approved, true)
  assert.equal(example.scenes.length, 4)
})
