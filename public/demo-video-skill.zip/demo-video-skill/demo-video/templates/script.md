# Demo script: Your app
Status: DRAFT

<!--
How this works:
- Each scene is a heading "## 1. Name", then its lines. Number the scenes 1, 2, 3 in order.
- Show: the page's address in your app, such as /dashboard.
- Do: steps before the picture is taken: click "Button", type "words" into "Box",
  choose "Option" in "List", press "Enter", hover over "Thing", scroll to "Heading",
  scroll down, wait 2 seconds, wait for "Words". Several are joined with commas.
- Point at: "Button words" when I say "spoken words": the pointer glides to it on those words.
- Click: the same as Point at, but it really clicks, and the next picture shows what happened.
- Zoom: "Part of the page": where the camera moves in. Zoom: none keeps the camera still.
- Tone: how this scene should sound, such as "a little brighter".
- Say: the words for the scene. [Notes in square brackets] are for the voice and never spoken.
- The Title card and End card are optional, and so are their Say lines.

When every Say line reads right, change DRAFT to APPROVED at the top.
Nothing is recorded until then. If any spoken words change afterwards, it goes back to DRAFT.
-->

## Title card
Say: Meet your app.

## 1. Welcome
Show: /
Say: This is the first thing you see.

## End card
Say: Try it today.
