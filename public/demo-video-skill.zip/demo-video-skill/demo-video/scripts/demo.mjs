#!/usr/bin/env node
// The one command for the demo video. Claude runs it for you; you can run it too:
//
//   node .claude/skills/demo-video/scripts/demo.mjs <step>
//
// Run it with no step to see the list. It finishes with:
//   0 = done · 1 = something broke · 2 = it needs you (approve the script, add a key, sign in)
//   3 = a check failed (a button the script names is not there, the video has a black stretch)

import { spawn } from 'node:child_process'
import { join } from 'node:path'
import { EXIT, findProject, NeedsYou, parseArgs, pathsFor, Problem, secondsText, shown, suggest } from './lib/project.mjs'
import { loadPrivateEnv, redact } from './lib/secrets.mjs'

const STEPS = [
  ['setup', 'Installs the helpers and the hidden browser. Once per project, about 300 MB.'],
  ['new', 'Starts the demo-video folder: settings, script and the private file. Never overwrites.'],
  ['doctor', 'Checks everything is ready and names the one thing to fix. --voice-test re-tests the voice.'],
  ['look', 'Walks through your app and notes the real words on each page, so the script uses them. --pages 12'],
  ['sign-in', 'For apps you sign in to by hand (Google, Apple, codes): opens a window, you sign in once.'],
  ['storyboard', 'Takes the pictures and opens a page showing every scene with its words. --scene 2 for one scene.'],
  ['narrate', 'Records the narration (only once the script says APPROVED). Unchanged lines are reused.'],
  ['make', 'Makes the whole video as a new cut (cut-01, cut-02…), checks it, and writes a report.'],
  ['check', 'Checks the newest cut again (or --cut 2), with today\'s never_show list.'],
  ['watch', 'Opens the newest cut\'s video and its contact sheet.'],
  ['preview', 'Plays the newest cut\'s film page in your browser, with a play bar. Stop with Ctrl+C.'],
  ['selftest', 'Proves every video check can fail, using small test videos made on the spot.'],
  ['set-private', 'Writes one line of the private file from what is piped in, never showing it: set-private APP_TEST_PASSWORD'],
]
const ALIASES = { render: 'make', video: 'make', check_setup: 'doctor', init: 'new', install: 'setup' }

const log = (s) => console.log(redact(String(s)))

function helpText() {
  const w = Math.max(...STEPS.map(([s]) => s.length))
  return [
    'Make a demo video of your app. The usual order:',
    '  setup → new → doctor → look → (write the script) → storyboard → (approve) → make',
    '',
    'Steps:',
    ...STEPS.map(([s, d]) => `  ${s.padEnd(w)}  ${d}`),
    '',
    'Run one with: node .claude/skills/demo-video/scripts/demo.mjs <step>',
    'Options for any step: --project <folder> (when running from somewhere else).',
  ].join('\n')
}

function openFile(target) {
  try {
    const p = spawn('open', [target], { stdio: 'ignore', detached: true })
    p.on('error', () => log(`(Could not open it by itself. Open this: ${target})`))
    p.unref()
  } catch {
    log(`(Could not open it by itself. Open this: ${target})`)
  }
}

/** The setup check, then the settings. Throws the right kind of stop when something needs fixing. */
async function checked(paths, opts = {}) {
  const { doctor, doctorStop } = await import('./lib/doctor.mjs')
  log('Checking the setup…')
  const d = await doctor({ paths, log, ...opts })
  if (!d.ok) throw doctorStop(d.failed)
  return d.settings
}

function sceneList(value) {
  if (value == null || value === true) return null
  const ns = String(value).split(/[\s,]+/).filter(Boolean).map(Number)
  if (!ns.length || ns.some((n) => !Number.isInteger(n) || n < 1)) throw new Problem(`--scene should be a scene number, or several like 2,3 (not "${value}").`)
  return ns
}

async function run(step, flags) {
  const project = findProject(flags)
  let paths = pathsFor(project)
  loadPrivateEnv(paths.privateEnv)
  const where = (p) => shown(p, project)

  switch (step) {
    case 'help':
      log(helpText())
      return EXIT.ok

    case 'setup': {
      const { setup } = await import('./lib/setup.mjs')
      setup({ log })
      log('Next: the "new" step starts the demo-video folder in your project.')
      return EXIT.ok
    }

    case 'new': {
      const { newProject } = await import('./lib/newproject.mjs')
      const r = newProject(paths)
      for (const f of r.made) log(`  made  ${where(f)}`)
      for (const f of r.kept) log(`  kept  ${where(f)} (already there, left as it was)`)
      log(r.ignore === 'added' ? '  added the private file and the output folder to .gitignore, so they are never committed' : '  .gitignore already keeps the private file and the output folder out of git')
      log('Next: fill in demo-video/settings.yaml (Claude can ask you the questions and fill it in), then run the doctor step.')
      return EXIT.ok
    }

    case 'doctor': {
      const { doctor, doctorStop } = await import('./lib/doctor.mjs')
      const d = await doctor({ paths, log, voiceTest: !!flags['voice-test'], needApp: !flags['no-app'] })
      if (!d.ok) throw doctorStop(d.failed)
      log('Everything is ready.')
      return EXIT.ok
    }

    case 'look': {
      const settings = await checked(paths, { needVoice: false })
      paths = pathsFor(project, settings)
      const { lookAround } = await import('./lib/look.mjs')
      const pages = flags.pages ? Number(flags.pages) : 12
      if (!Number.isInteger(pages) || pages < 1 || pages > 40) throw new Problem('--pages should be a number from 1 to 40.')
      const r = await lookAround({ settings, paths, log, pages, start: typeof flags.start === 'string' ? flags.start : '/' })
      log(`Looked at ${r.pages.length} page${r.pages.length === 1 ? '' : 's'}${r.skipped.length ? ` (skipped ${r.skipped.length}: sign-out, delete-type and file links are never opened)` : ''}.`)
      log(`Notes on every page: ${where(join(paths.look, 'pages.md'))}`)
      log(`Pictures: ${where(paths.look)}/page-01.png and on.`)
      return EXIT.ok
    }

    case 'sign-in': {
      const { loadSettings } = await import('./lib/settings.mjs')
      const settings = await loadSettings(paths)
      paths = pathsFor(project, settings)
      if (settings.sign_in.method !== 'by-hand') {
        throw new Problem(`The sign-in step is for sign_in → method: by-hand. Your settings say "${settings.sign_in.method}", ${settings.sign_in.method === 'form' ? 'so the test account in private.env is used automatically' : 'so no sign-in is needed'}.`)
      }
      const { appAnswers } = await import('./lib/doctor.mjs')
      const ans = await appAnswers(settings.app_url)
      if (!ans.ok) throw new NeedsYou(`Your app is not answering at ${settings.app_url} (${ans.why}). Start it first.`)
      const { signInByHand } = await import('./lib/browser.mjs')
      const minutes = flags.minutes ? Number(flags.minutes) : 5
      await signInByHand(settings, paths, { log, minutes: Number.isFinite(minutes) && minutes > 0 ? Math.min(minutes, 30) : 5 })
      return EXIT.ok
    }

    case 'storyboard': {
      const settings = await checked(paths, { needVoice: false })
      paths = pathsFor(project, settings)
      const { loadScript } = await import('./lib/script.mjs')
      const { makeStoryboard, lengthVerdict } = await import('./lib/storyboard.mjs')
      const script = loadScript(paths)
      const r = await makeStoryboard({ settings, script, paths, log, only: sceneList(flags.scene) })
      const verdict = lengthVerdict(r.layout.duration, settings.video_length_seconds)
      log('')
      log(`Length: ${verdict.text}`)
      for (const w of r.warnings) log(`Note: ${w}`)
      log(`Storyboard: ${where(r.file)}`)
      if (r.checkDir) log(`Each scene's picture with its outlines drawn in, for checking: ${where(r.checkDir)}`)
      if (!flags['no-open']) openFile(r.file)
      if (r.problems.length) {
        const { CheckFailed } = await import('./lib/project.mjs')
        throw new CheckFailed(`The storyboard found ${r.problems.length === 1 ? 'one thing' : `${r.problems.length} things`} to fix in the script:\n${r.problems.map((p) => `  • ${p}`).join('\n')}`, r.problems)
      }
      log(script.approved
        ? 'The script says APPROVED. If you changed any Say words since, set it back to Status: DRAFT and read the storyboard again.'
        : 'When every Say line reads right, change "Status: DRAFT" to "Status: APPROVED" at the top of script.md (or tell Claude "approved"). Nothing is recorded before then.')
      return EXIT.ok
    }

    case 'narrate': {
      const settings = await checked(paths, { needApp: false })
      paths = pathsFor(project, settings)
      const { loadScript } = await import('./lib/script.mjs')
      const { narrate } = await import('./lib/narrate.mjs')
      const script = loadScript(paths, { requireApproved: true })
      const r = await narrate({ settings, script, paths, log })
      log(`Narration: ${secondsText(r.duration)} in all (${r.recorded} line${r.recorded === 1 ? '' : 's'} recorded, ${r.reused} reused).`)
      log(`Listen: ${where(join(paths.narration, 'narration.wav'))}`)
      return EXIT.ok
    }

    case 'make': {
      const settings = await checked(paths)
      paths = pathsFor(project, settings)
      const { loadScript } = await import('./lib/script.mjs')
      const { makeVideo } = await import('./lib/make.mjs')
      const script = loadScript(paths, { requireApproved: true })
      const r = await makeVideo({ settings, script, paths, log })
      log('')
      log(`Cut ${r.cut} is ready: ${r.where}/${r.video} (${secondsText(r.duration)}).`)
      for (const w of r.checks.warnings) log(`Note: ${w}`)
      log(`Every check passed. Report: ${r.where}/report.md · Contact sheet: ${r.where}/contact-sheet.jpg`)
      log('To watch it: the watch step. Tell Claude what to change, and the next cut lands beside this one.')
      return EXIT.ok
    }

    case 'check': {
      const { loadSettings } = await import('./lib/settings.mjs')
      const settings = await loadSettings(paths)
      paths = pathsFor(project, settings)
      const { recheck } = await import('./lib/make.mjs')
      const r = await recheck({ settings, paths, n: typeof flags.cut === 'string' ? flags.cut : null, log })
      for (const w of r.checks.warnings) log(`Note: ${w}`)
      log(`Cut ${r.cut}: every check passed.`)
      return EXIT.ok
    }

    case 'watch':
    case 'preview': {
      const { loadSettings } = await import('./lib/settings.mjs')
      const settings = await loadSettings(paths)
      paths = pathsFor(project, settings)
      const { latestCut } = await import('./lib/make.mjs')
      const dir = latestCut(paths, typeof flags.cut === 'string' ? flags.cut : null)
      if (!dir) throw new NeedsYou('There is no video yet. Run the make step first.')
      if (step === 'watch') {
        const { readFileSync } = await import('node:fs')
        const report = JSON.parse(readFileSync(join(dir, 'report.json'), 'utf8'))
        openFile(join(dir, report.video))
        openFile(join(dir, 'contact-sheet.jpg'))
        log(`Opened cut ${report.cut}: ${where(join(dir, report.video))}`)
        return EXIT.ok
      }
      const { serveFolder } = await import('./lib/server.mjs')
      const server = await serveFolder(join(dir, 'film'))
      const url = `${server.url}index.html`
      log(`Playing ${where(dir)} at ${url}`)
      log('Press space to play or pause; the arrow keys step through it. Stop with Ctrl+C.')
      if (!flags['no-open']) openFile(url)
      await new Promise((done) => { process.once('SIGINT', done); process.once('SIGTERM', done) })
      await server.close()
      return EXIT.ok
    }

    case 'selftest': {
      const { selftest } = await import('./lib/selftest.mjs')
      log('Making small test videos that are wrong on purpose, and checking each one is caught…')
      const r = await selftest({ log })
      log(`All ${r.passed} self-tests behaved as expected: every video check can fail.`)
      return EXIT.ok
    }

    case 'set-private': {
      const { PRIVATE_LINES, writePrivateLine } = await import('./lib/secrets.mjs')
      const name = String(words[1] || '').toUpperCase()
      if (!name) throw new Problem(`Name the line to write, for example: set-private APP_TEST_PASSWORD. The lines are: ${PRIVATE_LINES.join(', ')}.`)
      if (process.stdin.isTTY) throw new Problem('Pipe the value in rather than typing it after the step name, so it never sits in the command.')
      const chunks = []
      for await (const c of process.stdin) chunks.push(c)
      const value = Buffer.concat(chunks).toString('utf8')
      if (!value.trim()) throw new Problem(`Nothing was piped in, so the ${name} line was left as it was.`)
      let how
      try { how = writePrivateLine(paths.privateEnv, name, value) } catch (e) { throw new Problem(e.message) }
      log(`${how === 'replaced' ? 'Replaced' : 'Added'} the ${name} line in the private file. The value was not shown anywhere.`)
      return EXIT.ok
    }

    default: {
      const names = [...STEPS.map(([s]) => s), 'help']
      const near = suggest(step, names)
      throw new Problem(`"${step}" is not a step I know.${near ? ` Did you mean ${near}?` : ''}\n\n${helpText()}`)
    }
  }
}

const { words, flags } = parseArgs(process.argv.slice(2))
const asked = String(words[0] || (flags.help ? 'help' : 'help')).toLowerCase()
const step = ALIASES[asked] || asked

run(step, flags).then(
  (code) => { process.exitCode = code ?? EXIT.ok },
  (e) => {
    const known = e && typeof e.exitCode === 'number'
    const code = known ? e.exitCode : EXIT.error
    const head = code === EXIT.needsYou ? 'Needs you:' : code === EXIT.checkFailed ? 'Check failed:' : 'Problem:'
    const msg = known ? e.message : `Something unexpected broke: ${String((e && e.message) || e).split('\n')[0]}`
    console.error(`\n${head} ${redact(msg)}`)
    if (!known && process.env.DEMO_VIDEO_DEBUG) console.error(redact(String(e && e.stack)))
    process.exitCode = code
    // Anything still holding the process open (a stuck browser) gets two seconds, then it ends.
    setTimeout(() => process.exit(code), 2000).unref()
  },
)
