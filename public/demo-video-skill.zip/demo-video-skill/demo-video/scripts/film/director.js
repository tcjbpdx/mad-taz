/* director.js: turns window.FILM_PLAN into the film's shots. Load it last.
 *
 * The make step writes plan.js from the script, the screenshots and the narration:
 *
 *   window.FILM_PLAN = {
 *     device: 'desk' | 'phone',          how the app is framed
 *     accent: '#2E7D5B',                 the colour of the cards, the click ripple and the play bar
 *     duration: 61.6,                    seconds, the length of the narration file
 *     fade: 0.45,                        the cross-fade between shots
 *     cards: [{ id, from, to, name, line, logo, first, last }],     the title card and the end card
 *     scenes: [{ id, line, from, to, stills: ['scene-1', 'scene-1-after'],
 *                target: { box, scale, phrase, click } | null,       where the pointer goes
 *                zoom: { box, scale, phrase } | null | false }],     where the camera goes (null: the target;
 *                                                                     false: no push-in, a slow drift)
 *     captions: [{ text, from, to }],
 *   }
 *
 * Every time that has to land on a spoken word comes from FILM.at(line, phrase), so a phrase the
 * narration does not contain stops the page with a red card instead of clicking at a guess.
 * Hand-tuning a scene: copy this file next to the page, change it, and load the copy instead.
 */
(function (root) {
  'use strict'

  const FILM = root.FILM
  const plan = root.FILM_PLAN
  if (!FILM || typeof FILM.screen !== 'function') throw new Error('director.js needs film-core.js and film-parts.js loaded before it')
  if (!plan || !Array.isArray(plan.scenes)) {
    FILM.fail('plan.js is missing or empty: make the video again')
    return
  }

  const { at, end, screen, pointer, caption, card, W, H } = FILM
  const FADE = Number.isFinite(plan.fade) ? plan.fade : 0.45
  const phone = plan.device === 'phone'

  // The accent colour, and a faint glow of it for the backdrop.
  const accent = /^#[0-9a-f]{6}$/i.test(plan.accent || '') ? plan.accent : '#3B82F6'
  const rgb = [1, 3, 5].map((i) => parseInt(accent.slice(i, i + 2), 16))
  document.documentElement.style.setProperty('--film-accent', accent)
  document.documentElement.style.setProperty('--film-accent-glow', 'rgba(' + rgb.join(',') + ',0.16)')

  // The preview plays the narration that sits beside the page.
  FILM.film({ duration: plan.duration, audio: plan.audio || 'narration.wav' })

  const shots = []
  const over = []

  // ------------------------------------------------------------------ the title card and the end card

  for (const c of plan.cards || []) {
    shots.push({
      id: c.id,
      kind: 'card',
      from: c.from,
      to: c.to == null ? undefined : c.to,
      in: c.first ? { black: 0.5 } : { fade: FADE },
      out: c.last ? { black: 0.7 } : undefined,
      layers: [card({ name: c.name, line: c.line, logo: c.logo || null })],
    })
  }

  // ------------------------------------------------------------------ the app scenes

  /** Camera keys must run forward in time: drop any key that does not. */
  const forward = (keys) => keys.filter((k, i) => i === 0 || k.t > keys[i - 1].t + 1e-6)

  plan.scenes.forEach((s, i) => {
    const last = i === plan.scenes.length - 1 && !(plan.cards || []).some((c) => c.from >= s.to - 1e-6)
    const lineStart = at(s.line)
    const lineEnd = end(s.line)
    const t = s.target || null

    // When the pointer lands: on its phrase, or a little way into the line.
    let tc = null
    if (t) tc = t.phrase ? at(s.line, t.phrase) : Math.min(lineStart + 1.4, Math.max(lineStart, lineEnd - 0.3))

    // The screen: one still, or the still before a click and the still after it.
    const list = s.stills || []
    const seq = list.length > 1 && tc != null
      ? [{ still: list[0], t: -Infinity }, { still: list[1], t: tc + 0.18 }]
      : list[0]

    // The camera: a slow drift, or a push toward the zoom box (else the target) that lands
    // a beat before its moment, then eases back out after a click so the result is seen whole.
    const cam = s.zoom === false ? null : s.zoom || (t ? { box: t.box, scale: t.scale, phrase: null } : null)
    let keys = [{ t: s.from - FADE, scale: 1 }]
    if (cam) {
      const moment = cam.phrase ? at(s.line, cam.phrase) : tc != null ? tc : lineStart + 1.0
      let arrive = moment - 0.2
      let leave = arrive - 1.3
      if (leave < s.from + 0.2) { leave = s.from + 0.2; arrive = Math.max(arrive, leave + 1.1) }
      keys.push({ t: leave, scale: 1 })
      keys.push({ t: arrive, scale: cam.scale, box: cam.box, ease: 'inOut' })
      const backAt = t && t.click && tc != null ? tc + 1.4 : null
      if (backAt != null && s.to - backAt > 2.6) {
        keys.push({ t: backAt, scale: cam.scale * 1.01, box: cam.box, ease: 'linear' })
        keys.push({ t: backAt + 1.3, scale: 1, ease: 'inOut' })
        keys.push({ t: s.to + FADE, scale: 1.02, ease: 'linear' })
      } else {
        keys.push({ t: s.to + FADE, scale: cam.scale * 1.03, box: cam.box, ease: 'linear' })
      }
    } else {
      keys.push({ t: s.to + FADE, scale: 1.04, ease: 'linear' })
    }
    keys = forward(keys)

    const scr = screen(seq, { id: s.id, device: phone ? 'phone' : 'desk', zoom: keys, blend: 0.2, stillsDir: 'stills/' })
    const layers = [scr]

    // The pointer glides in from the lower right and lands on its moment (or simply appears on
    // the target when the line gives it no time to travel).
    if (t && tc != null) {
      const arriveAt = tc - 0.12
      const enter = Math.max(s.from + 0.25, tc - 1.5)
      const path = arriveAt - enter >= 0.6
        ? [{ t: enter, stage: phone ? [W * 0.64, H * 0.82] : [W * 0.74, H * 0.84] }, { t: arriveAt, box: t.box, ease: 'inOut' }]
        : [{ t: Math.max(s.from + 0.1, arriveAt - 0.4), box: t.box }]
      path.push({ t: s.to + FADE, box: t.box })
      layers.push(pointer({ id: s.id + '-pointer', screen: scr, path, clicks: t.click ? [tc] : [], touch: phone }))
    }

    shots.push({
      id: s.id,
      kind: 'screen',
      from: s.from,
      to: s.to,
      in: i === 0 && !(plan.cards || []).length ? { black: 0.5 } : { fade: FADE },
      out: last ? { black: 0.7 } : undefined,
      layers,
    })
  })

  // ------------------------------------------------------------------ captions

  for (const c of plan.captions || []) over.push(caption(c.text, { from: c.from, to: c.to }))

  FILM.shots(shots)
  if (over.length) FILM.over(over)
})(typeof window !== 'undefined' ? window : globalThis)
