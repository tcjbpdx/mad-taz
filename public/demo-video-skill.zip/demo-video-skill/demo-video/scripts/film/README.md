# The film engine

A video here is a web page that draws one frame for any moment you ask it for. The make step
opens that page in a hidden browser, asks for frame 0, 1, 2… (30 a second), photographs each
one and joins them with the narration into an MP4. Nothing on the page moves by itself. Every
position, size and fade is worked out from the time alone, so the same page always gives the
same video.

You do not need to read this to make a video. It is here for anyone who wants to hand-tune one.

## The files

| File | What it is |
|---|---|
| `film-core.js` | The clock. Works out times from the narration's words (`FILM.at`, `FILM.end`), holds the shot list, gives the page its `window.__film` handle (duration, fps, ready, seek), and runs the preview play bar. |
| `film-parts.js` | The pictures: `screen` (a screenshot in a desk window or a phone outline, with camera moves), `pointer` (a mouse arrow or fingertip that glides and clicks), `spotlight`, `chip`, `title`, `caption` (subtitles) and `card` (the title and end cards). |
| `director.js` | Reads `plan.js` (written by the make step) and builds the shots: one per scene, plus the cards and captions. |
| `film.css` | How everything looks. The accent colour comes from your settings. |
| `assets/fonts/` | The Inter font, with its licence (SIL Open Font License). |

## The film page (made for you in the output folder)

```
film/
  index.html     loads the files above, then timeline.js, stills.js, plan.js, director.js
  timeline.js    every narration line with the time of each word
  stills.js      the screenshots, with the box of each thing the pointer or camera aims at
  plan.js        the scenes: when each starts and ends, where the pointer clicks
  stills/        the screenshots
  narration.wav  the narration
```

Open `film/index.html` through the preview link the make step prints to play the film with its
narration and scrub through it. Add `?export=1` to see the bare 1920×1080 stage.

## The rules the engine keeps

- **Times come from words.** `FILM.at('s2', 'one tap')` is the moment "one tap" starts in line
  `s2`. A phrase the line does not contain, or contains twice, is a load error: the page shows a
  red card and the video is not made. It never clicks at a guess.
- **Nothing moves on its own clock.** CSS animations and transitions are switched off on the
  stage, and any that sneak back in are a load error.
- **Every frame is checked.** If a layer fails to draw a frame, that frame is reported as wrong
  and the make step stops.

## Hand-tuning one scene

Copy `director.js` to `demo-video/custom/director.js` in your project and change the copy. The
make step uses your copy instead of the standard one for as long as it is there (delete it to go
back). Each layer takes plain options. For example, a pointer that hovers without clicking:

```js
FILM.pointer({ screen: scr, path: [{ t: at('s2') + 0.5, stage: [1400, 900] }, { t: at('s2', 'one tap'), box: 'target' }], clicks: [] })
```
