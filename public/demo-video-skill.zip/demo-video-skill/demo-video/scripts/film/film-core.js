/* film-core.js: the film runtime: its clock, word cues and the window.__film contract.
 *
 * A film page is a pure function of time: seek(t) sets the exact picture for
 * second t, and nothing moves on its own clock. That is what makes every frame
 * come out the same each time the video is made. This file holds the parts
 * that are not pictures:
 *
 *   - FILM.at() / FILM.end(): times taken from the narration's own words. A
 *     phrase that is missing or ambiguous is a LOAD ERROR: the page shows a red
 *     card and window.__film.ready rejects, so the video fails instead of guessing.
 *   - easing and small maths (ramp, mix, clamp, a seeded random);
 *   - FILM.shots([...]) and FILM.over([...]): the shot list and the layers that
 *     span shots. Layers come from film-parts.js;
 *   - window.__film = { duration, fps, ready, seek, cues, shots };
 *   - preview mode (a small play bar with the narration) and export mode
 *     (?export=1: no bar, no audio, a bare 1920x1080 stage).
 *
 * Plain script, no dependencies. Load order: film.css, film-core.js,
 * film-parts.js, timeline.js, stills.js, plan.js, director.js. README.md beside
 * this file explains the pieces.
 */
(function (root) {
  'use strict'

  const FPS = 30
  const W = 1920
  const H = 1080
  const EPS = 1e-9
  const hasDOM = typeof document !== 'undefined' && typeof document.createElement === 'function'

  const FILM = (root.FILM = root.FILM || {})
  const query = hasDOM && root.location && typeof URLSearchParams === 'function'
    ? new URLSearchParams(root.location.search)
    : { get: () => null }
  const EXPORT = query.get('export') === '1'

  // Where this file lives, so film-parts.js can find assets/ from any page depth.
  const BASE = (() => {
    if (!hasDOM) return ''
    const s = document.currentScript
    try { return s && s.src ? new URL('.', s.src).href : '' } catch { return '' }
  })()

  const state = {
    errors: [],
    warnings: [],
    shots: [],
    over: [],
    made: [], // every layer made, so one put in no shot is a load error rather than missing silently
    options: { tail: 1.5 },
    minted: new Map(), // time -> { label, line, phrase }: every at()/end() result
    extraCues: [],
    cues: [],
    shotList: [],
    duration: NaN,
    built: false,
    mounted: false,
    stage: null,
    layers: [],
    lastN: -1,
    t: 0,
  }

  // ------------------------------------------------------------------ errors

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
  }

  /** Record a load error. The page shows it on a red card and __film.ready rejects. */
  function fail(message) {
    state.failCount = (state.failCount || 0) + 1 // counts repeats too, so seek() can tell a frame broke
    const msg = String(message)
    if (!state.errors.includes(msg)) state.errors.push(msg)
    if (typeof console !== 'undefined') console.error('[film] ' + msg)
    if (state.mounted) showErrors()
    return NaN
  }

  /** Record something worth knowing that does not stop the film (shown in the preview bar and the console). */
  function warn(message) {
    const msg = String(message)
    if (!state.warnings.includes(msg)) state.warnings.push(msg)
    if (typeof console !== 'undefined') console.warn('[film] ' + msg)
  }

  function showErrors() {
    if (!hasDOM || !state.errors.length) return
    const stage = ensureStage()
    let card = stage.querySelector(':scope > .film-error')
    if (!card) {
      card = document.createElement('div')
      card.className = 'film-error'
      stage.appendChild(card)
    }
    card.innerHTML = '<div class="film-error-title">This film page cannot be filmed</div><ol>' +
      state.errors.map((e) => '<li>' + escapeHtml(e) + '</li>').join('') + '</ol>' +
      '<div class="film-error-foot">window.__film.ready rejects until these are fixed.</div>'
  }

  // ------------------------------------------------------------------ small maths

  const clamp = (x, a = 0, b = 1) => (x < a ? a : x > b ? b : x)
  const c01 = (t) => clamp(Number.isFinite(t) ? t : 0, 0, 1)

  /** Easing curves: each is a pure function from [0,1] to [0,1] with f(0)=0 and f(1)=1. */
  const ease = {
    linear: (t) => c01(t),
    in: (t) => { t = c01(t); return t * t * t },
    out: (t) => { t = c01(t); return 1 - Math.pow(1 - t, 3) },
    inOut: (t) => { t = c01(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2 },
    smooth: (t) => { t = c01(t); return t * t * t * (t * (t * 6 - 15) + 10) },
    // Half linear, half smoothstep: a camera move that is already moving on its first frame and still on its last.
    gentle: (t) => { t = c01(t); return 0.5 * t + 0.5 * t * t * (3 - 2 * t) },
    // At full speed on its first frame, then slowing to land softly: a move that must show on its word
    // (by a quarter of its length it is 44% of the way; 'smooth' is 10% there and 'inOut' 6%).
    land: (t) => { t = c01(t); return 1 - (1 - t) * (1 - t) },
    // A gentle settle: overshoots by about 4.5 percent (near t = 0.65), then comes to rest exactly at 1.
    settle: (t) => { t = c01(t); const c1 = 1.1, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2) },
    // A fast arrival that never passes 1 (no overshoot, unlike settle): for things landing on a surface.
    press: (t) => { t = c01(t); return 1 - Math.pow(1 - t, 3) * Math.cos(t * Math.PI * 0.5) },
  }

  function easeFn(e) {
    if (typeof e === 'function') return e
    if (e == null) return ease.inOut
    if (ease[e]) return ease[e]
    fail('unknown ease "' + e + '"; use one of ' + Object.keys(ease).join(', ') + ' or a function')
    return ease.inOut
  }

  /** Progress of t from a to b, clamped to [0,1], optionally eased. ramp(t, a, b) is 0 before a and 1 after b. */
  function ramp(t, a, b, e) {
    let u
    if (!(b > a)) u = t >= a ? 1 : 0
    else u = clamp((t - a) / (b - a))
    return e ? easeFn(e)(u) : u
  }

  /** Linear mix of two numbers (or two arrays of numbers, element by element). */
  function mix(a, b, u) {
    if (Array.isArray(a)) return a.map((v, i) => mix(v, b[i], u))
    return a + (b - a) * u
  }

  function hashSeed(seed) {
    if (typeof seed === 'number' && Number.isFinite(seed)) return (seed >>> 0) || 0x9e3779b9
    let h = 0x811c9dc5
    for (const ch of String(seed)) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) }
    return (h >>> 0) || 0x9e3779b9
  }

  /** A seeded random generator (mulberry32). FILM.random('dust')() gives the same numbers every time. */
  function random(seed) {
    let a = hashSeed(seed)
    return function next() {
      a = (a + 0x6d2b79f5) | 0
      let t = Math.imul(a ^ (a >>> 15), 1 | a)
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296
    }
  }

  /** Smooth, seeded drift in [-1,1] for each axis: a hand-held breath that is still a function of t alone. */
  function drift(t, seed = 1, speed = 0.35) {
    const r = random(seed)
    const p = [r(), r(), r(), r()].map((v) => v * Math.PI * 2)
    const x = 0.6 * Math.sin(t * speed * 2.1 + p[0]) + 0.4 * Math.sin(t * speed * 3.7 + p[1])
    const y = 0.6 * Math.sin(t * speed * 1.7 + p[2]) + 0.4 * Math.sin(t * speed * 3.1 + p[3])
    return [x, y]
  }

  // ------------------------------------------------------------------ the narration timeline and word cues

  function timeline() {
    const tl = root.FILM_TIMELINE
    return tl && Array.isArray(tl.lines) ? tl : null
  }

  function findLine(tl, id) {
    const want = typeof id === 'number' ? 's' + id : String(id)
    return tl.lines.find((l) => l.id === want || (l.n != null && 's' + l.n === want)) || null
  }

  /** Matching ignores case, accents, punctuation (dashes included) and apostrophes. */
  const norm = (s) => String(s == null ? '' : s).toLowerCase().normalize('NFKD')
    .replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}]+/gu, '')

  function findPhrase(line, phrase, opts) {
    const words = (line.words || []).map((w, i) => ({ w, i, k: norm(w.text) })).filter((x) => x.k)
    const toks = String(phrase).split(/\s+/).map(norm).filter(Boolean)
    if (!toks.length) return { error: 'the phrase is empty once punctuation is ignored' }
    const hits = []
    for (let i = 0; i + toks.length <= words.length; i++) {
      let ok = true
      for (let j = 0; j < toks.length; j++) if (words[i + j].k !== toks[j]) { ok = false; break }
      if (ok) hits.push(i)
    }
    const said = words.map((x) => x.w.text).join(' ')
    if (!hits.length) return { error: 'not found in line ' + line.id + ' (its words: ' + said + ')' }
    let at = hits[0]
    const nth = opts && opts.nth
    if (nth != null) {
      if (!(Number.isInteger(nth) && nth >= 1 && nth <= hits.length)) {
        return { error: '{ nth: ' + nth + ' } but the phrase occurs ' + hits.length + ' time(s) in line ' + line.id }
      }
      at = hits[nth - 1]
    } else if (hits.length > 1) {
      return { error: 'ambiguous: it occurs ' + hits.length + ' times in line ' + line.id + '; say which with { nth: 1 } to { nth: ' + hits.length + ' }' }
    }
    const span = words.slice(at, at + toks.length)
    const unheard = span.filter((x) => x.w.heard === false)
    if (unheard.length) {
      return { error: 'it touches ' + unheard.map((x) => '"' + x.w.text + '"').join(', ') + ', marked heard: false in the timeline (the word was not clearly spoken; cue a neighbouring word)' }
    }
    return { first: span[0].w, last: span[span.length - 1].w }
  }

  const finite = (...xs) => xs.find((x) => typeof x === 'number' && Number.isFinite(x))

  function cueTime(kind, lineId, phrase, opts) {
    const call = kind + '(' + JSON.stringify(lineId) + (phrase != null ? ', ' + JSON.stringify(phrase) : '') +
      (opts ? ', ' + JSON.stringify(opts) : '') + ')'
    const tl = timeline()
    if (!tl) return fail(call + ': no narration timeline is loaded (timeline.js is missing or has no lines)')
    const line = findLine(tl, lineId)
    if (!line) return fail(call + ': there is no line ' + JSON.stringify(lineId) + ' (the lines are ' + tl.lines.map((l) => l.id).join(', ') + ')')
    let t
    const words = line.words || []
    if (phrase == null) {
      t = kind === 'at' ? finite(line.start, words[0] && words[0].s) : finite(line.end, words.length ? words[words.length - 1].e : undefined)
    } else {
      const r = findPhrase(line, phrase, opts)
      if (r.error) return fail(call + ': ' + r.error)
      t = kind === 'at' ? r.first.s : r.last.e
    }
    if (!Number.isFinite(t)) return fail(call + ': the timeline gives no time for it')
    const label = phrase == null ? line.id + (kind === 'end' ? ' (end)' : '') : line.id + (kind === 'end' ? ' end of "' : ' "') + phrase + '"'
    const info = { label, line: line.id, phrase: phrase == null ? null : String(phrase) }
    const had = state.minted.get(t)
    if (!had || (had.phrase == null && info.phrase != null)) state.minted.set(t, info)
    return t
  }

  /** at('s3') is the start of line s3; at('s3', 'light hits') the start of that phrase's first word. */
  function at(lineId, phrase, opts) { return cueTime('at', lineId, phrase, opts) }
  /** end('s3') is the end of line s3; end('s3', 'light hits') the end of that phrase's last word. */
  function end(lineId, phrase, opts) { return cueTime('end', lineId, phrase, opts) }

  function lastWord() {
    const tl = timeline()
    if (!tl) return NaN
    let e = NaN
    for (const l of tl.lines) for (const w of l.words || []) if (Number.isFinite(w.e) && !(w.e <= e)) e = w.e
    if (!Number.isFinite(e)) for (const l of tl.lines) if (Number.isFinite(l.end) && !(l.end <= e)) e = l.end
    return e
  }

  // ------------------------------------------------------------------ shots and layers

  /** The film's settings: { duration } (seconds; default: the last word's end + tail), { tail } (at most 5 s), { audio } (preview only). */
  function film(opts) { Object.assign(state.options, opts || {}) }

  /** Declare a cue that is not a shot or layer start, e.g. FILM.cue(at('s2', 'pull back'), 'camera pulls back'). */
  function cue(t, label) {
    if (!Number.isFinite(t)) return fail('FILM.cue(' + t + '): not a time')
    const m = state.minted.get(t)
    state.extraCues.push({ t, label: label || (m ? m.label : 'cue at ' + t.toFixed(2)), line: m ? m.line : null, phrase: m ? m.phrase : null, kind: 'cue' })
    return t
  }

  function normIn(spec, where) {
    if (spec == null || spec === 'cut' || spec.cut) return { kind: 'cut', d: 0 }
    if (spec === 'fade') return { kind: 'fade', d: 0.3 }
    if (spec === 'black') return { kind: 'black', d: 0.4 }
    if (typeof spec === 'object' && spec.fade != null) return { kind: 'fade', d: Number(spec.fade) }
    if (typeof spec === 'object' && spec.black != null) return { kind: 'black', d: Number(spec.black) }
    fail(where + ': "in" must be { cut: true }, { fade: seconds } or { black: seconds }')
    return { kind: 'cut', d: 0 }
  }

  /** Add shots: { id, from, to?, kind: 'photo'|'screen'|'card'|'black', hold?, allowWhite?, allowBlack?, in?, out?, layers: [...] }.
   *  hold, allowWhite and allowBlack are kept for the checks (a deliberate still; white or black frames that are meant). */
  function shots(list) {
    if (!Array.isArray(list)) return fail('FILM.shots() takes an array of shots')
    for (const s of list) {
      if (!s || typeof s !== 'object') { fail('FILM.shots(): a shot must be an object'); continue }
      state.shots.push(s)
    }
  }

  /** Add layers that span shots, each with its own from/to. They sit above every shot. */
  function over(list) {
    if (!Array.isArray(list)) return fail('FILM.over() takes an array of layers')
    for (const l of list) state.over.push(l)
  }

  /** Make a layer. film-parts.js builds every primitive with this. */
  function layer(kind, opts, impl) {
    opts = opts || {}
    const L = Object.assign({ kind, opts, id: opts.id || null, from: opts.from, to: opts.to, on: opts.on || null, el: null, _mounted: false }, impl)
    state.made.push(L)
    return L
  }

  /** Opacity for something that fades in around `from` (centred like a shot fade) and out by `to`. 0 means hidden. */
  function presence(t, from, to, enter = 0, exit = 0) {
    const start = enter > 0 ? from - enter / 3 : from
    if (!(t >= start - EPS)) return 0
    if (Number.isFinite(to) && !(t < to - EPS)) return 0
    let k = enter > 0 ? ramp(t, start, from + (2 * enter) / 3, 'smooth') : 1
    if (exit > 0 && Number.isFinite(to)) k = Math.min(k, 1 - ramp(t, to - exit, to, 'smooth'))
    return k
  }

  function ensureStage() {
    let stage = document.getElementById('stage')
    if (!stage) {
      stage = document.createElement('div')
      stage.id = 'stage'
      document.body.appendChild(stage)
    }
    state.stage = stage
    return stage
  }

  const owner = (shot) => (shot ? 'shot "' + shot.id + '"' : 'FILM.over()')
  // How a layer is named in a load error: its kind, then its id, else its picture (photo plate.jpg).
  const named = (L) => (L.kind || 'layer') + (L.id ? ' "' + L.id + '"' : typeof L.src === 'string' ? ' ' + L.src : '')

  function mountLayer(L, host, shot) {
    if (L && L._mounted) return
    if (!L || typeof L.mount !== 'function') { fail('a layer in shot "' + (shot ? shot.id : 'over') + '" is not a layer (did you call photo(...) etc.?)'); return }
    L._mounted = true
    L._shot = shot
    let into = host
    if (L.on) {
      if (!L.on.mount) { fail((L.kind || 'layer') + ': "on" must be a layer such as photo(...) or screen(...)'); return }
      mountLayer(L.on, host, shot)
      // Laid on a layer that another shot owns, it would be drawn inside that shot, on that shot's clock.
      if (L.on._shot !== shot) fail(named(L) + ' in ' + owner(shot) + ' is laid on a ' + named(L.on) + ' from ' + owner(L.on._shot) + ': put them in the same shot')
      into = L.on.surface || host
    }
    try {
      L.mount(into, { FILM, shot, stage: state.stage })
    } catch (e) {
      fail((L.kind || 'layer') + ' could not be built: ' + (e && e.message ? e.message : e))
    }
    state.layers.push(L)
  }

  function build() {
    if (state.built) return
    state.built = true
    const opts = state.options
    const lw = lastWord()

    // Duration: explicit, or the last word's end plus a tail of at most 5 s (room for a silent end card), snapped to whole frames.
    let d = opts.duration
    if (d == null) {
      if (!Number.isFinite(lw)) fail('no duration: call FILM.film({ duration }) or load a narration timeline')
      else d = lw + clamp(Number(opts.tail != null ? opts.tail : 1.5), 0, 5)
    } else {
      d = Number(d)
      if (!(d > 0)) fail('FILM.film({ duration: ' + opts.duration + ' }): not a positive number of seconds')
      else if (Number.isFinite(lw) && d > lw + 5 + 1e-6) warn('the film runs ' + (d - lw).toFixed(2) + ' s past the last word; at most 5 s is the rule')
      else if (Number.isFinite(lw) && d < lw) warn('the film ends before the last word (' + lw + ' s)')
    }
    state.duration = Number.isFinite(d) && d > 0 ? Math.ceil(d * FPS - 1e-6) / FPS : NaN

    // Shots: sort by start, fill in missing ends, validate, and work out each one's visible window.
    const list = state.shots.map((s, i) => ({ s, i })).sort((a, b) => (Number(a.s.from) - Number(b.s.from)) || (a.i - b.i)).map((x) => x.s)
    const ids = new Set()
    list.forEach((s, i) => {
      const where = 'shot "' + (s.id || '#' + (i + 1)) + '"'
      if (!s.id) s.id = 'shot-' + (i + 1)
      if (ids.has(s.id)) fail(where + ': the id is used twice')
      ids.add(s.id)
      s.from = Number(s.from)
      if (s.to == null) s.to = i + 1 < list.length ? Number(list[i + 1].from) : state.duration
      s.to = Number(s.to)
      if (!Number.isFinite(s.from)) fail(where + ': "from" is not a time')
      if (!Number.isFinite(s.to)) fail(where + ': "to" is not a time')
      if (Number.isFinite(s.from) && Number.isFinite(s.to) && !(s.to > s.from)) fail(where + ': it ends (' + s.to + ') before it starts (' + s.from + ')')
      if (!Array.isArray(s.layers)) s.layers = []
      const inn = normIn(s.in, where)
      s._in = inn
      if (inn.kind === 'fade') { s._visFrom = s.from - inn.d / 3; s._inFrom = s._visFrom; s._inTo = s.from + (2 * inn.d) / 3 }
      else if (inn.kind === 'black') { s._visFrom = s.from; s._inFrom = s.from; s._inTo = s.from + inn.d }
      else { s._visFrom = s.from; s._inFrom = s._inTo = s.from }
      s._out = s.out && s.out.black != null ? Number(s.out.black) : 0
      s._visTo = s.to
    })
    list.forEach((s, i) => {
      const next = list[i + 1]
      if (next && next._in.kind === 'fade') s._visTo = Math.max(s.to, next._inTo)
    })
    state.shots = list

    if (hasDOM) mount()

    // Cues: every at()/end() value used as a shot start or a layer start, plus the times a layer lists in
    // cueTimes() (a pointer's clicks, a sweep's fill: kind L.cueKind, or '<kind>-click') and FILM.cue().
    const cues = []
    const add = (t, kind, id) => {
      const m = state.minted.get(t)
      if (m && Number.isFinite(t)) cues.push({ t, label: m.label, line: m.line, phrase: m.phrase, kind, id })
    }
    for (const s of list) {
      add(s.from, 'shot', s.id)
      for (const L of s.layers) if (L) { add(L.from, L.kind, L.id); (L.cueTimes ? L.cueTimes() : []).forEach((t) => add(t, L.cueKind || L.kind + '-click', L.id)) }
    }
    for (const L of state.over) if (L) { add(L.from, L.kind, L.id); (L.cueTimes ? L.cueTimes() : []).forEach((t) => add(t, L.cueKind || L.kind + '-click', L.id)) }
    cues.push(...state.extraCues)
    const seen = new Set()
    state.cues = cues.filter((c) => { const k = c.t.toFixed(4) + '|' + c.label; if (seen.has(k)) return false; seen.add(k); return true })
      .sort((a, b) => a.t - b.t)
    state.shotList = list.map((s) => ({ id: s.id, from: s.from, to: s.to, hold: !!s.hold, kind: s.kind || 'card', allowWhite: !!s.allowWhite, allowBlack: !!s.allowBlack }))
  }

  function mount() {
    const stage = ensureStage()
    document.documentElement.classList.add(EXPORT ? 'film-export' : 'film-preview')
    // A layer is built once, into one place. Listed a second time (in another shot, or twice), it
    // would mount nothing there and that shot would silently lack it: a load error instead.
    const listed = new Map()
    const claim = (L, shot) => {
      if (!L || typeof L !== 'object') return
      if (listed.has(L)) fail(named(L) + ' is listed in ' + owner(listed.get(L)) + ' and again in ' + owner(shot) + ': a layer belongs to one shot, so make another (call ' + (L.kind || 'it') + '(...) again) for the second')
      else listed.set(L, shot)
    }
    for (const s of state.shots) for (const L of s.layers) claim(L, s)
    for (const L of state.over) claim(L, null)
    for (const s of state.shots) {
      const el = document.createElement('div')
      el.className = 'film-shot film-kind-' + (s.kind || 'card')
      el.dataset.shot = s.id
      el.style.display = 'none'
      stage.appendChild(el)
      s._el = el
      for (const L of s.layers) mountLayer(L, el, s)
    }
    const overEl = document.createElement('div')
    overEl.className = 'film-over'
    stage.appendChild(overEl)
    for (const L of state.over) {
      if (L && L.from == null) fail((L.kind || 'layer') + ' in FILM.over() needs "from"')
      mountLayer(L, overEl, null)
    }
    // ...and one listed in a shot but built earlier into another (by a layer laid on it there) is missing too.
    for (const [L, shot] of listed) {
      if (L._mounted && L._shot !== shot) fail(named(L) + ' is listed in ' + owner(shot) + ' but was built into ' + owner(L._shot) + ', where a layer is laid on it: put them in the same shot')
    }
    // ...and one made but put in no shot (nor laid under a layer that is) would never show, silently.
    for (const L of state.made) {
      if (!L._mounted) fail(named(L) + ' was made but is in no shot: put it in a shot\'s layers, or in FILM.over() with its own "from"')
    }
    // Spans: when each layer starts and stops (its own from/to, or its shot's).
    for (const L of state.layers) {
      const s = L._shot
      const from = Number(L.from != null ? L.from : s ? s.from : 0)
      let to = L.to != null ? Number(L.to) : s ? Infinity : state.duration
      if (L.from != null && !Number.isFinite(from)) fail((L.kind || 'layer') + (L.id ? ' "' + L.id + '"' : '') + ': "from" is not a time')
      if (L.to != null && !Number.isFinite(to)) { fail((L.kind || 'layer') + (L.id ? ' "' + L.id + '"' : '') + ': "to" is not a time'); to = Infinity }
      // `end` is when its motion finishes: its own to, else the end of what it belongs to.
      const end = Number.isFinite(to) ? to : s ? s._visTo : state.duration
      L.span = { from, to, end, shot: s, hold: !!(s && s.hold) }
    }
    for (const img of stage.querySelectorAll('img')) { img.decoding = 'sync'; img.loading = 'eager' }
    state.mounted = true
    if (state.errors.length) showErrors()
  }

  // ------------------------------------------------------------------ seek

  const describeEl = (e) => {
    if (!e || !e.tagName) return 'an element'
    const cls = (e.getAttribute && e.getAttribute('class')) || ''
    return e.tagName.toLowerCase() + (cls.trim() ? '.' + cls.trim().split(/\s+/).join('.') : '')
  }

  /** CSS animations and transitions run on the browser's own clock, never seek's, so a page that
   *  has one would film differently each time: each one found is a load error. (film.css switches
   *  them off on the stage; this catches a page's own CSS that switches one back on.) */
  function checkAnimations() {
    if (!hasDOM || typeof document.getAnimations !== 'function') return
    for (const a of document.getAnimations()) {
      const kind = a.transitionProperty ? 'a CSS transition of ' + a.transitionProperty
        : a.animationName ? 'the CSS animation "' + a.animationName + '"' : 'a web animation'
      fail(kind + ' is running on ' + describeEl(a.effect && a.effect.target) + ': nothing may move on its own clock (set the value in seek(t) instead)')
    }
  }

  /** Put the stage in the exact state for second t. Returns the frame number n = floor(t*30 + 1e-6). */
  function seek(t) {
    t = Number(t)
    if (!Number.isFinite(t) || t < 0) t = 0
    const n = Math.floor(t * FPS + 1e-6)
    const tq = n / FPS // the picture depends on the frame number alone
    state.t = tq
    state.lastN = n
    if (!state.mounted) return n
    const failsBefore = state.failCount || 0
    const pending = []
    const done = new Set()
    const run = (L) => {
      if (!L || done.has(L)) return
      done.add(L)
      if (L.on) run(L.on) // a layer laid on another is drawn after it, from the same t
      if (!L._mounted || typeof L.seek !== 'function') return
      try {
        const r = L.seek(tq, L.span)
        if (r && typeof r.then === 'function') pending.push(r)
      } catch (e) {
        fail((L.kind || 'layer') + ' failed at ' + tq.toFixed(3) + ' s: ' + (e && e.message ? e.message : e))
      }
    }
    for (const s of state.shots) {
      const visible = tq >= s._visFrom - EPS && tq < s._visTo - EPS
      s._el.style.display = visible ? 'block' : 'none'
      if (!visible) continue
      let k = 1
      if (s._in.kind !== 'cut') k = Math.min(k, ramp(tq, s._inFrom, s._inTo, 'smooth'))
      if (s._out > 0) k = Math.min(k, 1 - ramp(tq, s.to - s._out, s.to, 'smooth'))
      s._el.style.opacity = String(k)
      for (const L of s.layers) run(L)
    }
    for (const L of state.over) run(L)
    checkAnimations()
    // A layer that broke on this frame drew a wrong picture: report a frame number that cannot be
    // right, so the exporter counts it (seekReportedWrongFrame) and fails instead of filming it.
    const result = () => ((state.failCount || 0) > failsBefore ? -1 : n)
    return pending.length ? Promise.all(pending).then(result) : result()
  }

  // ------------------------------------------------------------------ ready

  const FONT_FAMILY = 'Inter Film'

  async function prepare() {
    if (hasDOM && document.readyState === 'loading') await new Promise((r) => document.addEventListener('DOMContentLoaded', r, { once: true }))
    build()
    if (!state.shots.length && !state.over.length) fail('the page declared no shots: call FILM.shots([...])')
    if (state.errors.length) throw new Error(state.errors.join('\n'))
    if (hasDOM) {
      if (document.fonts) {
        await Promise.all([400, 500, 600, 700, 800].map((w) => document.fonts.load(w + ' 40px "' + FONT_FAMILY + '"')))
        await document.fonts.ready
        if (!document.fonts.check('800 40px "' + FONT_FAMILY + '"')) fail('the Inter font did not load (film/assets/fonts)')
      }
      const imgs = [...document.querySelectorAll('img')]
      await Promise.all(imgs.map((img) => img.decode().catch(() => fail('an image could not be loaded: ' + decodeURI(img.getAttribute('src') || img.src)))))
      for (const L of state.layers) {
        if (typeof L.layout === 'function') {
          try { L.layout() } catch (e) { fail((L.kind || 'layer') + ' layout failed: ' + (e && e.message ? e.message : e)) }
        }
      }
      // Warm seek: middle, then the start, so the first captured frame is not the first paint.
      await seek(state.duration / 2)
      await seek(0)
    }
    if (state.errors.length) throw new Error(state.errors.join('\n'))
    return { duration: state.duration, cues: state.cues.length, shots: state.shotList.length }
  }

  if (hasDOM) {
    // A script or image that fails to load (timeline.js missing, a typo in a path) is a load error too.
    root.addEventListener('error', (e) => {
      const el = e && e.target
      if (el && el !== root && el.tagName) {
        fail('could not load ' + el.tagName.toLowerCase() + ' ' + decodeURI(el.getAttribute('src') || el.getAttribute('href') || ''))
      } else if (e && e.message) {
        fail('script error: ' + e.message + (e.filename ? ' (' + e.filename.split('/').slice(-2).join('/') + ':' + e.lineno + ')' : ''))
      }
    }, true)
  }

  const ready = hasDOM ? prepare() : Promise.resolve()
  if (hasDOM) {
    ready.then(() => { if (!EXPORT) startPreview() }, (err) => {
      showErrors()
      if (!EXPORT) startPreview(err)
    })
  }

  // ------------------------------------------------------------------ preview mode

  function fmt(t) {
    const m = Math.floor(t / 60)
    const s = t - m * 60
    return m + ':' + (s < 10 ? '0' : '') + s.toFixed(2)
  }

  function lineAt(t) {
    const tl = timeline()
    if (!tl) return null
    let cur = null
    for (const l of tl.lines) if (Number.isFinite(l.start) && l.start <= t + EPS) cur = l
    return cur
  }

  function startPreview() {
    const stage = ensureStage()
    const BAR = 64
    const dur = Number.isFinite(state.duration) ? state.duration : 0
    const audioSrc = state.options.audio || '../narration.wav'
    const audio = new Audio()
    audio.preload = 'auto'
    audio.src = audioSrc
    let audioOk = true
    audio.addEventListener('error', () => { audioOk = false; info.textContent = 'no narration at ' + audioSrc + '; playing silent' })

    const bar = document.createElement('div')
    bar.className = 'film-bar'
    bar.innerHTML = '<button type="button" class="film-play" aria-label="Play">' +
      '<svg viewBox="0 0 20 20" width="18" height="18"><path class="i-play" d="M5 3 L17 10 L5 17 Z" fill="currentColor"/>' +
      '<g class="i-pause" fill="currentColor"><rect x="4" y="3" width="4.5" height="14"/><rect x="11.5" y="3" width="4.5" height="14"/></g></svg></button>' +
      '<span class="film-time">0:00.00</span>' +
      '<input class="film-scrub" type="range" min="0" step="0.0333333" value="0">' +
      '<div class="film-line"><span class="film-line-id"></span><span class="film-line-text"></span></div>' +
      '<span class="film-info"></span>'
    document.body.appendChild(bar)
    const btn = bar.querySelector('.film-play')
    const scrub = bar.querySelector('.film-scrub')
    const time = bar.querySelector('.film-time')
    const lineId = bar.querySelector('.film-line-id')
    const lineText = bar.querySelector('.film-line-text')
    const info = bar.querySelector('.film-info')
    scrub.max = String(dur)
    info.textContent = state.cues.length + ' cues · ' + state.shotList.length + ' shots' +
      (state.warnings.length ? ' · ' + state.warnings.length + ' warning' + (state.warnings.length > 1 ? 's' : '') : '')
    if (state.warnings.length) info.title = state.warnings.join('\n')

    let playing = false
    let clock0 = 0
    let t0 = 0
    let shownLine = null
    let raf = 0

    const fit = () => {
      const s = Math.min(root.innerWidth / W, (root.innerHeight - BAR) / H)
      const x = (root.innerWidth - W * s) / 2
      const y = Math.max(0, (root.innerHeight - BAR - H * s) / 2)
      stage.style.transform = 'translate(' + x + 'px,' + y + 'px) scale(' + s + ')'
    }
    root.addEventListener('resize', fit)
    fit()

    const show = (t) => {
      seek(t)
      time.textContent = fmt(t) + ' / ' + fmt(dur)
      if (document.activeElement !== scrub) scrub.value = String(t)
      const l = lineAt(t)
      if (l !== shownLine) {
        shownLine = l
        lineId.textContent = l ? l.id : ''
        lineText.innerHTML = l ? (l.words || []).map((w, i) => '<span data-i="' + i + '">' + escapeHtml(w.text) + '</span>').join(' ') : ''
      }
      if (l) {
        const spans = lineText.children
        ;(l.words || []).forEach((w, i) => { if (spans[i]) spans[i].className = t >= w.s && t < w.e + 0.05 ? 'on' : '' })
      }
    }
    const now = () => (playing ? (audioOk && !audio.ended && !audio.paused ? audio.currentTime : t0 + (performance.now() - clock0) / 1000) : t0)
    const loop = () => {
      if (!playing) return
      let t = now()
      if (t >= dur) { t = dur; pause(); t0 = dur }
      show(t)
      if (playing) raf = requestAnimationFrame(loop)
    }
    const play = () => {
      if (t0 >= dur - 1 / FPS) t0 = 0
      playing = true
      document.documentElement.classList.add('film-playing')
      clock0 = performance.now()
      if (audioOk) {
        try { audio.currentTime = t0 } catch {}
        audio.play().catch(() => { audioOk = false })
      }
      raf = requestAnimationFrame(loop)
    }
    const pause = () => {
      if (playing) t0 = now()
      playing = false
      document.documentElement.classList.remove('film-playing')
      audio.pause()
      cancelAnimationFrame(raf)
    }
    const jump = (t) => {
      t0 = clamp(t, 0, dur)
      if (playing) { clock0 = performance.now(); if (audioOk) try { audio.currentTime = t0 } catch {} }
      show(t0)
    }
    btn.addEventListener('click', () => (playing ? pause() : play()))
    scrub.addEventListener('input', () => jump(Number(scrub.value)))
    root.addEventListener('keydown', (e) => {
      if (e.code === 'Space') { e.preventDefault(); playing ? pause() : play() }
      else if (e.code === 'ArrowRight') { e.preventDefault(); jump(now() + (e.shiftKey ? 1 : 1 / FPS)) }
      else if (e.code === 'ArrowLeft') { e.preventDefault(); jump(now() - (e.shiftKey ? 1 : 1 / FPS)) }
      else if (e.code === 'Home') { e.preventDefault(); jump(0) }
    })
    const start = Number(query.get('t'))
    jump(Number.isFinite(start) && start > 0 ? start : 0)
  }

  // ------------------------------------------------------------------ the contract

  const api = {
    fps: FPS,
    ready,
    seek,
    get duration() { return state.duration },
    get cues() { return state.cues.map((c) => Object.assign({}, c)) },
    get shots() { return state.shotList.map((s) => Object.assign({}, s)) },
  }
  if (hasDOM) root.__film = api

  Object.assign(FILM, {
    version: '1.0.0',
    W, H, fps: FPS,
    exportMode: EXPORT,
    base: BASE,
    asset: (p) => BASE + 'assets/' + p,
    at, end, lastWord,
    film, shots, over, cue, layer, presence,
    ease, easeFn, ramp, mix, clamp, random, drift,
    fail, warn,
    norm,
    findPhrase,
    _build: build,
    _state: state,
  })
  // Live values. (Object.assign would copy a getter's value once, at load, and FILM.errors would
  // then read [] for ever: a page with errors reporting none.)
  const live = (get) => ({ get, enumerable: true, configurable: true })
  Object.defineProperties(FILM, {
    duration: live(() => state.duration),
    errors: live(() => state.errors.slice()),
    warnings: live(() => state.warnings.slice()),
    cues: live(() => state.cues.map((c) => Object.assign({}, c))),
    t: live(() => state.t),
  })
})(typeof window !== 'undefined' ? window : globalThis)
