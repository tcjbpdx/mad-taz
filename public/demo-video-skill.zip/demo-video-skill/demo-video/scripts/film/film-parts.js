/* film-parts.js: the pictures a film page is made of. Load it after film-core.js.
 *
 * Every function here returns a LAYER for FILM.shots([...]) or FILM.over([...]).
 * A layer builds its elements once (mount), learns the sizes of its pictures
 * once they have decoded (layout), and from then on seek(t) works out every
 * position, size and opacity from t alone. Nothing here starts a timer, an
 * animation or a transition.
 *
 *   screen(src, opts)     an app screenshot in a desk window or a phone outline
 *   pointer(opts)         a mouse arrow that travels and clicks
 *   spotlight(opts)       dims everything except one box on a screen
 *   chip(text, opts)      a big caption
 *   title(text, opts)     a big title with an optional second line
 *   caption(text, opts)   a subtitle strip along the bottom
 *   card(opts)            the title card and the end card: logo, name, one line
 *   FILM.box(stillId, name), FILM.still(stillId)
 *
 * README.md beside this file explains how the director uses them.
 */
(function (root) {
  'use strict'

  const FILM = root.FILM
  if (!FILM || typeof FILM.layer !== 'function') throw new Error('film-parts.js needs film-core.js loaded before it')
  const { W, H, ramp, mix, clamp, easeFn, layer, presence } = FILM
  const ease = FILM.ease
  const fail = (m) => FILM.fail(m)
  const warn = (m) => FILM.warn(m)
  /** An ease name that does not exist is a load error where it is written, not on the first frame that reaches it. */
  const checkEase = (e, where) => {
    if (e != null && typeof e !== 'function' && !ease[e]) fail(where + ': unknown ease "' + e + '"; use one of ' + Object.keys(ease).join(', ') + ' or a function')
  }
  const checkEases = (list, where) => (Array.isArray(list) ? list : []).forEach((k, i) => checkEase(k && k.ease, where + ' ' + (i + 1)))

  // ------------------------------------------------------------------ DOM helpers

  function el(tag, cls, parent) {
    const e = document.createElement(tag)
    if (cls) e.className = cls
    if (parent) parent.appendChild(e)
    return e
  }

  function picture(src, cls, parent) {
    const i = el('img', cls, parent)
    i.alt = ''
    i.draggable = false
    i.decoding = 'sync'
    i.loading = 'eager'
    i.src = src
    return i
  }

  /** Set a style property only when its value changes. */
  function css(e, prop, value) {
    const memo = e.__filmCss || (e.__filmCss = {})
    const v = String(value)
    if (memo[prop] === v) return
    memo[prop] = v
    e.style[prop] = v
  }
  const show = (e, on) => css(e, 'display', on ? '' : 'none')
  const r3 = (v) => String(Math.round(v * 1000) / 1000)
  const px = (v) => r3(v) + 'px'
  const size = (e, w, h) => { e.style.width = w + 'px'; e.style.height = h + 'px' }
  const isNum = (v) => typeof v === 'number' && Number.isFinite(v)


  // ------------------------------------------------------------------ cameras

  /** Interpolate camera keys { t, S, tx, ty, ease }: scale moves in log space and the point in the
   *  middle of the frame moves in a straight line, so a push feels even and a pan does not swing. */
  function camAt(keys, t) {
    if (!keys.length) return { S: 1, tx: 0, ty: 0 }
    if (!(t > keys[0].t)) return keys[0]
    for (let i = 1; i < keys.length; i++) {
      const b = keys[i]
      if (t < b.t) {
        const a = keys[i - 1]
        const u = easeFn(b.ease)(ramp(t, a.t, b.t))
        const S = Math.exp(mix(Math.log(a.S), Math.log(b.S), u))
        const lx = mix((W / 2 - a.tx) / a.S, (W / 2 - b.tx) / b.S, u)
        const ly = mix((H / 2 - a.ty) / a.S, (H / 2 - b.ty) / b.S, u)
        return { S, tx: W / 2 - S * lx, ty: H / 2 - S * ly }
      }
    }
    return keys[keys.length - 1]
  }

  // A change on a word should be visible no later than 0.25 s after the word starts.
  // A camera move is plainly under way once the frame's corners have moved 30 stage px (a 2.7%
  // zoom about the middle, or a 30 px pan).
  const CUE_SHOWS_BY = 0.25
  const CUE_SHOWS_PX = 30

  /** How far the frame's corners move (stage px, the largest of the four) from camera a to camera b. */
  function camShift(a, b) {
    let m = 0
    for (const q of [[0, 0], [W, 0], [0, H], [W, H]]) {
      const x = (b.S / a.S) * (q[0] - a.tx) + b.tx - q[0]
      const y = (b.S / a.S) * (q[1] - a.ty) + b.ty - q[1]
      m = Math.max(m, Math.hypot(x, y))
    }
    return m
  }

  /** A camera move that starts on a FILM.cue() carries that cue, so it must show by 0.25 s: warn when it does not.
   *  (Cues that are shot or layer starts are carried by the shot or layer, so they are not asked of the camera.) */
  function checkCueMoves(keys, what, cameraAt) {
    const cues = FILM.cues.filter((c) => c.kind === 'cue')
    for (let i = 1; i < keys.length; i++) {
      const a = keys[i - 1]
      const b = keys[i]
      const c = cues.find((x) => Math.abs(x.t - a.t) < 1e-6)
      if (!c || !(b.t > a.t)) continue
      if (camShift(cameraAt(a.t), cameraAt(b.t)) < 1) continue // a hold, not a move: the cue is carried by something else
      const by = Math.min(b.t, a.t + CUE_SHOWS_BY)
      const moved = camShift(cameraAt(a.t), cameraAt(by))
      if (moved < CUE_SHOWS_PX) {
        warn(what + ': the camera move on the cue "' + c.label + '" (' + a.t.toFixed(2) + ' s) has moved ' +
          Math.round(moved) + ' px by ' + by.toFixed(2) + ' s, under the ' + CUE_SHOWS_PX + ' px that plainly shows; a change on a word must show within ' +
          CUE_SHOWS_BY + ' s. Give the key at ' + b.t.toFixed(2) + ' s ease: \'land\' (or \'out\', or \'gentle\' for a long move).')
      }
    }
  }

  // ------------------------------------------------------------------ stills

  function stillsData() {
    const s = root.FILM_STILLS
    return s && Array.isArray(s.stills) ? s : null
  }

  /** The stills.js entry for a still id. */
  function still(id) {
    const data = stillsData()
    const hit = data && data.stills.find((x) => x.id === id)
    if (!hit) {
      fail('no still "' + id + '" (' + (data ? 'the stills are ' + data.stills.map((x) => x.id).join(', ') : 'stills.js holds no stills') + ')')
      return null
    }
    return hit
  }

  /** A named box from stills.js: { x, y, w, h } in the still's CSS px. */
  function box(stillId, name) {
    const s = still(stillId)
    if (!s) return { x: 0, y: 0, w: 0, h: 0 }
    const b = s.boxes && s.boxes[name]
    if (!b) {
      fail('still "' + stillId + '" has no box "' + name + '" (its boxes: ' + Object.keys(s.boxes || {}).join(', ') + ')')
      return { x: 0, y: 0, w: 0, h: 0 }
    }
    return { x: b.x, y: b.y, w: b.w, h: b.h }
  }

  // ------------------------------------------------------------------ screen

  const DESK_BAR = 34
  const DESK_RADIUS = 14

  function stillEntry(item, o) {
    // A still id, a path to an image, or { t, still } / { t, src }.
    const spec = typeof item === 'string' ? (/[./]/.test(item) ? { src: item } : { still: item }) : Object.assign({}, item)
    if (spec.still) {
      const s = still(spec.still)
      spec.data = s
      spec.src = (o.stillsDir || 'stills/') + (s ? s.file : spec.still + '.png')
      if (s && s.viewport) { spec.cssW = s.viewport.w; spec.cssH = s.viewport.h }
      if (s && s.dpr) spec.dpr = s.dpr
    }
    spec.t = spec.t != null ? Number(spec.t) : -Infinity
    return spec
  }

  /**
   * screen(src, { device, width, height, x, y, zoom, scroll, blend, caption, stills })
   *   src     a still id from stills.js, an image path, or a sequence [{ t, still | src }]
   *           (each still shows from its t: a click that opens a new screen is a new still)
   *   device  'desk' (default): a clean app window, rounded, with a slim neutral title bar and no
   *           browser chrome, 90% of the frame wide. 'phone': a phone outline with a camera island,
   *           and an optional caption beside it (caption: 'words').
   *   zoom    [{ t, scale, at: [x, y] | box: 'name', ease }]: the camera on the screen
   *           (still CSS px); scale 1 = the window as laid out.
   *   scroll  [{ t, y, ease }]: scroll the still inside the window (still CSS px).
   *   width   desk window width in stage px (default 1728); height: phone screen height (default 900).
   *   x, y    shift from the centre (stage px).
   */
  function screen(src, o) {
    o = o || {}
    const device = o.device || 'desk'
    if (device !== 'desk' && device !== 'phone') fail('screen(): device must be "desk" or "phone", not "' + device + '"')
    checkEases(o.zoom, 'screen: zoom key')
    checkEases(o.scroll, 'screen: scroll key')
    const seq = (Array.isArray(src) ? src : [src]).map((it) => stillEntry(it, o)).sort((a, b) => a.t - b.t)
    let group, view, scrollBox, caption
    const imgs = []
    let lay = null // the layout: where the content sits on the stage at zoom 1
    let zoomKeys = null
    const L = layer('screen', o, {
      device,
      mount(parent) {
        const wrap = el('div', 'film-screen film-' + device, parent)
        group = el('div', 'film-screen-group', wrap)
        if (device === 'desk') {
          const win = el('div', 'film-win', group)
          const bar = el('div', 'film-win-bar', win)
          for (let i = 0; i < 3; i++) el('span', 'film-win-dot', bar)
          view = el('div', 'film-win-view', win)
          L.win = win
          L.bar = bar
        } else {
          const body = el('div', 'film-phone-body', group)
          for (const b of ['action', 'up', 'down', 'power']) el('div', 'film-phone-btn film-phone-btn-' + b, body)
          view = el('div', 'film-phone-glass', body)
          L.body = body
        }
        scrollBox = el('div', 'film-screen-scroll', view)
        for (const s of seq) imgs.push(picture(s.src, 'film-screen-img', scrollBox))
        if (device === 'phone' && typeof o.caption === 'string' && o.caption) {
          caption = el('div', 'film-chip film-phone-caption', wrap)
          el('div', 'film-chip-text', caption).textContent = o.caption
        }
        L.el = wrap
        L.surface = view
      },
      layout() {
        seq.forEach((s, i) => {
          const im = imgs[i]
          const dpr = s.dpr || (s.cssW ? im.naturalWidth / s.cssW : 1)
          s.cssW = s.cssW || im.naturalWidth / dpr
          s.fullH = im.naturalHeight / dpr // the whole still, which may be taller than the viewport
          s.cssH = s.cssH || s.fullH
        })
        const first = seq[0]
        if (device === 'desk') {
          const winW = o.width || Math.round(W * 0.9)
          const k = winW / first.cssW
          const bar = o.bar === false ? 0 : DESK_BAR
          const maxView = (o.maxHeight || H - 2 * (o.margin != null ? o.margin : 28)) - bar
          const viewH = Math.min(first.cssH * k, maxView)
          const winH = bar + viewH
          const left = (W - winW) / 2 + (o.x || 0)
          const top = (H - winH) / 2 + (o.y || 0)
          lay = { k, left, top, contentLeft: left, contentTop: top + bar, w: winW, h: winH, viewH }
          Object.assign(L.win.style, { left: px(left), top: px(top), width: px(winW), height: px(winH), borderRadius: px(DESK_RADIUS) })
          if (bar) L.bar.style.height = px(bar)
          else L.bar.style.display = 'none'
          size(view, winW, viewH)
        } else {
          const screenH = o.height || 900
          const k = screenH / first.cssH
          const gw = first.cssW * k
          const gh = screenH
          const cx = W / 2 + (o.x || 0)
          const cy = H / 2 + (o.y || 0)
          const left = cx - gw / 2
          const top = cy - gh / 2
          lay = { k, left, top, contentLeft: left, contentTop: top, w: gw, h: gh, viewH: gh }
          const u = gw / 393 // the outline is drawn in the 393 x 852 point grid of an iPhone 15
          Object.assign(L.body.style, { left: px(left), top: px(top), width: px(gw), height: px(gh), borderRadius: px(54 * u) })
          L.body.style.boxShadow = '0 0 0 ' + px(10 * u) + ' #1e293b, 0 0 0 ' + px(13 * u) + ' #0f172a, 0 ' + px(40 * u) + ' ' + px(90 * u) + ' rgba(0,0,0,0.55)'
          Object.assign(view.style, { width: px(gw), height: px(gh), borderRadius: px(54 * u) })
          const island = el('div', 'film-phone-island', view)
          Object.assign(island.style, { width: px(126 * u), height: px(34 * u), top: px(12 * u), left: px(gw / 2 - 63 * u), borderRadius: px(17 * u) })
          const btn = (name, side, y, h) => {
            const b = L.body.querySelector('.film-phone-btn-' + name)
            Object.assign(b.style, { top: px(y * u), height: px(h * u), width: px(4 * u), borderRadius: px(2 * u) })
            b.style[side] = px(-17 * u)
          }
          btn('action', 'left', 118, 32)
          btn('up', 'left', 176, 62)
          btn('down', 'left', 250, 62)
          btn('power', 'right', 210, 100)
          if (caption) {
            const right = o.captionSide === 'left' ? null : left + gw + 13 * u + 72
            caption.style.top = px(cy)
            if (right != null) { caption.style.left = px(right); caption.style.transform = 'translate(0,-50%)' }
            else { caption.style.left = px(left - 13 * u - 72); caption.style.transform = 'translate(-100%,-50%)' }
          }
        }
        seq.forEach((s, i) => size(imgs[i], s.cssW * lay.k, s.fullH * lay.k))
        L.layoutBox = lay
        zoomKeys = null
        L.cameraAt(0) // builds the zoom keys now, so a zoom that misses its cue warns at load
      },
      seek(t, span) {
        const c = L.cameraAt(t)
        css(group, 'transform', 'translate(' + c.tx + 'px,' + c.ty + 'px) scale(' + c.S + ')')
        css(scrollBox, 'transform', 'translateY(' + px(-L.scrollAt(t) * lay.k) + ')')
        const cur = L.indexAt(t)
        const blend = o.blend || 0
        seq.forEach((s, i) => {
          let a = i === cur ? 1 : 0
          if (blend > 0 && i === cur && i > 0) a = ramp(t, s.t, s.t + blend)
          if (blend > 0 && i === cur - 1 && t < seq[cur].t + blend) a = 1
          show(imgs[i], a > 0)
          css(imgs[i], 'opacity', r3(a))
        })
        if (caption) css(caption, 'opacity', r3(presence(t, span.from, span.to, 0.3, 0.25)))
      },
      /** Which still is showing at t. */
      indexAt(t) {
        let cur = 0
        for (let i = 0; i < seq.length; i++) if (t >= seq[i].t - 1e-9) cur = i
        return cur
      },
      scrollAt(t) {
        const ks = (o.scroll || []).map((k) => ({ t: Number(k.t), y: Number(k.y), ease: k.ease }))
        if (!ks.length) return 0
        if (!(t > ks[0].t)) return ks[0].y
        for (let i = 1; i < ks.length; i++) if (t < ks[i].t) return mix(ks[i - 1].y, ks[i].y, easeFn(ks[i].ease || 'inOut')(ramp(t, ks[i - 1].t, ks[i].t)))
        return ks[ks.length - 1].y
      },
      /** A named box in the still showing at t (or any still of this screen that has it). */
      boxAt(name, t) {
        const order = [seq[L.indexAt(t)]].concat(seq)
        for (const s of order) if (s.data && s.data.boxes && s.data.boxes[name]) return s.data.boxes[name]
        fail('screen: no still here has a box "' + name + '"')
        return { x: 0, y: 0, w: 0, h: 0 }
      },
      /** A point of the still (CSS px) on the stage at time t, through the scroll and the zoom. */
      toStage(p, t) {
        const P = [lay.contentLeft + p[0] * lay.k, lay.contentTop + (p[1] - L.scrollAt(t)) * lay.k]
        const c = L.cameraAt(t)
        return [c.S * P[0] + c.tx, c.S * P[1] + c.ty]
      },
      cameraAt(t) {
        if (!zoomKeys) {
          zoomKeys = (o.zoom || []).map((z) => {
            const S = Number(z.scale != null ? z.scale : 1)
            let k
            if (z.at || z.box) {
              const b = z.box ? L.boxAt(z.box, Number(z.t)) : null
              const p = b ? [b.x + b.w / 2, b.y + b.h / 2] : z.at
              const P = [lay.contentLeft + p[0] * lay.k, lay.contentTop + (p[1] - L.scrollAt(Number(z.t))) * lay.k]
              k = { S, tx: W / 2 - S * P[0], ty: H / 2 - S * P[1] }
            } else k = { S, tx: (1 - S) * (W / 2), ty: (1 - S) * (H / 2) }
            return Object.assign(clampZoom(k), { t: Number(z.t), ease: z.ease || 'inOut' })
          })
          checkCueMoves(zoomKeys, 'screen ' + (o.id || 'zoom'), (u) => clampZoom(camAt(zoomKeys, u)))
        }
        return zoomKeys.length ? clampZoom(camAt(zoomKeys, t)) : { S: 1, tx: 0, ty: 0 }
      },
    })
    function clampZoom(c) {
      // A zoom never leaves the window hanging half off the frame: while it is smaller than the
      // frame it stays wholly inside it, and once it is bigger its edges stay out of the frame.
      // (Aiming a small zoom at a box near one side therefore moves it less than asked: zoom
      // further, past the frame, to bring that side in.)
      if (o.clamp === false || !lay) return c
      let { tx, ty } = c
      const x0 = c.S * lay.left
      const x1 = c.S * (lay.left + lay.w)
      tx = x1 - x0 >= W ? clamp(tx, W - x1, -x0) : clamp(tx, -x0, W - x1)
      const y0 = c.S * lay.top
      const y1 = c.S * (lay.top + lay.h)
      ty = y1 - y0 >= H ? clamp(ty, H - y1, -y0) : clamp(ty, -y0, H - y1)
      return { S: c.S, tx, ty }
    }
    return L
  }

  // ------------------------------------------------------------------ pointer

  // A macOS arrow, drawn at 2x: black with a white rim. Its tip is the hot spot.
  const ARROW = '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="58" viewBox="0 0 20 29">' +
    '<path d="M1.5 1.5 L1.5 22.6 L6.4 17.9 L9.9 26.3 L13.6 24.7 L10.1 16.6 L16.8 16.6 Z" fill="#0b0b0b" stroke="#ffffff" stroke-width="1.5" stroke-linejoin="round"/></svg>'
  const HOT = [3, 3]
  const TOUCH_HOT = [30, 30] // the centre of the 60 px fingertip in film.css

  /**
   * pointer({ screen, path, clicks, from, to, arc })
   *   path    [{ t, at: [x, y] | box: 'name', ax, ay, stage: [x, y], screen }]: where the pointer is at
   *           each time. at/box are in the screen's still CSS px (through its zoom and scroll);
   *           stage is stage px. Between points it travels on an eased, gently curved path.
   *   clicks  [t, ...]: a press and a ripple. A click on at(...) is listed as a cue.
   *   touch   true: a fingertip instead of a mouse arrow (for phone screens).
   */
  function pointer(o) {
    o = o || {}
    const path = (o.path || []).slice().sort((a, b) => a.t - b.t)
    const clicks = (o.clicks || []).map(Number)
    if (!path.length) fail('pointer(): give it a path [{ t, at | box | stage }]')
    checkEases(path, 'pointer: path point')
    let wrap, arrow
    const rings = []
    const L = layer('pointer', o, {
      from: o.from != null ? o.from : path[0] && path[0].t,
      to: o.to,
      mount(parent) {
        wrap = el('div', 'film-pointer-layer', parent)
        for (let i = 0; i < clicks.length; i++) rings.push(el('div', 'film-ripple', wrap))
        arrow = el('div', o.touch ? 'film-pointer film-touch' : 'film-pointer', wrap)
        if (!o.touch) arrow.innerHTML = ARROW
        L.el = wrap
      },
      cueTimes() { return clicks },
      seek(t, span) {
        const a = presence(t, span.from, span.to, 0.24, 0.2)
        if (a <= 0) { show(wrap, false); return }
        show(wrap, true)
        css(wrap, 'opacity', r3(a))
        const p = L.positionAt(t)
        let press = 1
        for (const c of clicks) {
          if (t >= c - 0.06 && t < c + 0.2) press = Math.min(press, t < c ? mix(1, 0.86, ramp(t, c - 0.06, c)) : mix(0.86, 1, ease.out(ramp(t, c, c + 0.2))))
        }
        const hot = o.touch ? TOUCH_HOT : HOT
        css(arrow, 'transform', 'translate(' + px(p[0] - hot[0]) + ',' + px(p[1] - hot[1]) + ') scale(' + r3(press) + ')')
        clicks.forEach((c, i) => {
          const r = rings[i]
          const u = ramp(t, c, c + 0.5)
          if (t < c || u >= 1) { show(r, false); return }
          show(r, true)
          const q = L.positionAt(c)
          const rad = mix(8, 46, ease.out(u))
          css(r, 'transform', 'translate(' + px(q[0] - rad) + ',' + px(q[1] - rad) + ')')
          css(r, 'width', px(2 * rad))
          css(r, 'height', px(2 * rad))
          css(r, 'opacity', r3(0.95 * (1 - ease.in(u))))
        })
      },
      positionAt(t) {
        if (!(t > path[0].t)) return point(path[0], t)
        for (let i = 1; i < path.length; i++) {
          const B = path[i]
          if (t < B.t) {
            const A = path[i - 1]
            const pa = point(A, t)
            const pb = point(B, t)
            const u = easeFn(B.ease || 'inOut')(ramp(t, A.t, B.t))
            const dx = pb[0] - pa[0]
            const dy = pb[1] - pa[1]
            const bend = Math.sin(Math.PI * u) * (o.arc != null ? o.arc : 0.08)
            return [mix(pa[0], pb[0], u) - dy * bend, mix(pa[1], pb[1], u) + dx * bend]
          }
        }
        return point(path[path.length - 1], t)
      },
    })
    function point(pt, t) {
      const scr = pt.screen || o.screen
      if (pt.stage) return pt.stage
      if (pt.box) {
        if (!scr) { fail('pointer(): a path point names box "' + pt.box + '" but no screen'); return [W / 2, H / 2] }
        const b = scr.boxAt(pt.box, pt.t)
        return scr.toStage([b.x + b.w * (pt.ax != null ? pt.ax : 0.5), b.y + b.h * (pt.ay != null ? pt.ay : 0.55)], t)
      }
      if (pt.at) return scr ? scr.toStage(pt.at, t) : pt.at
      fail('pointer(): a path point needs at, box or stage')
      return [W / 2, H / 2]
    }
    return L
  }

  // ------------------------------------------------------------------ spotlight

  /**
   * spotlight({ screen, box: 'name' | rect: [x, y, w, h] (still px) | stage: [x, y, w, h], from, to, dim, pad, radius })
   * `on: app` is taken as `screen: app`: the dimming covers the whole stage, so it never mounts inside the window.
   */
  function spotlight(o) {
    o = Object.assign({}, o)
    if (o.on && !o.screen) o.screen = o.on
    delete o.on
    const aimed = !!(o.stage || (o.screen && (o.box || o.rect)))
    if (!aimed) fail('spotlight(): give it a screen and a box or rect, or a stage rect [x, y, w, h]')
    let hole
    const L = layer('spotlight', o, {
      mount(parent) {
        hole = el('div', 'film-spotlight', parent)
        L.el = hole
      },
      seek(t, span) {
        const a = aimed ? presence(t, span.from, span.to, 0.3, 0.3) : 0
        if (a <= 0) { show(hole, false); return }
        show(hole, true)
        let r
        if (o.stage) r = o.stage
        else {
          const scr = o.screen
          const b = o.box ? scr.boxAt(o.box, t) : { x: o.rect[0], y: o.rect[1], w: o.rect[2], h: o.rect[3] }
          const p0 = scr.toStage([b.x, b.y], t)
          const p1 = scr.toStage([b.x + b.w, b.y + b.h], t)
          r = [p0[0], p0[1], p1[0] - p0[0], p1[1] - p0[1]]
        }
        const pad = o.pad != null ? o.pad : 12
        css(hole, 'left', px(r[0] - pad))
        css(hole, 'top', px(r[1] - pad))
        css(hole, 'width', px(r[2] + 2 * pad))
        css(hole, 'height', px(r[3] + 2 * pad))
        css(hole, 'borderRadius', px(o.radius != null ? o.radius : 14))
        css(hole, 'boxShadow', '0 0 0 4000px rgba(2,6,23,' + r3((o.dim != null ? o.dim : 0.6) * a) + ')')
      },
    })
    return L
  }

  // ------------------------------------------------------------------ words on screen

  const PLACES = {
    bottom: [W / 2, 930], top: [W / 2, 150], center: [W / 2, H / 2], centre: [W / 2, H / 2],
    left: [W * 0.27, H / 2], right: [W * 0.73, H / 2], 'lower-left': [W * 0.27, 900], 'lower-right': [W * 0.73, 900],
  }
  const placeOf = (at, dflt) => (Array.isArray(at) ? at : PLACES[at || dflt] || PLACES[dflt])

  /** Fade in and rise, centred on `from` the way the contract asks ([from - 0.10, from + 0.20]); fade out by `to`. */
  function words(kind, build, o, dflt, rise) {
    let box
    const L = layer(kind, o, {
      mount(parent) {
        box = build(parent)
        L.el = box
      },
      seek(t, span) {
        const a = presence(t, span.from, span.to, 0.3, 0.25)
        if (a <= 0) { show(box, false); return }
        show(box, true)
        const p = placeOf(o.at, dflt)
        const up = (1 - ease.out(ramp(t, span.from - 0.1, span.from + 0.35))) * rise
        css(box, 'opacity', r3(a))
        css(box, 'transform', 'translate(' + px(p[0]) + ',' + px(p[1] + up) + ') translate(-50%,-50%)')
      },
    })
    return L
  }

  /** chip(text, { from, to, at, size }): a big caption on the picture. Never a bordered card. */
  function chip(text, o) {
    o = o || {}
    return words('chip', (parent) => {
      const b = el('div', 'film-chip', parent)
      const tx = el('div', 'film-chip-text', b)
      tx.textContent = text
      if (o.size) tx.style.fontSize = px(o.size)
      return b
    }, o, 'bottom', 14)
  }

  /** title(text, { sub, from, to, at, size }): a big title, with an optional second line. */
  function title(text, o) {
    o = o || {}
    return words('title', (parent) => {
      const b = el('div', 'film-title', parent)
      const t1 = el('div', 'film-title-main', b)
      t1.textContent = text
      if (o.size) t1.style.fontSize = px(o.size)
      if (o.sub) el('div', 'film-title-sub', b).textContent = o.sub
      return b
    }, o, 'center', 18)
  }


  // ------------------------------------------------------------------ captions and cards

  /** caption(text, { from, to }): a subtitle strip along the bottom of the frame. It never moves; it fades in and out. */
  function caption(text, o) {
    o = o || {}
    let box
    const L = layer('caption', o, {
      mount(parent) {
        box = el('div', 'film-caption', parent)
        el('div', 'film-caption-text', box).textContent = text
        L.el = box
      },
      seek(t, span) {
        const a = presence(t, span.from, span.to, 0.18, 0.15)
        if (a <= 0) { show(box, false); return }
        show(box, true)
        css(box, 'opacity', r3(a))
      },
    })
    return L
  }

  /**
   * card({ name, line, logo, from, to }): the title card and the end card. The app's
   * name large, one line under it, and its logo above when there is one, on the
   * backdrop tinted with the accent colour. It settles in on its first second and
   * then grows very slowly, so it is never a frozen picture.
   */
  function card(o) {
    o = o || {}
    let ground, group
    const L = layer('card', o, {
      mount(parent) {
        ground = el('div', 'film-card', parent)
        group = el('div', 'film-card-group', ground)
        if (o.logo) picture(o.logo, 'film-card-logo', group)
        if (o.name) el('div', 'film-card-name', group).textContent = o.name
        if (o.line) el('div', 'film-card-line', group).textContent = o.line
        L.el = ground
      },
      seek(t, span) {
        if (t < span.from - 0.1 - 1e-9 || (isNum(span.to) && t >= span.to - 1e-9)) { show(ground, false); return }
        show(ground, true)
        const end = isNum(span.to) ? span.to : span.end
        const a = ramp(t, span.from - 0.1, span.from + 0.45, 'smooth')
        const s = mix(0.965, 1, ease.out(ramp(t, span.from - 0.1, span.from + 0.9))) + 0.015 * ramp(t, span.from + 0.9, end)
        const up = (1 - ease.out(ramp(t, span.from - 0.1, span.from + 0.7))) * 16
        css(group, 'opacity', r3(a))
        css(group, 'transform', 'translate(-50%,-50%) translateY(' + px(up) + ') scale(' + r3(s) + ')')
      },
    })
    return L
  }

  Object.assign(FILM, { screen, pointer, spotlight, chip, title, caption, card, box, still })
})(typeof window !== 'undefined' ? window : globalThis)
