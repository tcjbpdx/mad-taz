---
name: demo-video
description: Use when someone wants a demo video, product walkthrough, explainer or promo video of their web app. Writes the script from the app's real screens, shows a storyboard for approval, records the narration (free Mac voice or Google voice), films the app with camera moves and a pointer, and makes a checked 1920×1080 MP4 with captions. Mac only; the app must open in a web browser.
---

# Demo video

You are making a narrated demo video of the person's web app. They may not be technical: talk
in plain words, never paste code or file paths at them unless they ask, and do the typing for
them. Ask questions with pop-up choices (the AskUserQuestion tool) wherever you can.

Every step is one command, run from the project's top folder:

```
node .claude/skills/demo-video/scripts/demo.mjs <step>
```

Below, `demo <step>` means that command. Each step prints what happened in plain words and ends
with an exit code: **0** done · **1** something broke (the message says what) · **2** it needs
the person (approve the script, add a key, sign in) · **3** a check failed (the message lists
each thing to fix). Read the whole message before deciding what to do.

## The rules that matter most

1. **Never open, read, print or search `demo-video/private.env`.** It holds their test account
   and voice key, one per line: `APP_TEST_EMAIL`, `APP_TEST_PASSWORD`, `GOOGLE_VOICE_KEY` and
   `NEVER_SHOW` (private words to keep off screen). Don't `cat` it, `grep` it, echo environment
   variables, or read it to "check" it: the doctor step checks it without showing it. When they
   need to fill it in, open it for them in TextEdit with `open -e demo-video/private.env`, tell
   them which line to fill (type after the `=`, then Cmd+S), and wait for them to say it's saved.
   Never ask them to paste a password or key into the chat. If they paste one anyway, don't
   repeat it back: pipe it into `demo set-private`, which writes that one line without showing
   it, then suggest they replace that key later because it has been in a chat.

   ```
   node .claude/skills/demo-video/scripts/demo.mjs set-private APP_TEST_PASSWORD <<'VALUE'
   (the pasted value, exactly as they sent it)
   VALUE
   ```
2. **Nothing is recorded until the script says `Status: APPROVED`.** Only they can approve it,
   by saying so or by editing the line themselves. If any **Say** words change after approval
   (yours or theirs), set the line back to `Status: DRAFT` and ask again. Changes to Show, Do,
   Point at, Click, Zoom or Tone don't need a new approval.
3. **Never script a risky click.** No delete, remove, pay, buy, checkout, send, invite, publish,
   share, transfer or sign-out buttons in Do or Click lines. The tools refuse them anyway (unless
   the person lists one under safety → ok_to_click). A real browser really clicks their app:
   tell them to use a **test account with tidy, made-up data**, because everything in it can
   appear in the video.
4. **Never publish or upload the video anywhere.** It stays in their output folder. Never delete
   an earlier cut.
5. Big files (pictures, sound, videos) stay in `demo-video/output/`, which is kept out of git.

## First time in a project

1. **Setup.** If `.claude/skills/demo-video/node_modules` is missing, run `demo setup` (a few
   minutes; it downloads about 300 MB, a private browser and a video maker, which take about
   650 MB once unpacked). If Node is missing or too old, tell them to install it from nodejs.org
   (Download → macOS Installer, opened from Downloads; it asks for their Mac's own password,
   which is normal), then start Claude Code fresh.
2. **Start the folder.** If there is no `demo-video/` folder, run `demo new`. It makes
   `settings.yaml`, `script.md` and `private.env`, and adds the private file and output folder to
   `.gitignore`.
3. **Fill in `demo-video/settings.yaml` for them.** First work out what you can from the project
   itself: the app's name, the address its dev server runs on, how sign-in works, the main
   pages. Then ask the rest in one pop-up round (up to four questions). Good questions:
   - What the video is for and who will watch it (fills `audience` and shapes the script).
   - The three or four things to show off, most important first (`features_to_show`).
   - How long: 30 s, about 60 s (recommended), or 90 s (`video_length_seconds`).
   - The voice: the free Mac voice (recommended to start), or a Google voice (more natural,
     needs their own Google AI Studio key, costs a little per video). Tell them the Mac voice is
     for practice and private videos: Apple's licence allows its built-in voices for personal,
     non-commercial use only, so a video they'll publish, share publicly or use for a business
     needs the Google voice. If they've said that's what the video is for, recommend Google.

   Sign-in: `form` when the app has an email and password form (they put a **test** account in
   private.env); `by-hand` for Google, Apple, magic-link or code sign-ins (run `demo sign-in`:
   a window opens and they sign in once); `none` when there is no sign-in.

   Words that must never appear on screen go in `never_show`. Personal ones (their own real
   email address, their surname) go on the private file's `NEVER_SHOW` line instead, commas
   between them, so they never sit in a file that gets shared. They fill that line in like the
   password.
4. **Start their app** if `app_url` is on this computer and it isn't running. Use their usual
   dev command in the background, and stop it when you are done.
5. **Run `demo doctor`.** It checks everything in order and stops at the first thing to fix,
   with the fix spelled out. Do the fix (or walk them through it), then run it again until it
   says "Everything is ready."

## Making the video

1. **Look around:** `demo look`. It walks their app without clicking anything, saves a picture
   of each page in `demo-video/output/look/`, and writes `pages.md` with each page's headings,
   buttons, links, boxes, lists and switches, word for word. Other words (paragraphs, numbers,
   the names in a list) aren't in it: read those off the pictures. Read `pages.md` and look at
   the pictures before you write a word of script.
2. **Write `demo-video/script.md`.** The format is in the comment at the top of the file. Keep
   it to:
   - **Status: DRAFT** at the top.
   - **A title card and an end card,** each with one short Say line. The title card shows the
     app's name and `tagline`; the end card shows the name and `look → end_card` (or the
     tagline). Make each card's Say line agree with what it shows.
   - **One idea per scene,** and about 4 scenes for 30 s, 5 to 6 for 60 s, 7 to 8 for 90 s.
     Speech runs about 190 words a minute, and the cards and pauses take about 8 s in all.
   - **Say lines** that talk to the viewer, in short sentences: what they get, not how the
     screen works. No jargon unless their audience uses it.
   - **Words copied exactly** from `pages.md` or the pictures for every quoted button or box in
     Do, Point at, Click and Zoom. The pointer phrase (`when I say "…"`) must appear exactly
     once in that scene's Say words.
   - **Point at** also moves the camera in on that thing. To show more of the screen around it,
     add a **Zoom** line on something bigger that holds it (a card, a list), or `Zoom: none` to
     keep the whole screen.
   - **Prefer Point at to Click.** Click only when the result is worth seeing (the next picture
     shows it). A click really happens in their app: whatever it saves stays saved, later
     scenes see it, and the next run starts from what the last one left. Never click something
     that only works once.
   - **Do steps all happen before the picture is taken,** so the viewer sees the result, never
     the typing. Write Say lines about the result ("the reminder is set for Friday"), not the
     action ("type Friday into the box").
   - **Show** is just the page's address, such as `/settings`. To reach a state, add Do steps.
   - **Odd words go in `say_it_like`** in settings (brand names, abbreviations), not in the script.
3. **Storyboard:** `demo storyboard`. It takes the pictures and opens a page in their browser
   with every scene, its picture (the pointer's target outlined in red, the zoom in blue), its
   words and the estimated length. If it lists problems (exit 3), fix the script and run it
   again with `--no-open`, so it doesn't open another tab each time. `--scene 3` redoes just
   scene 3. Then look at the pictures yourself in `demo-video/output/storyboard/check/`: each
   scene's picture with its outlines drawn in. Check that each one shows what the words
   describe, that the red outline sits on the right thing, and that there are no error screens,
   empty lists, private data or loading spinners. Fix those before showing them.
4. **Ask for approval.** Tell them the storyboard is open in their browser. Ask in a pop-up:
   "Approved, record it" / "I'll make edits myself first" / "Change something (tell me)". On
   approval, change the line to `Status: APPROVED` yourself.
5. **Make it:** `demo make`. It takes fresh pictures, records the narration (only changed lines
   are recorded again), films the video and checks it. Usually a minute or two on a recent Mac
   (a 37-second video took 27 seconds in testing); an older Mac takes a few minutes. Each run makes a new folder, `demo-video/output/cut-01`, `cut-02`, and so on.
6. **Review it yourself before handing it over.** Open `contact-sheet.jpg` in the cut folder
   (one frame every few seconds) and `report.md`. Look for anything a viewer would trip over: a
   wrong page, an empty screen, a pointer aimed at the wrong thing, text cut off. If something
   is off, fix it and make a new cut.
7. **Hand it over:** run `demo watch` (it opens the video and the contact sheet), and tell them
   in two or three sentences what is in it, how long it runs, and that every check passed. If
   it used the Mac voice, remind them it's for practice: before they post it, switch to a
   Google voice and make a new cut. Ask what they'd change.

## Changing a cut

- **Words:** edit the Say lines, set `Status: DRAFT`, run `demo storyboard --scene N` for the
  changed scenes, and ask for approval again before `demo make`. Only changed lines are
  re-recorded.
- **Pictures or pointer** (Show, Do, Point at, Click, Zoom): edit and run `demo make`. No
  re-approval needed.
- **Voice:** change `voice` in settings. A new voice re-records every line.
- **Length:** cut words. The storyboard and the report both show the length against the target.
- **Fine camera work** (advanced, only if asked): copy `.claude/skills/demo-video/scripts/film/director.js`
  to `demo-video/custom/director.js` and edit it. The film engine's manual is
  `.claude/skills/demo-video/scripts/film/README.md`. `demo preview` plays the newest cut's film
  page with a play bar. Run it in the background and stop it when done.

## Coming back to it

When they say "carry on" or come back later, don't start over. Look at what already exists:
`demo-video/settings.yaml` filled in, the script's Status line, and the newest `cut-NN` folder
in `demo-video/output/`. Start their app again if it isn't answering (it stops when Claude Code
closes). Then run `demo doctor` and pick up from the first step not yet done.

## The feedback form

When they ask for help with the feedback form, read `FEEDBACK.md` beside this file. Ask its
questions a few at a time in plain chat, and save their answers in their own words as
`demo-video/feedback.md` (never inside the skill folder). Leave out any email address, password
or key-shaped text. Tell them the file's name and that it's the one to send back.

## Other steps

- `demo check`: checks the newest cut again (`--cut 2` for another), for example after adding
  a `never_show` word.
- `demo narrate`: records the narration on its own, to listen to `output/narration/narration.wav`
  before filming.
- `demo selftest`: proves each video check can catch a bad video. Run it if a check seems wrong.
- `demo doctor --voice-test`: tests the Google voice again (one short request).

## When something goes wrong

| What it says | What to do |
|---|---|
| Helpers not installed / hidden browser not downloaded | `demo setup` |
| Your app is not answering | Start their app; check `app_url` (the port especially) |
| The test account is not filled in | `open -e demo-video/private.env`; they fill in the two lines |
| It went back to the sign-in page | The test account details are wrong, or (by-hand) the saved sign-in ran out: `demo sign-in` |
| "…" is not on the page | The script's quoted words don't match the screen. Check `pages.md` or the storyboard picture; copy the exact words. |
| I used the first one | Those words appear more than once on the page. Pick words that appear once, or accept it if the first one is right. |
| A risky button was refused | Point at it instead of clicking, or leave it out |
| Block saves stopped requests | Pictures may be empty: turn `safety → block_saves` off for a private test account |
| The Google voice refused / ran out | The message says why. Google limits how many voice requests a key can make a day; each changed line is one request. Switch `voice → service` to `mac` to carry on. |
| A check failed on the video | Read the listed failures and look at the contact sheet. A long silence usually means a scene with very few words. A frozen picture usually means one scene runs over 10 seconds with nothing moving: split it. |
| The film page found a problem | Usually a pointer phrase that isn't in the Say words, or a picture that went missing. Run the storyboard again; it shows the problem per scene. |

Anything still unclear: show them the exact message, explain it in a sentence, and suggest
the fix.
