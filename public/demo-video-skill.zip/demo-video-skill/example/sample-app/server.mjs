// Fernhouse: a tiny made-up plant-care app, for trying the demo-video skill. No installs.
//   node example/sample-app/server.mjs        then open http://localhost:4321
import { createServer } from 'node:http'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const page = () => readFileSync(join(here, 'index.html'))
const port = Number(process.env.PORT) || 4321

createServer((req, res) => {
  const path = new URL(req.url, 'http://x').pathname
  if (path === '/favicon.ico') { res.writeHead(204).end(); return }
  // Every address gets the same page; the page shows the right screen for it.
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }).end(page())
}).listen(port, '127.0.0.1', () => console.log(`Fernhouse is running at http://localhost:${port} (stop it with Ctrl+C)`))
