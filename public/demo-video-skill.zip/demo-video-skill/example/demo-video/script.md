# Demo script: Fernhouse
Status: APPROVED

<!-- A finished example. Your own script starts as DRAFT, and you change it to APPROVED
     once every Say line reads right. -->

## Title card
Say: Meet Fernhouse. Plant care, without the guesswork.

## 1. Every plant at a glance
Show: /plants
Point at: "Water today" when I say "need water today"
Say: Every plant you own sits on one page, and the ones that need water today rise
straight to the top, so nothing gets forgotten.

## 2. Find any plant
Show: /plants
Do: type "fig" into "Search plants"
Point at: "Fiddle leaf fig" when I say "fiddle leaf fig"
Say: Looking for one plant? Start typing, and the fiddle leaf fig is right there.

## 3. Water with one tap
Show: /plants/monstera
Click: "Water now" when I say "one tap"
Tone: a little brighter
Say: Open a plant to see how it's doing. When the monstera is thirsty, one tap logs it,
and Fernhouse works out the next watering day for you.

## 4. The week ahead
Show: /schedule
Zoom: "This week"
Point at: "Mist the calathea" when I say "misting"
Say: The weekly schedule plans the rest: watering, misting, and the odd feed,
so your weekend stays free.

## End card
Say: Fernhouse. Try it free today.
