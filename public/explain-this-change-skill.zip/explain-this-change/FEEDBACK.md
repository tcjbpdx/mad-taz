# Feedback: Explain This Change, version 1

Thank you for trying it. Fill in whatever you can after your first few explanations. Short
answers are perfect. What you write here decides what changes in version 2.

**The easy way:** ask Claude *"Help me fill in the explain-this-change feedback form"*. It asks
you the questions a few at a time and saves your answers as `feedback.md` in your project's
`explain-this-change/` folder.

When it's done, send that file back to whoever gave you this skill.

---

**Date:**

**What you used it on (one line, no code or project names you'd rather keep private):**

**Mostly: whole pull requests, single files, or single hunks with a question?**

## Getting set up

1. Putting the skill in your project and the first `doctor` run: anything unclear or slow?

2. Did the default writer (your own Claude Code sign-in) just work? If you used an API key
   instead, why?

3. Was "What goes where" in the README enough to decide whether you could use it on your
   code? Anything you still had to work out yourself?

## The explanations

4. Did the first explanation get the change right? Anything it got wrong, or missed?

5. When you asked a question, did it answer it first, and was the answer the one you needed?

6. Did the code light up on the right lines as it was talked about? Any line that lit the
   wrong thing?

7. QUICK and DEEP DIVE: which did you use, and was each the right length?

8. The proof section: was it clear what had and hadn't been shown to work? Did it ever claim
   more than it should?

9. "Intent not stated." and the labelled reasons: helpful, or too often "not stated"?

10. The review focus at the end: did it point at what you'd actually check?

## The button, questions and saving

11. If you put the button in a review app: how long did it take, and what got in the way
    (security policy, allowed addresses, styling)?

12. Asking mid-walkthrough: did the answers fit where you were in it?

13. If you switched on saving to the pull request: was the comment useful to the rest of the
    team, or noise?

## Wishes

14. What do you wish it did that it doesn't?

15. Would you put this button in front of your own users? What would have to change first?

---

**If something broke**, paste the message Claude showed you here. Before you send it, check it
doesn't show your code, an email address, a password, or a long string of random letters and
numbers (that could be a key).
