// Hand-written answers for the practice change (Parcel Pigeon, pull request #42), in exactly the
// shape Claude is asked for. The tests use them in place of Claude, and the offline self-test plays
// them, so everything after the writer can be checked without spending anything.
//
// Every line they light up is a real line of the sample change. Line numbers are the sample's:
//   h1 carrierClient.js new 1–10 (old 1–6)      the import, TIMEOUT_MS 10s → 4s, ATTEMPTS = 3
//   h2 carrierClient.js new 14–28 (old 10–19)   isRetryable at 17–18, request() through withRetry at 20–25
//   h3 format.js new 2–8                         the carrier_busy label at 5
//   h4 retry.js new 1–19                         withRetry()
//   h5 trackingService.js new 7–16              the carrier_busy branch at 10–13
//   h6 test/retry.test.js new 1–35
//   h7 test/trackingService.test.js new 14–40 (old 14–21)
//   registerWebhook() is carrierClient.js new 37–43 — not changed, but it now goes through request().

import { NeedsYou } from '../../scripts/lib/project.mjs'

const code = (hunk, side, from, to = from) => ({ type: 'code', hunk, file: '', side, from, to, item: -1 })
const at = (file, side, from, to = from) => ({ type: 'code', hunk: '', file, side, from, to, item: -1 })
const card = (item = -1) => ({ type: 'card', hunk: '', file: '', side: 'after', from: 0, to: 0, item })
const say = (who, text, show) => ({ who, say: text, show })
const chapter = (kind, title, lines, extra = {}) => ({
  kind, title, hunks: [], before: '', after: '', why: '', why_source: '', affects: '', nodes: [], edges: [], lines, ...extra,
})

const CLIENT = 'src/carrierClient.js'

/** The whole pull request, no question. */
export function wholeScript() {
  return {
    title: 'Carrier requests retry up to three times',
    summary: 'Every carrier request now goes through a new retry helper with backoff, the per-try timeout drops to four seconds, and a carrier still failing after the last try shows a "busy" message.',
    focus_items: [
      { kind: 'risk', severity: 'high', text: 'registerWebhook() sends a POST through request(), so a webhook registration that times out is now sent again, up to three times. Nothing in the change says the carrier ignores a repeated registration.', general: false, hunk: '', file: CLIENT, side: 'after', from: 37, to: 43 },
      { kind: 'behaviour_change', severity: 'medium', text: 'A 5xx from the carrier used to show "We can\'t see this parcel right now". It now shows the carrier_busy label instead.', general: false, hunk: 'h5', file: '', side: 'after', from: 10, to: 13 },
      { kind: 'tests', severity: 'medium', text: 'The old 500 test now uses a 404, and nothing tests a POST being retried.', general: false, hunk: 'h7', file: '', side: 'after', from: 17, to: 18 },
      { kind: 'performance', severity: 'low', text: 'The worst case is three four-second tries plus two short waits, which the comment says must fit inside 15 seconds.', general: false, hunk: 'h1', file: '', side: 'after', from: 5, to: 7 },
    ],
    reasoning: [],
    quick: [
      chapter('overview', 'What changed', [
        say(0, 'This pull request makes carrier lookups ride out short outages. Every request to the carrier now goes through a retry helper that tries up to three times.', code('h2', 'after', 20, 25)),
        say(1, 'To keep the worst case inside the page\'s fifteen seconds, each try now times out after four seconds instead of ten.', code('h1', 'after', 5, 7)),
        say(0, 'One thing to check: the webhook registration is a POST, and it now retries too.', at(CLIENT, 'after', 37, 43)),
      ]),
    ],
    deep: [
      chapter('overview', 'What this pull request does', [
        say(0, 'Issue 41 says customers saw "we can\'t see this parcel" whenever the carrier had a short burst of 503s, and a refresh fixed it.', card()),
        say(1, 'So this change retries carrier requests, shortens each try, and adds a clearer message for when the carrier is still down.', card()),
      ]),
      chapter('change', 'A retry helper with backoff', [
        say(0, 'The new withRetry helper calls a function up to a set number of times.', code('h4', 'after', 5, 9)),
        say(1, 'Between tries it waits, doubling each time, plus a random bit of jitter so clients do not all retry at once.', code('h4', 'after', 13, 13)),
        say(0, 'It stops early when retryOn says an error is not worth another try, and it throws the last error when it gives up.', code('h4', 'after', 11, 16)),
      ], {
        hunks: ['h4'], before: 'No retry helper existed.', after: 'withRetry() tries up to three times, waiting longer each time, and stops early when retryOn says no.',
        why: 'So a short carrier outage does not fail the lookup.', why_source: 'commit:daf6be6', affects: 'Every carrier request (through request() in the carrier client).',
      }),
      chapter('change', 'Every carrier request retries, with a shorter timeout', [
        say(1, 'The request function now wraps the fetch in withRetry, with three attempts.', code('h2', 'after', 20, 25)),
        say(0, 'isRetryable decides what gets another try: a timeout, a dropped connection, or a carrier error of 500 or above. A 4xx answer does not.', code('h2', 'after', 17, 18)),
        say(1, 'Each try now times out after four seconds instead of ten, so three tries fit inside the tracking page\'s fifteen-second budget.', code('h1', 'after', 5, 7)),
        say(0, 'Before, there was one ten-second try.', code('h1', 'before', 3)),
      ], {
        hunks: ['h1', 'h2'], before: 'One request with a 10-second timeout; any failure went straight to the caller.', after: 'Up to three 4-second tries for 5xx answers, timeouts and dropped connections; 4xx answers are not retried.',
        why: 'Three attempts still fit inside the tracking page\'s 15-second budget.', why_source: 'pr', affects: 'lookupStatus() and registerWebhook(), which both call request().',
      }),
      chapter('change', 'A "carrier busy" message', [
        say(1, 'When the carrier is still failing after every retry, trackParcel now returns a carrier_busy status, marked retryable.', code('h5', 'after', 10, 13)),
        say(0, 'And the label for it tells the customer to try again in a minute.', code('h3', 'after', 5)),
        say(1, 'A 4xx error still falls through to the old "unknown" answer.', code('h5', 'after', 14, 16)),
      ], {
        hunks: ['h5', 'h3'], before: 'Any carrier error showed "We can\'t see this parcel right now".', after: 'A 5xx after the last retry shows "The carrier is busy. Try again in a minute"; other carrier errors still show unknown.',
        why: 'Customers were told the parcel could not be seen, when the carrier was only briefly down.', why_source: 'issue:41', affects: 'What the tracking page shows when the carrier fails.',
      }),
      chapter('change', 'Tests for the helper and the tracking service', [
        say(0, 'The helper gets its own tests: success after a failure, giving up after the last try, stopping when retryOn says no, and growing waits.', code('h6', 'after', 7, 35)),
        say(1, 'The tracking tests add a recovery after two 503s, and the busy message when every try fails.', code('h7', 'after', 23, 40)),
        say(0, 'Note that the old "falls back to unknown" test changed from a 500 to a 404, because a 500 now means busy.', code('h7', 'after', 17, 18)),
      ], {
        hunks: ['h6', 'h7'], before: 'One tracking test expected "unknown" for a 500.', after: 'New tests for withRetry(), for recovery after two 503s, and for the busy message; the unknown test now uses a 404.',
        why: 'Intent not stated.', why_source: 'none', affects: 'The test suite only.',
      }),
      chapter('diagram', 'Where the retry sits', [
        say(1, 'Both carrier calls go through request, so both now retry.', at(CLIENT, 'after', 37, 43)),
      ], {
        nodes: [
          { id: 'page', label: 'trackParcel()', file: 'src/trackingService.js' },
          { id: 'lookup', label: 'lookupStatus()', file: CLIENT },
          { id: 'hook', label: 'registerWebhook()', file: CLIENT },
          { id: 'req', label: 'request()', file: CLIENT },
          { id: 'retry', label: 'withRetry()', file: 'src/retry.js' },
        ],
        edges: [
          { from: 'page', to: 'lookup', label: '' },
          { from: 'lookup', to: 'req', label: 'GET' },
          { from: 'hook', to: 'req', label: 'POST' },
          { from: 'req', to: 'retry', label: 'up to 3 tries' },
        ],
      }),
      chapter('focus', 'Review focus', [
        say(0, 'First, registerWebhook. It is a POST, and it now retries on a timeout. If the first registration reached the carrier but the answer was slow, the carrier could get it twice.', card(0)),
        say(1, 'Second, a 5xx now shows the busy message rather than "unknown". That is intended, but anything that reads the status should know about carrier_busy.', card(1)),
        say(0, 'Third, the tests cover lookups recovering, but nothing covers a POST being retried.', card(2)),
        say(1, 'And the worst case is about thirteen seconds, close to the fifteen-second budget.', card(3)),
      ]),
    ],
  }
}

export const H2_QUESTION = 'Is it safe to retry every request?'

/** Just hunk h2, with the reviewer's question. */
export function h2QuestionScript() {
  return {
    title: 'Retrying every carrier request, and the POST it catches',
    summary: 'request() now retries timeouts, dropped connections and 5xx answers up to three times. That is safe for the status lookup, but registerWebhook() is a POST and it retries too.',
    focus_items: [
      { kind: 'risk', severity: 'high', text: 'registerWebhook() is a POST that now retries on a timeout, so the carrier may receive the same registration more than once.', general: false, hunk: '', file: CLIENT, side: 'after', from: 37, to: 43 },
      { kind: 'edge_case', severity: 'medium', text: 'A timeout is retried even when the carrier may already have acted on the request.', general: false, hunk: 'h2', file: '', side: 'after', from: 17, to: 18 },
    ],
    reasoning: [],
    quick: [
      chapter('answer', 'Not quite every request', [
        say(0, 'Not quite. Lookups are safe to retry, but registerWebhook is a POST, and it goes through the same request function.', at(CLIENT, 'after', 37, 43)),
        say(1, 'A timed-out registration could reach the carrier twice.', code('h2', 'after', 17, 18)),
      ]),
      chapter('overview', 'What changed', [
        say(0, 'request now wraps the fetch in withRetry, three attempts, retrying timeouts and 5xx answers.', code('h2', 'after', 20, 25)),
      ]),
    ],
    deep: [
      chapter('answer', 'Not quite every request', [
        say(0, 'Short answer: it is safe for the status lookup, which only reads. It is less safe for registerWebhook.', at(CLIENT, 'after', 28, 35)),
        say(1, 'registerWebhook sends a POST through request, so it now retries too.', at(CLIENT, 'after', 37, 43)),
        say(0, 'And isRetryable treats a timeout as worth another try. If the carrier did register the webhook but answered slowly, the second try registers it again.', code('h2', 'after', 17, 18)),
      ]),
      chapter('overview', 'What this part changes', [
        say(1, 'This is the heart of the pull request: the one function every carrier call goes through.', code('h2', 'after', 20, 25)),
      ]),
      chapter('change', 'request() retries', [
        say(0, 'Before, request made one fetch and threw a CarrierError on any non-OK answer.', code('h2', 'before', 13, 16)),
        say(1, 'Now the same fetch runs inside withRetry, with three attempts.', code('h2', 'after', 20, 25)),
        say(0, 'isRetryable says yes to anything that is not a CarrierError, which covers timeouts and dropped connections, and to carrier errors of 500 or more.', code('h2', 'after', 17, 18)),
      ], {
        hunks: ['h2'], before: 'One fetch; any non-OK answer threw straight away.', after: 'Up to three fetches; 5xx answers, timeouts and dropped connections get another try, 4xx answers do not.',
        why: 'The carrier blips with short bursts of 503s, and a moment later the same request works.', why_source: 'pr', affects: 'lookupStatus() and registerWebhook(), which both call request().',
      }),
      chapter('focus', 'Review focus', [
        say(1, 'Check whether the carrier ignores a repeated webhook registration. If not, registerWebhook should skip the retry.', card(0)),
        say(0, 'And remember a timeout does not mean the carrier did nothing.', card(1)),
      ]),
    ],
  }
}

/**
 * The same explanations when Claude Code's notes of the session that wrote the change are given (the
 * practice project's session.jsonl, source id "session"): what was asked, the approach, the
 * alternative turned down and the trade-off, each quoted word for word, walked through in the deep
 * version just before the review focus.
 */
export function withReasoning(script, { question = false } = {}) {
  const points = [
    { kind: 'asked', text: 'The person asked for retries, with the tracking page still answering within 15 seconds.', quote: 'The tracking page has to answer within 15 seconds, so don\'t make the worst case slower than that.', source: 'session' },
    { kind: 'approach', text: 'Claude put the retry in the request layer, so every carrier call gets it, not only status lookups.', quote: 'In the request layer every carrier call gets it, and the caller stays simple.', source: 'session' },
    { kind: 'alternative', text: 'Honouring Retry-After was considered and dropped, because the carrier does not send it on its 503s.', quote: 'I looked at honouring Retry-After, but the carrier doesn\'t send it on its 503s', source: 'session' },
    { kind: 'tradeoff', text: 'The per-try timeout came down to four seconds so three tries fit the 15-second budget.', quote: 'At 4 seconds each, the worst case is 3 × 4s plus 0.6s of backoff, about 12.6 seconds', source: 'session' },
  ]
  const out = clone(script)
  out.reasoning = question ? [points[1], points[3]] : points
  const lines = question
    ? [
        say(1, 'Claude\'s notes say why every request retries: it chose the request layer so that every carrier call gets the retry. That choice is what brings the POST along.', card(0)),
        say(0, 'And the four-second timeout was picked so three tries stay inside fifteen seconds.', card(1)),
      ]
    : [
        say(1, 'Claude\'s notes from the session that wrote this start with the ask: retries, but the page still has to answer within fifteen seconds.', card(0)),
        say(0, 'It put the retry in the request layer so every carrier call gets it. Worth knowing, because that is how the webhook POST ended up retrying.', card(1)),
        say(1, 'It looked at honouring Retry-After, and dropped it because the carrier does not send it on its 503s.', card(2)),
        say(0, 'And the four-second timeout is the trade-off that keeps three tries under fifteen seconds.', card(3)),
      ]
  const at = out.deep.findIndex((c) => c.kind === 'focus')
  out.deep.splice(at, 0, chapter('reasoning', 'Why it was built this way', lines))
  return out
}

/** A deep copy, for tests that break one thing. */
export const clone = (v) => JSON.parse(JSON.stringify(v))

export const H2_FOLLOW_UP = 'What happens when the carrier stays down?'

/** An answer to a question asked mid-play, about the h2 explainer. */
export function h2FollowUpAnswer() {
  return {
    answerable: true,
    title: 'When the carrier stays down',
    lines: [
      say(0, 'Each try gets four seconds, and request allows three of them.', at(CLIENT, 'after', 6, 7)),
      say(1, 'After the third failed try, request stops retrying. What withRetry hands back then lives in retry.js, outside this part.', code('h2', 'after', 20, 25)),
      say(0, 'So what the page shows depends on the caller, which this part does not include.', card()),
    ],
  }
}

// ---- product mode: the plain-English recap, with pictures of the practice tracking page --------

const pic = (item, point_at = '') => ({ type: 'picture', item, point_at })
const note = (item = -1) => ({ type: 'card', item, point_at: '' })
const part = (kind, title, lines, extra = {}) => ({ kind, title, hunks: [], before: '', after: '', why: '', why_source: '', lines, ...extra })

/** The pages the try step lets product mode picture (product → pages: the page, then a note). */
export const PRODUCT_PAGES = [
  '/ the front page, where a parcel number is typed in',
  '/track/PP-2002 a parcel the carrier fails on twice, then answers',
  '/track/PP-3003 a parcel the carrier keeps failing on',
]

const BUSY = 'The carrier is busy. Try again in a minute'
const ON_ITS_WAY = 'On its way'

/** The whole change as a plain-English recap, no question. Picture 0 is the busy parcel, 1 the one that recovers. */
export function productWholeScript() {
  return {
    title: 'The tracking page rides out short carrier hiccups',
    summary: 'When the parcel company has a short hiccup, the tracking page now quietly tries again, and when the hiccup lasts it says the carrier is busy instead of saying the parcel cannot be seen.',
    pictures: [
      { page: '/track/PP-3003', label: 'A parcel while the carrier keeps failing' },
      { page: '/track/PP-2002', label: 'A parcel the carrier stumbled on, then answered' },
      { page: '/', label: 'The front page, where a parcel number goes in' },
    ],
    focus_items: [
      { kind: 'watch_out', severity: 'high', text: "Behind the scenes, the app's sign-up for the carrier's updates now tries again too, so the carrier might get the same sign-up twice. Nothing in the change says whether that matters.", picture: -1 },
      { kind: 'try_it', severity: 'medium', text: 'Open parcel PP-3003 and read the message: it should say the carrier is busy and to try again in a minute.', picture: 0 },
      { kind: 'looks_different', severity: 'medium', text: '"We can\'t see this parcel right now" now only shows for a parcel number the carrier does not know.', picture: -1 },
      { kind: 'not_checked', severity: 'medium', text: 'Nothing here says anyone has opened the page during a real hiccup at the carrier.', picture: -1 },
      { kind: 'watch_out', severity: 'low', text: 'A page can take a little longer when the carrier is struggling: up to three tries of four seconds each, which still fit inside fifteen seconds.', picture: -1 },
    ],
    quick: [
      part('overview', 'What is different', [
        say(0, 'When the parcel company has a short hiccup, the tracking page no longer gives up straight away. It quietly tries again, up to three times.', pic(1, ON_ITS_WAY)),
        say(1, 'If the carrier is still down after that, people now see a clearer message: the carrier is busy, try again in a minute.', pic(0, BUSY)),
        say(0, 'Customers used to be told their parcel could not be seen, when a refresh a minute later showed it. Open parcel PP-3003 to see the new message.', pic(0, BUSY)),
      ]),
    ],
    deep: [
      part('overview', 'What is different', [
        say(0, 'Support had fourteen tickets in one week from customers told "We can\'t see this parcel right now". Each time, a refresh a minute later showed the parcel.', note()),
        say(1, 'So now the page rides out short hiccups at the parcel company, and when a hiccup lasts, it says so plainly.', pic(1, ON_ITS_WAY)),
      ]),
      part('change', 'A short hiccup no longer shows an error', [
        say(0, 'When the parcel company fails to answer, the app now asks again, up to three times, waiting a little longer each time.', pic(1, ON_ITS_WAY)),
        say(1, 'So a parcel like this one, where the carrier stumbled twice, still shows where it is: on its way.', pic(1, ON_ITS_WAY)),
        say(0, 'To keep the page quick, each try now gets four seconds instead of ten, so three tries still fit inside fifteen seconds.', note()),
      ], {
        hunks: ['h1', 'h2', 'h4'], before: 'One try, given ten seconds. Any hiccup at the parcel company showed an error.', after: 'Up to three tries of four seconds each, with a short wait between them.',
        why: 'A short burst of errors at the carrier should not tell customers their parcel cannot be seen, and the page still has to answer within fifteen seconds.', why_source: 'pr',
      }),
      part('change', 'A clearer message when the carrier stays down', [
        say(1, 'If the carrier is still failing after the last try, the page now says: the carrier is busy, try again in a minute.', pic(0, BUSY)),
        say(0, 'Before, that same moment showed "We can\'t see this parcel right now".', pic(0, BUSY)),
        say(1, 'A parcel number the carrier does not know at all still gets that old message.', note()),
      ], {
        hunks: ['h3', 'h5'], before: 'Any trouble at the carrier showed "We can\'t see this parcel right now".', after: 'When the carrier is still failing after every try, the page says "' + BUSY + '".',
        why: 'Customers were told the parcel could not be seen, when the carrier was only briefly down.', why_source: 'issue:41',
      }),
      part('change', 'Behind the scenes: new automatic checks', [
        say(0, 'The rest has nothing new to see: new automatic checks for trying again, for a parcel that recovers after two hiccups, and for the busy message.', note()),
      ], {
        hunks: ['h6', 'h7'], before: 'The automatic checks expected the old message for any carrier error.', after: 'New checks cover trying again, recovering after two hiccups, and the busy message.',
        why: 'Intent not stated.', why_source: 'none',
      }),
      part('focus', 'What to check', [
        say(1, "First, something to watch: the app's sign-up for the carrier's updates now tries again too, so the carrier might get the same sign-up twice. Nothing here says whether that matters.", note(0)),
        say(0, 'Then try it: open parcel PP-3003 and read the message. It should say the carrier is busy and to try again in a minute.', pic(0, BUSY)),
        say(1, 'Notice that the old message, we can\'t see this parcel right now, now only shows for a parcel number the carrier does not know.', note(2)),
        say(0, 'Nothing here says anyone has opened the page during a real hiccup at the carrier, so that is still to try.', note(3)),
        say(1, 'And a page can take a little longer when the carrier struggles, though three tries still fit inside fifteen seconds.', note(4)),
      ]),
    ],
  }
}

export const PRODUCT_FOLLOW_UP = 'What do customers see when the carrier is down?'

/** An answer to a question asked mid-play, about the product recap above. */
export function productFollowUpAnswer() {
  return {
    answerable: true,
    title: 'What customers see when the carrier is down',
    lines: [
      say(0, 'They see a new message: the carrier is busy, try again in a minute.', pic(0, BUSY)),
      say(1, 'That shows only when the carrier is still failing after every try. A short hiccup is ridden out, and the parcel shows as usual.', pic(1, ON_ITS_WAY)),
      say(0, 'A parcel number the carrier does not know still gets the old message, that the parcel cannot be seen right now.', note()),
    ],
  }
}

/**
 * A stand-in for Claude for the offline practice run: it knows the two explanations above and the
 * one follow-up answer, and says so plainly when asked for anything else. Nothing is sent anywhere.
 */
export function offlineWriter() {
  const only = 'The offline practice has ready-made answers for three things only: "Explain the whole change"; the retry change in carrierClient.js (lines 14–28) with the question "' + H2_QUESTION + '"; and, inside that one, the follow-up "' + H2_FOLLOW_UP + '". Run the try step without --offline to have Claude explain anything else.'
  const same = (a, b) => a.toLowerCase().replace(/\s+/g, ' ').trim() === b.toLowerCase().replace(/\s+/g, ' ').trim()
  const onlyProduct = 'The offline practice of product mode has ready-made answers for two things only: "Explain the whole change", and, inside it, the question "' + PRODUCT_FOLLOW_UP + '". Run the try step without --offline to have Claude explain anything else.'
  const write = async ({ purpose, prompt }) => {
    // Product mode's prompts name the pages that may be pictured (or, for a question, the pictures taken).
    if (purpose === 'ask' && prompt.includes('## PICTURES ALREADY TAKEN')) {
      const m = /## The question\n([^\n]*)/.exec(prompt)
      if (m && same(m[1], PRODUCT_FOLLOW_UP)) return productFollowUpAnswer()
      throw new NeedsYou(onlyProduct)
    }
    if (purpose !== 'ask' && prompt.includes('## ALLOWED PAGES')) {
      const what = (/^What to explain: (.*)$/m.exec(prompt) || [])[1] || ''
      const asked = /^The question \(answer it first\): (.*)$/m.test(prompt)
      if (what === 'The whole change' && !asked) return productWholeScript()
      throw new NeedsYou(onlyProduct)
    }
    if (purpose === 'ask') {
      const m = /## The question\n([^\n]*)/.exec(prompt)
      if (m && same(m[1], H2_FOLLOW_UP)) return h2FollowUpAnswer()
      throw new NeedsYou(only)
    }
    const what = (/^What to explain: (.*)$/m.exec(prompt) || [])[1] || ''
    const question = (/^The reviewer's question \(answer it first\): (.*)$/m.exec(prompt) || [])[1] || ''
    // With the practice session given (the try step names it), the answers carry its reasoning.
    const session = prompt.includes('### source "session"')
    if (what === 'The whole change' && !question) return session ? withReasoning(wholeScript()) : wholeScript()
    if (/, one change \(h2\)$/.test(what) && same(question, H2_QUESTION)) return session ? withReasoning(h2QuestionScript(), { question: true }) : h2QuestionScript()
    throw new NeedsYou(only)
  }
  // Its own cache keys: a ready-made answer is never served later as Claude's, or the other way round.
  write.cacheKey = 'offline-practice'
  return write
}
