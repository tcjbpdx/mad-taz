import { test, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { trackParcel } from '../src/trackingService.js'

const realFetch = globalThis.fetch
afterEach(() => { globalThis.fetch = realFetch })

const answer = (status, body) => async () => new Response(JSON.stringify(body), { status })

test('shows a delivered parcel', async () => {
  globalThis.fetch = answer(200, { status: 'delivered', updated_at: '2026-11-02T10:00:00Z', last_scan: { city: 'Leeds' } })
  const r = await trackParcel('PP123')
  assert.equal(r.label, 'Delivered')
  assert.equal(r.location, 'Leeds')
})

test('falls back to unknown when the carrier fails', async () => {
  globalThis.fetch = answer(500, {})
  const r = await trackParcel('PP123')
  assert.equal(r.status, 'unknown')
})
