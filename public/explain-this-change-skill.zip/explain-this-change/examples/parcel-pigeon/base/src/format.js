const LABELS = {
  in_transit: 'On its way',
  out_for_delivery: 'Out for delivery',
  delivered: 'Delivered',
  unknown: "We can't see this parcel right now",
}

export const describeStatus = (status) => LABELS[status] ?? LABELS.unknown
