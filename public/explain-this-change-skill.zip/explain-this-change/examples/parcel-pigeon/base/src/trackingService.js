import { lookupStatus, CarrierError } from './carrierClient.js'
import { describeStatus } from './format.js'

// What the tracking page shows for one parcel.
export async function trackParcel(trackingNo) {
  try {
    const found = await lookupStatus(trackingNo)
    return { trackingNo, ...found, label: describeStatus(found.status) }
  } catch (err) {
    if (err instanceof CarrierError) {
      return { trackingNo, status: 'unknown', label: describeStatus('unknown') }
    }
    throw err
  }
}
