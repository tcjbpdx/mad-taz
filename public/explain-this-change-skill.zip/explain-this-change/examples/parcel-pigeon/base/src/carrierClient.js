// Talks to the parcel carrier's tracking API.
const API = process.env.CARRIER_API || 'https://api.example-carrier.test/v2'
const TIMEOUT_MS = 10_000

export class CarrierError extends Error {
  constructor(message, status) {
    super(message)
    this.name = 'CarrierError'
    this.status = status
  }
}

async function request(path, init = {}) {
  const res = await fetch(`${API}${path}`, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS) })
  if (!res.ok) throw new CarrierError(`Carrier answered ${res.status}`, res.status)
  return res.json()
}

export async function lookupStatus(trackingNo) {
  const body = await request(`/parcels/${encodeURIComponent(trackingNo)}`)
  return {
    status: body.status,
    updatedAt: body.updated_at,
    location: body.last_scan?.city ?? null,
  }
}

export async function registerWebhook(callbackUrl) {
  return request('/webhooks', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ url: callbackUrl, events: ['status_changed'] }),
  })
}
