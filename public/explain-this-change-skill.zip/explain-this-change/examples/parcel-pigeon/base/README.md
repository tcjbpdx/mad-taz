# Parcel Pigeon

A made-up parcel tracker. It exists only so Explain This Change has a small, realistic
change to explain. Nothing here talks to a real carrier.

- `src/carrierClient.js` asks the carrier for a parcel's status.
- `src/trackingService.js` turns that into what the tracking page shows.
- `npm test` runs the tests; `npm run flaky` plays a carrier that fails twice, then answers.
- `npm run page` opens the tracking page at http://127.0.0.1:4321 with a pretend carrier:
  PP-1001 answers, PP-2002 blips twice then answers, PP-3003 is down.
