// Plays a flaky carrier: it fails twice with 503, then answers.
// Prints what the tracking page would show, so a change in behaviour is easy to see.
import { trackParcel } from '../src/trackingService.js'

let calls = 0
globalThis.fetch = async () => {
  calls += 1
  if (calls <= 2) return new Response('{}', { status: 503 })
  return new Response(JSON.stringify({ status: 'in_transit', updated_at: '2026-11-02T10:00:00Z', last_scan: { city: 'Leeds' } }), { status: 200 })
}

const result = await trackParcel('PP123')
console.log(`carrier calls: ${calls}`)
console.log(`page shows:    ${result.label}`)
