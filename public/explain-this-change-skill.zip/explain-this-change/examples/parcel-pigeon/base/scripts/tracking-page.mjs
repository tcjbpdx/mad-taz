// Parcel Pigeon's tracking page, running on this computer with a pretend carrier, so the page can be
// opened in a browser (and pictured by product mode). Nothing here talks to a real carrier.
//
//   npm run page                 (or: node scripts/tracking-page.mjs --port 4321)
//
// The pretend carrier has three parcels:
//   PP-1001  answers straight away
//   PP-2002  fails twice with 503 (a short blip), then answers
//   PP-3003  fails every time with 503 (the carrier is down)
// Any other number is one the carrier does not know (404).
import { createServer } from 'node:http'
import { trackParcel } from '../src/trackingService.js'

const PARCELS = {
  'PP-1001': { failures: 0, body: { status: 'delivered', updated_at: '2026-11-02T08:12:00Z', last_scan: { city: 'York' } } },
  'PP-2002': { failures: 2, body: { status: 'in_transit', updated_at: '2026-11-02T10:00:00Z', last_scan: { city: 'Leeds' } } },
  'PP-3003': { failures: Infinity, body: null },
}

// Each page load starts the pretend carrier's count again, so every visit plays the same story.
const calls = new Map()
globalThis.fetch = async (url) => {
  const no = decodeURIComponent(String(url).split('/parcels/')[1] || '')
  const parcel = PARCELS[no]
  if (!parcel) return new Response('{}', { status: 404 })
  const n = (calls.get(no) || 0) + 1
  calls.set(no, n)
  if (n <= parcel.failures) return new Response('{}', { status: 503 })
  return new Response(JSON.stringify(parcel.body), { status: 200 })
}

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

const STYLE = `
  :root { color-scheme: light; --ink: #1d2433; --soft: #5b6475; --line: #e3e6ec; --brand: #0f766e; }
  * { box-sizing: border-box; }
  body { margin: 0; font: 16px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif; color: var(--ink); background: #f7f8fa; }
  header { background: #fff; border-bottom: 1px solid var(--line); padding: 14px 24px; }
  header a { color: var(--brand); font-weight: 700; font-size: 19px; text-decoration: none; }
  main { max-width: 640px; margin: 36px auto; padding: 0 20px; }
  h1 { font-size: 26px; margin: 0 0 6px; }
  .soft { color: var(--soft); margin: 0 0 22px; }
  form { display: flex; gap: 8px; margin: 0 0 26px; }
  input { flex: 1; font: inherit; padding: 10px 12px; border: 1px solid var(--line); border-radius: 8px; background: #fff; }
  button, .button { font: inherit; font-weight: 600; padding: 10px 16px; border: 0; border-radius: 8px; background: var(--brand); color: #fff; text-decoration: none; display: inline-block; }
  ul { list-style: none; padding: 0; margin: 0; display: grid; gap: 8px; }
  li a { display: block; padding: 12px 14px; background: #fff; border: 1px solid var(--line); border-radius: 8px; color: var(--ink); text-decoration: none; }
  .card { background: #fff; border: 1px solid var(--line); border-radius: 12px; padding: 24px; }
  .status { font-size: 24px; font-weight: 700; margin: 4px 0 8px; }
  .status.busy { color: #b45309; }
  .status.unknown { color: #b91c1c; }
  .status.ok { color: var(--brand); }
  .back { display: inline-block; margin-top: 18px; color: var(--brand); }
`

const page = (title, body) => `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)} · Parcel Pigeon</title><style>${STYLE}</style></head>
<body><header><a href="/">Parcel Pigeon</a></header><main>${body}</main></body></html>`

function home() {
  return page('Track a parcel', `
  <h1>Track a parcel</h1>
  <p class="soft">Type the number from your receipt.</p>
  <form action="/track" method="get"><input name="no" placeholder="PP-1234" aria-label="Tracking number"><button>Track</button></form>
  <p class="soft">Or try one of these:</p>
  <ul>${Object.keys(PARCELS).map((no) => `<li><a href="/track/${no}">${no}</a></li>`).join('')}</ul>`)
}

async function track(no) {
  calls.delete(no)
  const r = await trackParcel(no)
  const tone = r.status === 'carrier_busy' ? 'busy' : r.status === 'unknown' ? 'unknown' : 'ok'
  return page(`Parcel ${no}`, `
  <div class="card">
    <p class="soft">Parcel ${esc(no)}</p>
    <p class="status ${tone}">${esc(r.label)}</p>
    ${r.location ? `<p>Last seen in ${esc(r.location)}.</p>` : ''}
    ${r.retryable ? `<a class="button" href="/track/${encodeURIComponent(no)}">Try again</a>` : ''}
  </div>
  <a class="back" href="/">Track another parcel</a>`)
}

const portArg = process.argv.indexOf('--port')
const port = Number(portArg > 0 ? process.argv[portArg + 1] : process.env.PORT || 4321)

const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost')
  const send = (status, html) => { res.writeHead(status, { 'content-type': 'text/html; charset=utf-8' }); res.end(html) }
  try {
    if (url.pathname === '/') return send(200, home())
    if (url.pathname === '/track') {
      res.writeHead(302, { location: `/track/${encodeURIComponent((url.searchParams.get('no') || '').trim().toUpperCase())}` })
      return res.end()
    }
    const m = /^\/track\/([^/]+)$/.exec(url.pathname)
    if (m) return send(200, await track(decodeURIComponent(m[1]).toUpperCase()))
    return send(404, page('Not found', '<h1>Not found</h1><a class="back" href="/">Back to the start</a>'))
  } catch (e) {
    return send(500, page('Something went wrong', `<h1>Something went wrong</h1><p class="soft">${esc(e.message)}</p>`))
  }
})

server.listen(port, '127.0.0.1', () => {
  console.log(`Parcel Pigeon tracking page: http://127.0.0.1:${server.address().port}`)
})
