// The example review page: reads the change from the helper and draws it as a plain diff, with an
// <explain-change> button on the whole change, each file and each hunk. A real review app already
// has its own diff view; it would only add the buttons. Code is set as text, never as HTML.

(() => {
  'use strict'
  const meta = document.querySelector('meta[name="explain-token"]')
  const token = meta && meta.content !== '{{TOKEN}}' ? meta.content : ''
  const server = window.location.origin

  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag)
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue
      if (k === 'text') n.textContent = v
      else if (k === 'class') n.className = v
      else n.setAttribute(k, v === true ? '' : String(v))
    }
    for (const k of kids) if (k != null) n.append(k)
    return n
  }

  function button(attrs) {
    const b = el('explain-change', { server, ...attrs })
    if (token) b.setAttribute('token', token)
    return b
  }

  /** A line inside the hunk the button should explain: the first added line (or removed, if none). */
  function lineIn(h) {
    const added = h.rows.find((r) => r.t === 'add')
    if (added) return { line: added.new }
    const removed = h.rows.find((r) => r.t === 'del')
    if (removed) return { line: removed.old, side: 'before' }
    return { line: h.newStart }
  }

  function hunkTable(h) {
    const rows = h.rows.map((r) => el('tr', { class: r.t },
      el('td', { class: 'no', text: r.old == null ? '' : String(r.old) }),
      el('td', { class: 'no', text: r.new == null ? '' : String(r.new) }),
      el('td', { class: 'mk', text: r.t === 'add' ? '+' : r.t === 'del' ? '−' : ' ' }),
      el('td', { class: 'src', text: r.text })))
    return el('div', { class: 'scroll' }, el('table', null, el('tbody', null, ...rows)))
  }

  function draw(change) {
    document.getElementById('title').textContent = change.label ? `Reviewing ${change.label}` : 'Reviewing the change'
    document.getElementById('whole').replaceChildren(button({ ask: true, label: 'Explain the whole change' }))
    const main = document.getElementById('change')
    main.replaceChildren()
    for (const f of change.files) {
      const box = el('section', { class: 'file' },
        el('h2', null, el('span', { class: 'path', text: f.oldPath && f.oldPath !== f.path ? `${f.oldPath} → ${f.path}` : f.path }),
          f.binary ? null : button({ file: f.path })))
      for (const h of f.hunks) {
        const at = lineIn(h)
        box.append(
          el('div', { class: 'hunk-head' },
            el('span', { class: 'where', text: `Lines ${h.newStart}+${h.section ? `  ·  ${h.section}` : ''}` }),
            button({ file: f.path, line: at.line, side: at.side, ask: true })),
          hunkTable(h))
      }
      main.append(box)
    }
  }

  async function load() {
    const headers = { 'content-type': 'application/json' }
    if (token) headers['x-explain-token'] = token
    try {
      const r = await fetch('/diff', { method: 'POST', headers, body: '{}' })
      const j = await r.json()
      if (!r.ok) throw new Error(j.error || `The helper said no (${r.status}).`)
      draw(j)
    } catch (e) {
      document.getElementById('title').textContent = 'The change could not be read'
      document.getElementById('change').replaceChildren(el('p', { class: 'problem', text: e.message }))
    }
  }

  load()
})()
