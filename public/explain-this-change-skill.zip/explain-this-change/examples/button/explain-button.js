// <explain-change>: an "Explain this" button for any review app. It asks the Explain This Change
// helper on the reviewer's own computer (node .claude/skills/explain-this-change/scripts/explain.mjs serve) to explain a change, or
// one part of it, then plays the narrated walkthrough in a window over the page. No framework, no
// build step, nothing sent anywhere except to that helper.
//
//   <script src="http://127.0.0.1:4317/button.js"></script>
//   <explain-change file="src/carrierClient.js" line="20" ask></explain-change>
//
// What to explain (attributes, all optional):
//   file + line        one hunk: the part of the change around that line (side="before" for a removed line)
//   file + from + to   just those lines
//   file               the whole file
//   hunk               one hunk by its id, such as h3
//   (none)             the whole change
// Which change: pr="42" (a pull request), or base="main" head="my-branch", or set the element's
// .diff property to the diff's text. With none, the helper's own default (the current branch).
// Also: question="…" (answered first), ask (shows a box to type a question), label="…",
// server="http://127.0.0.1:4317", token="…" (only when the helper has one).
//
// Events (they bubble): explain-change:progress { stage, message }, explain-change:ready
// { id, url, title, cached }, explain-change:error { message, details }.
// From script: ExplainChange.explain({ server, token, source, scope, question, onProgress })
// resolves to { id, url, title, cached }; ExplainChange.open(url) shows it.
//
// Styling: set --explain-accent (and --explain-radius) on the element, or style ::part(button).
// A review app with its own security policy needs the helper's address in script-src, frame-src
// and connect-src.

(() => {
  'use strict'
  if (typeof window === 'undefined' || !window.customElements || window.customElements.get('explain-change')) return

  const DEFAULT_SERVER = 'http://127.0.0.1:4317'

  const CSS = `
:host { display: inline-block; font: 13px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: inherit; }
:host([hidden]) { display: none; }
form { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; margin: 0; }
input { font: inherit; color: inherit; background: transparent; border: 1px solid color-mix(in srgb, currentColor 25%, transparent);
  border-radius: var(--explain-radius, 7px); padding: 4px 8px; min-width: 14em; }
button { font: inherit; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;
  border: 1px solid var(--explain-accent, #2563EB); background: var(--explain-accent, #2563EB); color: var(--explain-on-accent, #fff);
  border-radius: var(--explain-radius, 7px); padding: 4px 10px; }
button:disabled { opacity: 0.6; cursor: progress; }
button:focus-visible, input:focus-visible { outline: 2px solid var(--explain-accent, #2563EB); outline-offset: 2px; }
svg { width: 14px; height: 14px; flex-shrink: 0; }
.status { font-size: 12px; opacity: 0.8; max-width: 32em; }
.status.bad { opacity: 1; color: #cf222e; }
@media (prefers-color-scheme: dark) { .status.bad { color: #ff7b72; } }
.spin { animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .spin { animation: none; } }
`
  const VIEWER_CSS = `
dialog { width: min(1400px, 96vw); height: min(900px, 92vh); max-width: none; max-height: none; padding: 0; border: 0;
  border-radius: 12px; overflow: hidden; background: #0e1116; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.45); }
dialog::backdrop { background: rgba(10, 12, 16, 0.55); }
.frame { display: grid; grid-template-rows: auto 1fr; height: 100%; }
.bar { display: flex; align-items: center; gap: 8px; padding: 6px 8px 6px 14px; background: #151a21; color: #e6e9ef;
  font: 600 13px/1.3 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
.bar span { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bar button { font: inherit; border: 1px solid #29303a; background: #1b2129; color: inherit; border-radius: 7px; padding: 4px 10px; cursor: pointer; }
.bar button:focus-visible { outline: 2px solid #6b9bff; outline-offset: 2px; }
iframe { width: 100%; height: 100%; border: 0; background: #fff; display: block; }
@media (max-width: 640px) { dialog { width: 100vw; height: 100dvh; border-radius: 0; } }
`
  const ICON = 'M8 5v14l11-7z'
  const SPIN = 'M12 2a10 10 0 1 0 10 10h-2.5A7.5 7.5 0 1 1 12 4.5z'

  function adopt(root, css) {
    try {
      const s = new CSSStyleSheet()
      s.replaceSync(css)
      root.adoptedStyleSheets = [s]
    } catch {
      const st = document.createElement('style')
      st.textContent = css
      root.append(st)
    }
  }

  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag)
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue
      if (k === 'text') n.textContent = v
      else n.setAttribute(k, v === true ? '' : String(v))
    }
    for (const k of kids) if (k != null) n.append(k)
    return n
  }

  function icon(d, cls) {
    const ns = 'http://www.w3.org/2000/svg'
    const s = document.createElementNS(ns, 'svg')
    s.setAttribute('viewBox', '0 0 24 24')
    s.setAttribute('aria-hidden', 'true')
    if (cls) s.setAttribute('class', cls)
    const p = document.createElementNS(ns, 'path')
    p.setAttribute('d', d)
    p.setAttribute('fill', 'currentColor')
    s.append(p)
    return s
  }

  function helperOrigin(server) {
    const u = new URL(server || DEFAULT_SERVER, window.location.href)
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('The helper\'s address should start with http:// or https://.')
    return u.origin
  }

  function pageUrl(base, path, token) {
    const u = new URL(path, base)
    if (u.origin !== base) throw new Error('The helper answered with an address somewhere else, so it was not opened.')
    if (token) u.searchParams.set('token', token)
    return u.href
  }

  function fail(message, details) {
    const e = new Error(message)
    e.details = Array.isArray(details) ? details : []
    return e
  }

  /** Asks the helper to explain; resolves to { id, url, title, cached }. */
  async function explainChange({ server, token, source = null, scope = { kind: 'whole' }, question = '', onProgress = () => {}, signal } = {}) {
    const base = helperOrigin(server)
    const headers = { 'content-type': 'application/json' }
    if (token) headers['x-explain-token'] = token
    let r
    try {
      r = await fetch(`${base}/explain`, {
        method: 'POST', headers, signal, credentials: 'omit', referrerPolicy: 'no-referrer',
        body: JSON.stringify({ source, scope, question }),
      })
    } catch (e) {
      if (e && e.name === 'AbortError') throw e
      throw fail(`The explain helper is not answering at ${base}. Start it on this computer, from the project's top folder, with: node .claude/skills/explain-this-change/scripts/explain.mjs serve`)
    }
    if (!r.ok) {
      const j = await r.json().catch(() => ({}))
      throw fail(j.error || `The helper said no (${r.status}).`, j.details)
    }
    let done = null
    let problem = null
    const take = (text) => {
      if (!text.trim()) return
      let o
      try { o = JSON.parse(text) } catch { return }
      if (o.done) done = o.done
      else if (o.error) problem = fail(o.error, o.details)
      else onProgress({ stage: String(o.stage || ''), message: String(o.message || '') })
    }
    const reader = r.body.getReader()
    const dec = new TextDecoder()
    let buf = ''
    for (;;) {
      const { value, done: end } = await reader.read()
      if (end) break
      buf += dec.decode(value, { stream: true })
      let i
      while ((i = buf.indexOf('\n')) >= 0) { take(buf.slice(0, i)); buf = buf.slice(i + 1) }
    }
    take(buf + dec.decode())
    if (problem) throw problem
    if (!done) throw fail('The helper stopped before the explanation was ready.')
    return { id: done.id, title: done.title || '', cached: Boolean(done.cached), warnings: done.warnings || [], url: pageUrl(base, done.url, token) }
  }

  // ---- the window the walkthrough plays in (one, shared by every button) ----

  let viewer = null
  let returnFocus = null

  function makeViewer() {
    const host = el('div', { 'data-explain-change-viewer': '' })
    const root = host.attachShadow({ mode: 'open' })
    adopt(root, VIEWER_CSS)
    const title = el('span', { text: 'Explain This Change' })
    const close = el('button', { type: 'button', text: 'Close' })
    const frame = el('iframe', {
      title: 'Explain This Change player',
      referrerpolicy: 'no-referrer',
      // Its own address, so it may ask the helper follow-up questions; nothing else of this page's.
      sandbox: 'allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-downloads',
      allow: 'clipboard-write',
    })
    const dialog = el('dialog', { 'aria-label': 'Explain This Change', part: 'dialog' },
      el('div', { class: 'frame' }, el('div', { class: 'bar' }, title, close), frame))
    root.append(dialog)
    close.addEventListener('click', () => dialog.close())
    dialog.addEventListener('close', () => {
      frame.src = 'about:blank' // stops the narration
      if (returnFocus && returnFocus.focus) returnFocus.focus()
      returnFocus = null
    })
    document.body.append(host)
    viewer = { dialog, frame, title }
    return viewer
  }

  /** Shows a walkthrough (an address from explainChange) over the page. */
  function openPlayer(url, { title = '' } = {}) {
    const v = viewer || makeViewer()
    returnFocus = document.activeElement
    v.title.textContent = title || 'Explain This Change'
    v.frame.src = url
    if (!v.dialog.open) v.dialog.showModal()
    v.frame.focus()
  }

  // ---- the button ----

  function scopeOf(node) {
    const a = (n) => node.getAttribute(n)
    const side = a('side') === 'before' ? 'before' : undefined
    if (a('hunk')) return { kind: 'hunk', id: a('hunk') }
    const file = a('file')
    if (file && a('from')) return { kind: 'lines', file, from: Number(a('from')), to: Number(a('to') || a('from')), side }
    if (file && a('line')) return { kind: 'hunk', file, line: Number(a('line')), side }
    if (file) return { kind: 'file', file }
    return { kind: 'whole' }
  }

  function sourceOf(node) {
    if (node.source && typeof node.source === 'object') return node.source
    if (typeof node.diff === 'string' && node.diff.trim()) return { kind: 'diff', text: node.diff }
    const pr = node.getAttribute('pr')
    if (pr) return { kind: 'github', number: Number(pr) }
    const base = node.getAttribute('base')
    const head = node.getAttribute('head')
    if (base || head) return { kind: 'git', base: base || undefined, head: head || undefined }
    return null
  }

  class ExplainChangeElement extends HTMLElement {
    static get observedAttributes() { return ['label', 'ask', 'question', 'file', 'hunk', 'line', 'from'] }

    constructor() {
      super()
      this._root = this.attachShadow({ mode: 'open' })
      adopt(this._root, CSS)
      this._busy = false
      this._abort = null
    }

    connectedCallback() { this._render() }
    disconnectedCallback() { if (this._abort) this._abort.abort() }
    attributeChangedCallback() { if (this.isConnected && !this._busy) this._render() }

    _label() {
      if (this.getAttribute('label')) return this.getAttribute('label')
      const s = scopeOf(this)
      return s.kind === 'whole' ? 'Explain this change' : s.kind === 'file' ? 'Explain this file' : 'Explain this part'
    }

    _render() {
      const askBox = this.hasAttribute('ask')
      this._input = askBox ? el('input', { type: 'text', part: 'input', maxlength: 500, placeholder: 'Ask something about it (optional)', 'aria-label': 'Your question (optional)' }) : null
      if (this._input && this.getAttribute('question')) this._input.value = this.getAttribute('question')
      this._button = el('button', { type: 'submit', part: 'button' }, icon(ICON), el('span', { text: this._label() }))
      this._status = el('span', { class: 'status', part: 'status', role: 'status', 'aria-live': 'polite' })
      const form = el('form', null, this._input, this._button, this._status)
      form.addEventListener('submit', (ev) => { ev.preventDefault(); this.run() })
      this._root.replaceChildren(form)
    }

    _say(text, bad) {
      this._status.textContent = text
      this._status.className = bad ? 'status bad' : 'status'
    }

    _setBusy(on) {
      this._busy = on
      this._button.disabled = on
      this._button.firstChild.replaceWith(icon(on ? SPIN : ICON, on ? 'spin' : null))
      this.toggleAttribute('busy', on)
    }

    /** Explains, then opens the walkthrough. Resolves to { id, url, title, cached }, or null on a problem. */
    async run() {
      if (this._busy) return null
      const question = (this._input ? this._input.value : this.getAttribute('question') || '').trim()
      this._setBusy(true)
      this._say('Starting…')
      this._abort = new AbortController()
      const emit = (name, detail) => this.dispatchEvent(new CustomEvent(`explain-change:${name}`, { detail, bubbles: true, composed: true }))
      try {
        const res = await explainChange({
          server: this.getAttribute('server') || DEFAULT_SERVER,
          token: this.getAttribute('token') || '',
          source: sourceOf(this),
          scope: scopeOf(this),
          question,
          signal: this._abort.signal,
          onProgress: (p) => { this._say(p.message); emit('progress', p) },
        })
        this._say(res.cached ? 'Ready (kept from last time).' : 'Ready.')
        emit('ready', res)
        openPlayer(res.url, { title: res.title })
        return res
      } catch (e) {
        if (e && e.name === 'AbortError') return null
        const message = e && e.message ? e.message : 'That could not be explained.'
        this._say(message, true)
        this._status.title = (e && e.details ? e.details : []).join('\n')
        emit('error', { message, details: (e && e.details) || [] })
        return null
      } finally {
        this._abort = null
        this._setBusy(false)
      }
    }
  }

  window.customElements.define('explain-change', ExplainChangeElement)
  window.ExplainChange = Object.freeze({ explain: explainChange, open: openPlayer, version: '1.0.0' })
})()
