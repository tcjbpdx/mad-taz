// Shared by the tests: a fresh copy of the sample change in a temporary folder.
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { buildSample } from '../scripts/lib/sample.mjs'

let built = null
export function sampleRepo() {
  if (!built) built = buildSample(join(mkdtempSync(join(tmpdir(), 'etc-sample-')), 'parcel-pigeon'))
  return built
}
