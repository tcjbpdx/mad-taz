// The player: one self-contained page, a strict security policy, and — when the browser helper is
// installed — a real browser check that every line lights exactly the code it cites.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { openSource } from '../scripts/lib/source.mjs'
import { applyScope } from '../scripts/lib/scope.mjs'
import { buildContext } from '../scripts/lib/context.mjs'
import { checkScript, tidyScript } from '../scripts/lib/checks.mjs'
import { checkContext } from '../scripts/lib/script.mjs'
import { buildPresentation } from '../scripts/lib/present.mjs'
import { defaultSettings } from '../scripts/lib/settings.mjs'
import { cleanAccent, connectSources, inlineHashes, onAccent, playerScript, renderHtml, scriptJson } from '../scripts/lib/render.mjs'
import { reviewHtml } from '../scripts/lib/review.mjs'
import { H2_QUESTION, clone, h2QuestionScript, wholeScript } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

let opened = null
function present(scope, scriptFn, tweak = (p) => p) {
  if (!opened) {
    const s = sampleRepo()
    opened = openSource({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { settings: { source: { use_github: false } } })
  }
  const scoped = applyScope(opened.diff, scope)
  const ctx = checkContext({ src: opened, scoped, context: buildContext(opened, scoped) })
  const script = tidyScript(scriptFn(), ctx)
  const { hard } = checkScript(script, ctx)
  assert.deepEqual(hard, [], 'the fixture script should pass the fact-checker')
  return tweak(buildPresentation({ src: opened, scoped, settings: defaultSettings(), script, id: `test-${scope.kind}`, created: '2026-11-22T00:00:00Z' }))
}
const whole = () => present({ kind: 'whole' }, wholeScript)
const oneHunk = () => present({ kind: 'hunk', id: 'h2', question: H2_QUESTION }, h2QuestionScript)
const temp = () => mkdtempSync(join(tmpdir(), 'etc-player-'))
/** The security policy as the browser reads it (the attribute is HTML-escaped in the file). */
const policyOf = (html) => {
  const m = html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)
  return m && m[1].replace(/&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&')
}

// ---- the page itself ---------------------------------------------------------------------------

test('page: the presentation is embedded, and every inline style and script is pinned by the policy', () => {
  const p = whole()
  const html = renderHtml(p)
  assert.match(html, /^<!doctype html>/i)
  const data = html.match(/<script type="application\/json" id="etc-data">([\s\S]*?)<\/script>/)
  assert.ok(data, 'the presentation is in the page')
  assert.equal(JSON.parse(data[1]).id, p.id)
  const csp = policyOf(html)
  assert.ok(csp, 'the page carries a security policy')
  const { style, script } = inlineHashes(html)
  assert.ok(csp.includes(`style-src ${style}`), 'the inline style is the one the policy allows')
  assert.ok(csp.includes(`script-src ${script}`), 'the inline script is the one the policy allows')
  assert.match(csp, /default-src 'none'/)
  assert.match(csp, /connect-src 'none'/)
  assert.equal((html.match(/<script>/g) || []).length, 1, 'exactly one runnable script')
  assert.equal((html.match(/<style>/g) || []).length, 1, 'exactly one style block')
  assert.ok(!/\{\{[A-Z]+\}\}/.test(html), 'every placeholder is filled')
})

test('page: nothing is loaded from anywhere — no outside scripts, styles, fonts or images', () => {
  const html = renderHtml(whole())
  assert.ok(!/<(script|link|img|iframe|audio|video|source)[^>]+(src|href)=["']?(https?:)?\/\//i.test(html))
  assert.ok(!/@import|url\(\s*["']?(https?:)?\/\//i.test(html))
})

test('page: words in the change cannot break out of the data', () => {
  const p = whole()
  p.summary = 'Ends early </script><script>alert(1)</script> and <!-- here'
  p.title = 'A "title" <b>with</b> & marks'
  const html = renderHtml(p)
  assert.ok(!html.includes('</script><script>alert(1)'))
  assert.ok(!html.includes('<!-- here'))
  assert.match(html, /<title>A &quot;title&quot; &lt;b&gt;with&lt;\/b&gt; &amp; marks · Explain This Change<\/title>/)
  const data = html.match(/<script type="application\/json" id="etc-data">([\s\S]*?)<\/script>/)
  assert.equal(JSON.parse(data[1]).summary, p.summary)
  assert.equal(scriptJson('a b c'), '"a\\u2028b\\u2029c"')
})

test('page: a "$&" in the code is copied as written, not treated as a pattern', () => {
  const p = whole()
  p.summary = 'costs $& and $1 and $$'
  const html = renderHtml(p)
  const data = html.match(/<script type="application\/json" id="etc-data">([\s\S]*?)<\/script>/)
  assert.equal(JSON.parse(data[1]).summary, 'costs $& and $1 and $$')
})

test('page: theme and accent come from the settings; a bad accent falls back safely', () => {
  const p = whole()
  p.player.theme = 'dark'
  p.player.accent = 'red; background:url(x)'
  const html = renderHtml(p)
  assert.match(html, /<html lang="en" data-theme="dark">/)
  assert.match(html, /--accent:#2563EB/)
  assert.equal(cleanAccent('#0a8'), '#00AA88')
  assert.equal(cleanAccent('#12ab9F'), '#12AB9F')
  assert.equal(onAccent('#FFFF00'), '#111111')
  assert.equal(onAccent('#1E3A8A'), '#FFFFFF')
  p.player.theme = 'auto'
  assert.match(renderHtml(p), /<html lang="en">/)
})

test('page: it may only talk to the ask and save addresses it was given', () => {
  assert.equal(connectSources([]), "'none'")
  assert.equal(connectSources(['/ask', '/save']), "'self'")
  assert.equal(connectSources(['https://review.example.com/x/ask', 'http://127.0.0.1:4848/save']), 'https://review.example.com http://127.0.0.1:4848')
  assert.throws(() => connectSources(['javascript:alert(1)']), /not an http\(s\) address/)
  assert.throws(() => connectSources(['//elsewhere.example']), /not an address the player can ask/)
  const html = renderHtml(whole(), { askEndpoint: '/ask', token: 'abc' })
  assert.match(policyOf(html), /connect-src 'self'/)
  assert.match(html, /"token":"abc"/)
})

test('page: the player script is one closure that parses', () => {
  const js = playerScript()
  assert.match(js, /^\(function \(\) \{\n'use strict';/)
  assert.doesNotThrow(() => new Function(js))
})

// ---- in a real browser -------------------------------------------------------------------------

let hasBrowser = true
try { await import('playwright') } catch { hasBrowser = false }
const browserTest = (name, fn) => test(name, { skip: hasBrowser ? false : 'the browser helper (optional) is not installed here' }, fn)

async function review(p, opts = {}) {
  const dir = temp()
  const file = join(dir, 'explain.html')
  writeFileSync(file, renderHtml(p))
  return reviewHtml(file, p, { playLines: 0, ...opts })
}
const lineCount = (p) => ['quick', 'deep'].reduce((n, d) => n + p.depths[d].reduce((m, c) => m + c.lines.length, 0), 0)

browserTest('browser: the whole change — every line lights exactly what it cites, both layouts, desktop and phone', async () => {
  const p = whole()
  const out = await review(p)
  assert.deepEqual(out.problems, [])
  assert.equal(out.checked, lineCount(p) * 2 * 2)
})

browserTest('browser: one hunk with a question — the answer plays first and every line lights what it cites', async () => {
  const p = oneHunk()
  assert.equal(p.depths.deep[0].kind, 'answer')
  const out = await review(p, { playLines: 3 })
  assert.deepEqual(out.problems, [])
  assert.ok(out.checked >= lineCount(p) * 2 * 2)
})

browserTest('browser: the check catches a line that lights the wrong code', async () => {
  const p = whole()
  const bad = clone(p)
  const line = bad.depths.deep.find((c) => c.kind === 'change').lines[0]
  const want = { ...line.show }
  // The page is drawn from the doctored copy; the check compares with the truth.
  line.show.from += 1
  line.show.to += 1
  const dir = temp()
  const file = join(dir, 'bad.html')
  writeFileSync(file, renderHtml(bad))
  const out = await reviewHtml(file, p, { widths: [1280], views: ['unified'], playLines: 0 })
  assert.ok(out.problems.some((m) => m.includes(line.id) && /lit lines/.test(m)), `expected a complaint about ${line.id} (${want.from}–${want.to})`)
})
