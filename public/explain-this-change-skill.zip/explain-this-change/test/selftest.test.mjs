// The self-test: it passes on a sound copy, and — the point of it — it notices when a safeguard
// has stopped saying no. A self-test that cannot be shown failing would always report "all passed".
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
import { SKILL_DIR } from '../scripts/lib/project.mjs'
import { selftest } from '../scripts/lib/selftest.mjs'

const acceptEverything = () => ({ hard: [], soft: [] })

test('selftest: every safeguard on this copy catches its doctored example', async () => {
  const lines = []
  const { results, failed } = await selftest({ log: (s) => lines.push(s) })
  assert.deepEqual(failed, [])
  assert.ok(results.length >= 15, `only ${results.length} checks ran`)
  // The browser check is the only one allowed to be skipped, and only when the browser is missing.
  for (const r of results.filter((x) => x.ok === null)) assert.match(r.detail, /hidden browser is not downloaded/)
  assert.ok(lines.some((l) => /✓ A line pointing past the end/.test(l)))
})

test('selftest: a line checker that accepts everything is reported, case by case', async () => {
  const { results, failed } = await selftest({ swap: { checkScript: acceptEverything } })
  const names = failed.map((r) => r.name)
  // The clean explanation still passes; every doctored one now slips through and is named.
  assert.ok(results.find((r) => r.name === 'The ready-made explanation passes').ok)
  for (const want of [/past the end/, /never shown/, /guessed reason/, /not in the change/, /nothing to show it/, /never-show list/, /word for word/, /question first/]) {
    assert.ok(names.some((n) => want.test(n)), `expected "${want}" among the failures: ${names.join(' | ')}`)
  }
  assert.ok(failed.every((r) => r.detail === 'nothing was refused'), failed.map((r) => r.detail).join(' | '))
})

test('selftest: a product checker that accepts everything is reported too', async () => {
  const { failed } = await selftest({ swap: { checkProductScript: acceptEverything } })
  assert.deepEqual(failed.map((r) => r.name), [
    'A picture of a page that is not allowed is refused',
    'Code words in a recap are sent back to be said plainly',
  ])
})

test('selftest: the command says so and finishes 0 on a sound copy', () => {
  const r = spawnSync(process.execPath, [join(SKILL_DIR, 'scripts', 'explain.mjs'), 'selftest'], { encoding: 'utf8', timeout: 120000 })
  assert.equal(r.status, 0, r.stdout + r.stderr)
  assert.match(r.stdout, /Nothing leaves this computer/)
  assert.match(r.stdout, /All \d+ passed/)
})
