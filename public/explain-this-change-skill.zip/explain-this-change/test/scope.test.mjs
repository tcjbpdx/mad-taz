import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseDiff } from '../scripts/lib/diff.mjs'
import { applyScope, scopeFromFlags } from '../scripts/lib/scope.mjs'

const d = parseDiff(`diff --git a/a.js b/a.js
--- a/a.js
+++ b/a.js
@@ -1,3 +1,3 @@
 one
-two
+TWO
 three
@@ -20,3 +20,4 @@
 twenty
+new
 twenty-one
 twenty-two
diff --git a/b.js b/b.js
--- a/b.js
+++ b/b.js
@@ -5,2 +5,2 @@
-x
+y
 z
`)

test('reads scopes from the command line', () => {
  assert.deepEqual(scopeFromFlags({}), { kind: 'whole' })
  assert.deepEqual(scopeFromFlags({ file: 'a.js', question: ' why? ' }), { kind: 'file', file: 'a.js', question: 'why?' })
  assert.deepEqual(scopeFromFlags({ lines: 'a.js:20-22' }), { kind: 'lines', file: 'a.js', side: 'after', from: 20, to: 22 })
  assert.deepEqual(scopeFromFlags({ lines: 'before:a.js:2' }), { kind: 'lines', file: 'a.js', side: 'before', from: 2, to: 2 })
  assert.deepEqual(scopeFromFlags({ hunk: 'h2' }), { kind: 'hunk', id: 'h2' })
  assert.deepEqual(scopeFromFlags({ hunk: 'b.js:5' }), { kind: 'hunk', file: 'b.js', side: 'after', line: 5 })
  assert.throws(() => scopeFromFlags({ lines: 'a.js' }), /should look like/)
})

test('whole, file, lines and hunk scopes keep the right hunks, with their original ids', () => {
  assert.deepEqual(applyScope(d, { kind: 'whole' }).hunks.map((h) => h.id), ['h1', 'h2', 'h3'])
  assert.deepEqual(applyScope(d, { kind: 'file', file: 'b.js' }).hunks.map((h) => h.id), ['h3'])
  const lines = applyScope(d, { kind: 'lines', file: 'a.js', from: 21, to: 21, question: 'what is new?' })
  assert.deepEqual(lines.hunks.map((h) => h.id), ['h2'])
  assert.deepEqual(lines.focus, { file: 'a.js', side: 'after', from: 21, to: 21 })
  assert.equal(lines.scope.question, 'what is new?')
  assert.equal(lines.files.length, 1)
  const hunk = applyScope(d, { kind: 'hunk', file: 'a.js', line: 2, side: 'before' })
  assert.equal(hunk.hunks[0].id, 'h1')
  assert.equal(applyScope(d, { kind: 'hunk', id: 'h3' }).label, 'b.js, one change (h3)')
})

test('says plainly when a scope points at nothing', () => {
  assert.throws(() => applyScope(d, { kind: 'file', file: 'c.js' }), /not one of the files.*a\.js, b\.js/)
  assert.throws(() => applyScope(d, { kind: 'lines', file: 'a.js', from: 10, to: 12 }), /did not change/)
  assert.throws(() => applyScope(d, { kind: 'hunk', id: 'h9' }), /h1 to h3/)
})
