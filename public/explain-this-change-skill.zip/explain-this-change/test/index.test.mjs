// The front door: explain() keeps what it makes and reuses it, and ask() answers a question
// mid-play, checked like the script, added to the explainer, and never twice for the same question.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { CheckFailed, Problem, ask, explain, history, readExplainer } from '../index.mjs'
import { renderHtml } from '../scripts/lib/render.mjs'
import { reviewHtml } from '../scripts/lib/review.mjs'
import { H2_FOLLOW_UP, H2_QUESTION, clone, h2FollowUpAnswer, h2QuestionScript, wholeScript } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

const temp = () => mkdtempSync(join(tmpdir(), 'etc-index-'))
const source = () => {
  const s = sampleRepo()
  return { kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }
}
const H2 = { kind: 'hunk', id: 'h2', question: H2_QUESTION }

/** A stand-in for Claude that counts its calls and hands out answers per purpose. */
function fakeWriter({ explain: e = [h2QuestionScript()], ask: a = [h2FollowUpAnswer()] } = {}) {
  const calls = { explain: 0, ask: 0, prompts: [] }
  const writer = async ({ purpose, prompt }) => {
    calls.prompts.push(prompt)
    const list = purpose === 'ask' ? a : e
    const n = calls[purpose]++
    return clone(list[Math.min(n, list.length - 1)])
  }
  return { writer, calls }
}

/** One explainer of h2 with its question, kept in a fresh store. */
async function madeH2(extra = {}) {
  const store = temp()
  const w = fakeWriter(extra)
  const r = await explain(source(), H2, { store, writer: w.writer, settings: { project_name: 'Parcel Pigeon' } })
  return { store, r, ...w }
}

// ---- explain ----------------------------------------------------------------------------------

test('explain: makes the explainer, keeps it in its own folder, and the kept page opens on its own', async () => {
  const progress = []
  const store = temp()
  const { writer, calls } = fakeWriter()
  const r = await explain(source(), H2, { store, writer, onProgress: (p) => progress.push(p.stage) })
  assert.equal(calls.explain, 1)
  assert.equal(r.cached, false)
  assert.match(r.id, /^[0-9a-f]{16}$/)
  assert.equal(r.presentation.id, r.id)
  assert.equal(r.presentation.depths.deep[0].kind, 'answer')
  assert.ok(existsSync(join(store, r.id, 'presentation.json')))
  assert.ok(existsSync(join(store, r.id, 'ask.json')))
  const kept = readFileSync(r.path, 'utf8')
  assert.match(kept, /connect-src (?:'|&#x27;)none(?:'|&#x27;)/, 'the kept copy talks to nothing')
  assert.deepEqual(progress.filter((s) => ['context', 'write', 'check', 'build', 'done'].includes(s)), ['context', 'write', 'check', 'build', 'done'])
})

test('explain: the same change, scope and question a second time is reused, with no call to Claude', async () => {
  const { store, r, writer, calls } = await madeH2()
  const again = await explain(source(), H2, { store, writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.equal(calls.explain, 1)
  assert.equal(again.cached, true)
  assert.equal(again.id, r.id)
  assert.equal(again.usage.requests, 0)
})

test('explain: a different question, scope or writer setting is a different explainer', async () => {
  const { store, r } = await madeH2()
  const other = fakeWriter({ explain: [wholeScript()] })
  const whole = await explain(source(), { kind: 'whole' }, { store, writer: other.writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.notEqual(whole.id, r.id)
  const q2 = fakeWriter()
  const asked = await explain(source(), { ...H2, question: `${H2_QUESTION} Really?` }, { store, writer: q2.writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.notEqual(asked.id, r.id)
  assert.equal(q2.calls.explain, 1)
})

test('explain: who writes it is part of what is kept, so a different writer never gets another writer\'s explanation', async () => {
  const { store, r } = await madeH2()
  const named = (key) => { const w = fakeWriter(); w.writer.cacheKey = key; return w }
  const first = named('house-writer')
  const a = await explain(source(), H2, { store, writer: first.writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.notEqual(a.id, r.id, 'a writer with its own name is not the unnamed one')
  assert.equal(first.calls.explain, 1)
  const again = named('house-writer')
  const b = await explain(source(), H2, { store, writer: again.writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.equal(b.id, a.id, 'the same name is the same writer, even as a new function')
  assert.equal(b.cached, true)
  assert.equal(again.calls.explain, 0)
  const other = named('another-writer')
  const c = await explain(source(), H2, { store, writer: other.writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.notEqual(c.id, a.id)
  const { offlineWriter } = await import('../examples/parcel-pigeon/answers.mjs')
  assert.equal(offlineWriter().cacheKey, 'offline-practice')
})

test('explain: a kept explainer takes today\'s look, and today\'s never-show list still refuses it', async () => {
  const { store, r, writer } = await madeH2()
  const dark = await explain(source(), H2, { store, writer, settings: { project_name: 'Parcel Pigeon', look: { theme: 'dark' } } })
  assert.equal(dark.id, r.id)
  assert.equal(dark.presentation.player.theme, 'dark')
  await assert.rejects(
    explain(source(), H2, { store, writer, settings: { project_name: 'Parcel Pigeon' }, neverShow: ['registerWebhook'] }),
    (e) => e instanceof CheckFailed && /never-show/.test(e.message),
  )
})

test('explain: with no store nothing is kept, and the page gets the ask address it was given', async () => {
  const { writer } = fakeWriter()
  const r = await explain(source(), H2, { store: null, writer, askEndpoint: '/ask', token: 't0k3n' })
  assert.equal(r.dir, null)
  assert.match(r.html, /connect-src (?:'|&#x27;)self(?:'|&#x27;)/)
  assert.ok(r.askContext && r.askContext.hunks.length === 1)
})

// ---- ask --------------------------------------------------------------------------------------

test('ask: answers by id, places the answer after the chapter it was asked in, and keeps it', async () => {
  const { store, r, writer, calls } = await madeH2()
  const res = await ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd3', line: 'd3.2', depth: 'deep' }, { store, writer })
  assert.equal(calls.ask, 1)
  assert.equal(res.answer.id, 'a1')
  assert.equal(res.answer.after, 'd3')
  assert.equal(res.answer.question, H2_FOLLOW_UP)
  assert.deepEqual(res.answer.chapter.lines.map((l) => l.id), ['a1.1', 'a1.2', 'a1.3'])
  assert.equal(res.answer.chapter.lines[1].show.fn, 'request', 'each code line knows the function it sits in')
  const prompt = calls.prompts.at(-1)
  assert.match(prompt, /## Where they paused\nIn "request\(\) retries", just after: Now the same fetch/)
  assert.match(prompt, /## The question\nWhat happens when the carrier stays down\?/)
  const kept = readExplainer(store, r.id)
  assert.equal(kept.presentation.answers.length, 1)
  assert.match(readFileSync(kept.path, 'utf8'), /When the carrier stays down/, 'the kept page includes the answer')
})

test('ask: the same question at the same place is answered from what was kept', async () => {
  const { store, r, writer, calls } = await madeH2()
  const body = { question: H2_FOLLOW_UP, chapter: 'd3', depth: 'deep' }
  await ask(r.id, body, { store, writer })
  const again = await ask(r.id, { ...body, question: '  what happens when the CARRIER stays down ' }, { store, writer })
  assert.equal(calls.ask, 1)
  assert.equal(again.cached, true)
  assert.equal(again.answer.id, 'a1')
  const elsewhere = await ask(r.id, { ...body, chapter: 'd2' }, { store, writer })
  assert.equal(elsewhere.answer.id, 'a2', 'asked at another place, it is a new answer')
})

test('ask: a question asked during an answer goes after the chapter that answer went after', async () => {
  const { store, r, writer } = await madeH2()
  await ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd3', depth: 'deep' }, { store, writer })
  const res = await ask(r.id, { question: 'And the four seconds?', chapter: 'a1', line: 'a1.1', depth: 'deep' }, { store, writer })
  assert.equal(res.answer.after, 'd3')
})

test('ask: an answer that cites code it was not shown is sent back once, then accepted', async () => {
  const bad = h2FollowUpAnswer()
  bad.lines[1].show = { type: 'code', hunk: 'h4', file: '', side: 'after', from: 1, to: 5, item: -1 }
  const { store, r, writer, calls } = await madeH2({ ask: [bad, h2FollowUpAnswer()] })
  const res = await ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd2', depth: 'deep' }, { store, writer })
  assert.equal(calls.ask, 2)
  assert.match(calls.prompts.at(-1), /hunk "h4", which is not in scope/)
  assert.equal(res.answer.chapter.lines[1].show.hunk, 'h2')
})

test('ask: an answer that still fails, or claims tests pass with no proof, is refused and nothing is kept', async () => {
  const bad = h2FollowUpAnswer()
  bad.lines[0].say = 'The tests pass, so this is fine.'
  const { store, r, writer, calls } = await madeH2({ ask: [bad] })
  const err = await ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd2', depth: 'deep' }, { store, writer }).catch((e) => e)
  assert.ok(err instanceof CheckFailed)
  assert.equal(calls.ask, 2)
  assert.ok(err.details.some((d) => /nothing shows tests or checks passing/.test(d)))
  assert.equal(readExplainer(store, r.id).presentation.answers.length, 0)
})

test('ask: a never-show word in the answer is refused', async () => {
  const { store, r, writer } = await madeH2()
  const err = await ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd2', depth: 'deep' }, { store, writer, neverShow: ['four seconds'] }).catch((e) => e)
  assert.ok(err instanceof CheckFailed)
})

test('ask: works on an explainer held in memory, with no store', async () => {
  const { writer } = fakeWriter()
  const r = await explain(source(), H2, { store: null, writer })
  const res = await ask(r, { question: H2_FOLLOW_UP, chapter: 'd2', depth: 'deep' }, { store: null, writer })
  assert.equal(res.answer.id, 'a1')
  assert.equal(res.presentation.answers.length, 1)
  assert.equal(r.presentation.answers.length, 0, 'the original is left as it was')
})

test('ask: a bad id, an empty question or a missing explainer is a plain problem', async () => {
  const { store, r, writer } = await madeH2()
  await assert.rejects(ask('../../etc', { question: 'why?' }, { store, writer }), (e) => e instanceof Problem && /not an explainer id/.test(e.message))
  await assert.rejects(ask(r.id, { question: '  ' }, { store, writer }), /Type a question first/)
  await assert.rejects(ask(r.id, { question: 'x'.repeat(600) }, { store, writer }), /keep it under 500/)
  await assert.rejects(ask('0123456789abcdef', { question: 'why?' }, { store, writer }), /There is no explainer/)
})

test('ask: a chapter that is not there, or too short a question, is said plainly and nothing is asked', async () => {
  const { store, r, writer, calls } = await madeH2()
  await assert.rejects(ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd99', depth: 'deep' }, { store, writer }),
    (e) => e instanceof Problem && /There is no chapter "d99" in the DEEP DIVE version of this explanation\. Its chapters are: d1 \(/.test(e.message))
  await assert.rejects(ask(r.id, { question: 'ok' }, { store, writer }), (e) => e instanceof Problem && /"ok" is too short to answer/.test(e.message))
  assert.equal(calls.ask, 0)
})

test('history: lists what was kept, newest first', async () => {
  const { store, r } = await madeH2()
  const list = await history({ store })
  assert.equal(list.length, 1)
  assert.equal(list[0].id, r.id)
  assert.equal(list[0].question, H2_QUESTION)
})

test('history: a row holding a word from today\'s never-show list keeps only its id and date', async () => {
  const { store, r } = await madeH2()
  const [row] = await history({ store, neverShow: ['Retry'] })
  assert.equal(row.id, r.id)
  assert.equal(row.hidden, true)
  assert.match(row.title, /^Hidden: it holds a word from the never-show list$/)
  assert.equal(row.question, undefined)
  assert.doesNotMatch(JSON.stringify(row), /retry/i)
  assert.deepEqual(await history({ store, neverShow: ['retry'], search: 'retry' }), [], 'searching for the word does not find it either')
  assert.equal((await history({ store, neverShow: ['nothing-like-this'] }))[0].hidden, undefined)
})

// ---- in a real browser -------------------------------------------------------------------------

let hasBrowser = true
try { await import('playwright') } catch { hasBrowser = false }

test('browser: an answer added mid-play lights exactly what it cites, like every other line', { skip: hasBrowser ? false : 'the browser helper (optional) is not installed here' }, async () => {
  const { store, r, writer } = await madeH2()
  const res = await ask(r.id, { question: H2_FOLLOW_UP, chapter: 'd3', depth: 'deep' }, { store, writer })
  const file = join(temp(), 'with-answer.html')
  writeFileSync(file, renderHtml(res.presentation))
  const out = await reviewHtml(file, res.presentation, { widths: [1280], playLines: 0 })
  assert.deepEqual(out.problems, [])
})
