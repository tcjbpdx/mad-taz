import { test } from 'node:test'
import assert from 'node:assert/strict'
import { functionAt, gitPath, languageOf, listing, parseDiff } from '../scripts/lib/diff.mjs'

const DIFF = `diff --git a/src/a.js b/src/a.js
index 111..222 100644
--- a/src/a.js
+++ b/src/a.js
@@ -1,4 +1,5 @@ export function go() {
 const a = 1
-const b = 2
+const b = 3
+const c = 4
 
 export default a
@@ -10 +11 @@
-old
+new
\\ No newline at end of file
diff --git a/new.txt b/new.txt
new file mode 100644
--- /dev/null
+++ b/new.txt
@@ -0,0 +1,2 @@
+--- looks like a header
++++ and so does this
diff --git a/img.png b/img.png
Binary files a/img.png and b/img.png differ
diff --git a/old name.js b/new name.js
similarity index 100%
rename from old name.js
rename to new name.js
`

test('reads files, hunks and line numbers', () => {
  const d = parseDiff(DIFF)
  assert.deepEqual(d.files.map((f) => [f.path, f.status]), [['src/a.js', 'modified'], ['new.txt', 'added'], ['img.png', 'modified'], ['new name.js', 'renamed']])
  assert.deepEqual(d.hunks.map((h) => h.id), ['h1', 'h2', 'h3'])
  const h1 = d.hunks[0]
  assert.equal(h1.section, 'export function go() {')
  assert.deepEqual(h1.rows.map((r) => [r.t, r.old, r.new]), [['ctx', 1, 1], ['del', 2, null], ['add', null, 2], ['add', null, 3], ['ctx', 3, 4], ['ctx', 4, 5]])
  assert.equal(d.hunks[1].oldLines, 1)
  assert.equal(d.hunks[1].rows.at(-1).noEol, true)
  assert.equal(d.files[2].binary, true)
  assert.equal(d.files[3].oldPath, 'old name.js')
  assert.equal(d.files[0].added, 3)
  assert.equal(d.files[0].removed, 2)
})

test('a line that looks like a header inside a hunk stays a line', () => {
  const d = parseDiff(DIFF)
  assert.deepEqual(d.hunks[2].rows.map((r) => r.text), ['--- looks like a header', '+++ and so does this'])
})

test('reads a plain diff with no "diff --git" lines', () => {
  const d = parseDiff('--- a/x.py\n+++ b/x.py\n@@ -1 +1 @@\n-a\n+b\n--- a/y.py\n+++ b/y.py\n@@ -2 +2 @@\n-c\n+d\n')
  assert.deepEqual(d.files.map((f) => f.path), ['x.py', 'y.py'])
  assert.deepEqual(d.hunks.map((h) => h.file), ['x.py', 'y.py'])
})

test('unquotes git paths', () => {
  assert.equal(gitPath('"a/caf\\303\\251.js"'), 'café.js')
  assert.equal(gitPath('/dev/null'), null)
})

test('names the function a line sits in', () => {
  const js = [
    "import x from 'y'",
    'const TIMEOUT = 1',
    '',
    'async function request(path) {',
    '  return withRetry(async () => {',
    '    const res = await fetch(path)',
    '    if (!res.ok) {',
    '      throw new Error()',
    '    }',
    '  })',
    '}',
    'const isRetryable = (err) => err.status >= 500',
    'class Thing {',
    '  method(a) {',
    '    return a',
    '  }',
    '}',
  ]
  assert.equal(functionAt(js, 2), null)
  assert.equal(functionAt(js, 6), 'request')
  assert.equal(functionAt(js, 8), 'request')
  assert.equal(functionAt(js, 12), 'isRetryable')
  assert.equal(functionAt(js, 15), 'method')
  const py = ['class A:', '    def go(self):', '        if x:', '            return 1']
  assert.equal(functionAt(py, 4), 'go')
})

test('the listing Claude reads carries ids and both line numbers', () => {
  const d = parseDiff(DIFF)
  const text = listing(d.files, { fnOf: (h) => (h.id === 'h1' ? ['go'] : []) })
  assert.match(text, /### h1 · src\/a\.js · modified · in go\(\)/)
  assert.match(text, /\n {4}2 {7}- const b = 2\n/)
  assert.match(text, /\n {10}2 \+ const b = 3\n/)
  assert.match(text, /img\.png · modified · binary file/)
})

test('knows common languages', () => {
  assert.equal(languageOf('src/a.tsx'), 'typescript')
  assert.equal(languageOf('Dockerfile'), 'dockerfile')
  assert.equal(languageOf('notes'), 'plaintext')
})
