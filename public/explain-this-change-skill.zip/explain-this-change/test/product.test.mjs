// Product mode: a plain-English recap with pictures of the app. The checks that keep it plain and
// traceable to the change, the engine run (with a stand-in for the browser, then with the real one on
// the practice project's own tracking page), questions asked mid-play, saving, and the setup check.
// The practice tracking page runs on this computer with a pretend carrier: nothing is sent anywhere.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ask, explain } from '../index.mjs'
import { NeedsYou, Problem, SKILL_DIR } from '../scripts/lib/project.mjs'
import { openSource } from '../scripts/lib/source.mjs'
import { applyScope } from '../scripts/lib/scope.mjs'
import { buildContext } from '../scripts/lib/context.mjs'
import { checkContext } from '../scripts/lib/script.mjs'
import { allowedPages, checkProductScript, codeWords, tidyProductScript } from '../scripts/lib/product.mjs'
import { browserReady, takePictures } from '../scripts/lib/pictures.mjs'
import { commentBody } from '../scripts/lib/save.mjs'
import { renderHtml } from '../scripts/lib/render.mjs'
import { reviewHtml } from '../scripts/lib/review.mjs'
import { buildSample, startSamplePage } from '../scripts/lib/sample.mjs'
import { settingsFromObject } from '../scripts/lib/settings.mjs'
import { PRODUCT_FOLLOW_UP, PRODUCT_PAGES, clone, offlineWriter, productFollowUpAnswer, productWholeScript } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

const temp = () => mkdtempSync(join(tmpdir(), 'etc-product-'))
const BUSY = 'The carrier is busy. Try again in a minute'
const source = () => {
  const s = sampleRepo()
  return { kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }
}
/** Product settings for the practice project; app_url is only used where a test takes real pictures. */
const productSettings = (extra = {}) => ({
  project_name: 'Parcel Pigeon', mode: 'product', source: { use_github: false }, voice: { service: 'none' },
  product: { enabled: true, app_url: 'http://127.0.0.1:9', pages: PRODUCT_PAGES, ...extra },
})

let opened = null
function setup(scope = { kind: 'whole' }, extra = {}) {
  if (!opened) opened = openSource({ ...source() }, { settings: { source: { use_github: false } } })
  const scoped = applyScope(opened.diff, scope)
  const context = buildContext(opened, scoped)
  const ctx = checkContext({ src: opened, scoped, context, ...extra })
  const settings = settingsFromObject(productSettings())
  return { scoped, context, ctx, pages: allowedPages(settings, scoped, context) }
}
const check = (script, extra) => {
  const { ctx, pages } = setup({ kind: 'whole' }, extra)
  return checkProductScript(tidyProductScript(script), ctx, pages)
}

/** A stand-in for the browser: "takes" the pictures asked for, finding every word it is asked to. */
function fakeCapture({ skip = [] } = {}) {
  const calls = []
  const capture = async ({ pictures, points }) => {
    calls.push({ pictures, points })
    const boxes = (words) => Object.fromEntries(words.map((w, i) => [w, { x: 40, y: 100 + i * 40, w: 300, h: 28 }]))
    return {
      pictures: pictures.map((p, i) => (skip.includes(i) ? null : { page: p.page, label: p.label, src: 'data:image/jpeg;base64,AAAA', width: 1280, height: 800, boxes: boxes(points[i]) })),
      warnings: skip.map((i) => `Picture ${i + 1} (${pictures[i].page}) was not taken (a stand-in reason).`),
    }
  }
  return { capture, calls }
}

// ---- which pages, and plain words -------------------------------------------------------------

test('pages: the ones listed in settings win (the first word is the page, the rest a note)', () => {
  const { pages } = setup()
  assert.deepEqual(pages.map((p) => p.page), ['/', '/track/PP-2002', '/track/PP-3003'])
  assert.equal(pages[2].note, 'a parcel the carrier keeps failing on')
})

test('pages: with none listed, the front page and any page the change names in quotes, never a file or an API address', () => {
  const settings = settingsFromObject({ product: { enabled: true, app_url: 'http://127.0.0.1:9' } })
  const scoped = { hunks: [{ rows: [{ t: 'add', text: "router.get('/settings', show)" }, { t: 'add', text: "fetch('/api/parcels')" }, { t: 'add', text: "img.src = '/logo.png'" }, { t: 'del', text: "go('/old-page')" }] }] }
  const context = { excerpts: [{ side: 'after', lines: ["link('/help/')"] }, { side: 'before', lines: ["link('/gone')"] }] }
  assert.deepEqual(allowedPages(settings, scoped, context).map((p) => p.page), ['/', '/settings', '/help'])
})

test('plain words: file names, code names and developer words are caught; everyday words are not', () => {
  assert.deepEqual(codeWords('The page now says the carrier is busy, on your iPhone.'), [])
  assert.ok(codeWords('It changed format.js').includes('format.js'))
  assert.ok(codeWords('trackParcel now retries').includes('trackParcel'))
  assert.ok(codeWords('the carrier_busy status').includes('carrier_busy'))
  assert.ok(codeWords('the endpoint retries').includes('endpoint'))
})

// ---- the checker ------------------------------------------------------------------------------

test('the ready-made recap passes every check, with nothing to tidy', () => {
  const { hard, soft } = check(productWholeScript())
  assert.deepEqual(hard, [])
  assert.deepEqual(soft, [])
})

test('the checker refuses a page that is not allowed, a picture that does not exist, and words not in the code', () => {
  const s = productWholeScript()
  s.pictures[2].page = '/admin'
  s.deep[1].lines[0].show = { type: 'picture', item: 7, point_at: '' }
  s.quick[0].lines[1].show.point_at = 'Your parcel is safe with us'
  const { hard } = check(s)
  assert.ok(hard.some((h) => /pictures\[2\] is of "\/admin", which is not one of the ALLOWED PAGES/.test(h)), hard.join('\n'))
  assert.ok(hard.some((h) => /shows picture 7, but there are 3 pictures/.test(h)), hard.join('\n'))
  assert.ok(hard.some((h) => /points at "Your parcel is safe with us", which is not word for word in the code/.test(h)), hard.join('\n'))
})

test('the checker refuses a guessed why, a pass claim with no proof, and a never-show word; code words are sent back to be said plainly', () => {
  const s = productWholeScript()
  s.deep[3].why = 'To make the tests faster.' // why_source stays "none"
  s.deep[0].lines[1].say = 'All the tests pass now, so the page is ready.'
  s.summary = 'Parcel Pigeon now rides out carrier hiccups.'
  s.deep[2].lines[2].say = 'A 404 from the carrier still goes through trackParcel to the unknown label.'
  const { hard, soft } = check(s, { neverShow: ['pigeon'] })
  assert.ok(hard.some((h) => /Intent not stated/.test(h)), hard.join('\n'))
  assert.ok(hard.some((h) => /nothing shows tests or checks passing/.test(h)), hard.join('\n'))
  assert.ok(hard.some((h) => /never-show list/.test(h)), hard.join('\n'))
  assert.ok(soft.some((m) => /code or developer words/.test(m) && /trackParcel/.test(m)), soft.join('\n'))
})

test('the checker wants the question answered first, and the recap to end on what to check', () => {
  const s = productWholeScript()
  s.deep.push(s.deep.splice(4, 1)[0], s.deep.splice(1, 1)[0]) // move "what to check" off the end
  const { ctx, pages } = setup({ kind: 'whole', question: 'Will customers notice?' })
  const { hard } = checkProductScript(tidyProductScript(s), ctx, pages)
  assert.ok(hard.some((h) => /must start with an answer chapter/.test(h)), hard.join('\n'))
  assert.ok(hard.some((h) => /deep must end with the focus chapter/.test(h)), hard.join('\n'))
})

// ---- the engine --------------------------------------------------------------------------------

test('explain: a product recap carries its pictures, and each line keeps the picture and words it points at', async () => {
  const { capture, calls } = fakeCapture()
  const r = await explain(source(), { kind: 'whole' }, { store: temp(), writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  const p = r.presentation
  assert.equal(p.mode, 'product')
  assert.deepEqual(p.pictures.map((x) => x.page), ['/track/PP-3003', '/track/PP-2002', '/'])
  assert.deepEqual(calls[0].points, [[BUSY], ['On its way'], []], 'only the words lines point at are looked for, once each')
  assert.deepEqual(p.files, [], 'a recap shows no code')
  const first = p.depths.quick[0].lines[0]
  assert.equal(first.show.type, 'picture')
  assert.equal(first.show.item, 1)
  assert.equal(first.show.point_at, 'On its way')
  assert.match(r.html, /What to check/)
})

test('explain: a picture that could not be taken falls back to the card, and says so', async () => {
  const { capture } = fakeCapture({ skip: [0] })
  const r = await explain(source(), { kind: 'whole' }, { store: null, writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  const p = r.presentation
  assert.equal(p.pictures[0], null)
  const busyLine = p.depths.quick[0].lines[1]
  assert.equal(busyLine.show.type, 'card')
  assert.equal(busyLine.show.point_at, '')
  assert.ok(r.warnings.some((w) => /Picture 1 \(\/track\/PP-3003\) was not taken/.test(w)), r.warnings.join('\n'))
  assert.equal(p.focus.find((f) => f.kind === 'try_it').picture, -1, 'a focus item about a missing picture is about no picture')
})

test('explain: when no picture at all can be taken, it says every line shows its card', async () => {
  const { capture } = fakeCapture({ skip: [0, 1, 2] })
  const r = await explain(source(), { kind: 'whole' }, { store: null, writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  assert.ok(r.warnings.includes('No pictures of the app could be taken, so every line shows its card instead.'), r.warnings.join('\n'))
})

test('explain: product mode for one call needs product mode switched on; an unknown mode is a plain problem', async () => {
  const off = { project_name: 'Parcel Pigeon', source: { use_github: false }, voice: { service: 'none' } }
  await assert.rejects(explain(source(), { kind: 'whole' }, { store: null, writer: offlineWriter(), proof: null, settings: off, mode: 'product' }), (e) => e instanceof NeedsYou && /Product mode is off/.test(e.message))
  await assert.rejects(explain(source(), { kind: 'whole' }, { store: null, writer: offlineWriter(), proof: null, settings: off, mode: 'podcast' }), (e) => e instanceof Problem && /mode must be one of/.test(e.message))
})

test('explain: before Claude is asked anything, a product recap checks the app is answering', async () => {
  let asked = 0
  const writer = async () => { asked++; return productWholeScript() }
  const ready = await browserReady()
  await assert.rejects(explain(source(), { kind: 'whole' }, { store: null, writer, proof: null, settings: productSettings() }),
    (e) => e instanceof NeedsYou && (ready ? /not answering at http:\/\/127\.0\.0\.1:9/ : /hidden browser/).test(e.message))
  assert.equal(asked, 0, 'nothing is paid for when the pictures cannot be taken')
})

test('ask: a question mid-recap is answered in plain words, showing pictures already taken', async () => {
  const { capture } = fakeCapture()
  const store = temp()
  const r = await explain(source(), { kind: 'whole' }, { store, writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  const res = await ask(r.id, { question: PRODUCT_FOLLOW_UP, chapter: 'd3', depth: 'deep' }, { store, writer: offlineWriter(), settings: productSettings() })
  const lines = res.answer.chapter.lines
  assert.equal(lines.length, 3)
  assert.deepEqual(lines.map((l) => l.show.type), ['picture', 'picture', 'card'])
  assert.equal(lines[0].show.point_at, BUSY)
})

test('ask: an answer that points at a picture that was not taken shows the card instead', async () => {
  const { capture } = fakeCapture({ skip: [1] })
  const store = temp()
  const r = await explain(source(), { kind: 'whole' }, { store, writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  const res = await ask(r.id, { question: PRODUCT_FOLLOW_UP }, { store, writer: async () => clone(productFollowUpAnswer()), settings: productSettings() })
  assert.deepEqual(res.answer.chapter.lines.map((l) => l.show.type), ['picture', 'card', 'card'])
})

test('the offline stand-in says plainly what it has no ready-made answer for', async () => {
  const { capture } = fakeCapture()
  await assert.rejects(explain(source(), { kind: 'hunk', id: 'h3' }, { store: null, writer: offlineWriter(), capture, proof: null, settings: productSettings() }),
    (e) => e instanceof NeedsYou && /product mode has ready-made answers for two things only/.test(e.message))
})

test('saving: the comment is headed what to check, in plain labels, and carries no picture', async () => {
  const { capture } = fakeCapture()
  const r = await explain(source(), { kind: 'whole' }, { store: null, writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  const body = commentBody(r.presentation)
  assert.match(body, /#### What to check/)
  assert.match(body, /\*\*High\*\* · watch out: /)
  assert.match(body, /\*\*Medium\*\* · try this: Open parcel PP-3003/)
  assert.match(body, /no picture is put in this comment/)
  assert.doesNotMatch(body, /data:image|base64/)
  assert.doesNotMatch(body, /Review focus/)
})

test('explain: the proof chapter, its table and the saved comment are in plain words; Claude is still told the exact rows', async () => {
  const { capture } = fakeCapture()
  const prompts = []
  const offline = offlineWriter()
  const writer = async (a) => { prompts.push(a.prompt); return offline(a) }
  const r = await explain(source(), { kind: 'whole' }, { store: null, writer, capture, settings: productSettings() })
  assert.match(prompts[0], /test\/retry\.test\.js \(new\)/, 'Claude gets the file names, so its own lines can be exact')
  const p = r.presentation
  const chapter = p.depths.deep.find((c) => c.kind === 'proof')
  assert.ok(chapter, 'the deep version has its proof chapter')
  assert.ok(!p.depths.quick.some((c) => c.kind === 'proof'))
  const said = [p.proof.summary, ...p.proof.items.flatMap((i) => [i.label, i.detail]), ...chapter.lines.map((l) => l.say)].filter(Boolean)
  for (const w of said) {
    assert.deepEqual(codeWords(w), [], w)
    assert.doesNotMatch(w, /\/|→|run_tests|\btests?\b/i, w)
  }
  assert.equal(p.proof.summary, 'Nothing here shows the change working: no automatic checks were run and no results were read.')
  const body = commentBody(p)
  const proofPart = body.slice(body.indexOf('#### Proof'))
  assert.match(proofPart, /Automatic checks in this change.*1 new set and 1 updated set/)
  assert.doesNotMatch(proofPart, /\.js\b|run_tests|passing its tests/)
  assert.equal((body.match(/Nothing here shows the change working/g) || []).length, 1, 'said once, not twice')
})

// ---- the setup check ---------------------------------------------------------------------------

const CLI = join(SKILL_DIR, 'scripts', 'explain.mjs')
const cli = (args, env = {}) => {
  const r = spawnSync(process.execPath, [CLI, ...args], { cwd: SKILL_DIR, encoding: 'utf8', timeout: 60000, env: { ...process.env, EXPLAIN_DEBUG: '', ...env } })
  return { code: r.status, out: r.stdout, err: r.stderr }
}
const hasBrowser = await browserReady()
const browserTest = (name, fn) => test(name, { skip: hasBrowser ? false : 'the hidden browser (setup --browser) is not downloaded here' }, fn)

browserTest('doctor: a form sign-in with no test account stops; an app that is not running is only a note', async () => {
  const dir = buildSample(join(temp(), 'parcel-pigeon')).dir
  assert.equal(cli(['new', '--project', dir]).code, 0)
  writeFileSync(join(dir, 'answers.json'), JSON.stringify({ explain: [], ask: [] }))
  const settings = join(dir, 'explain-this-change', 'settings.yaml')
  const base = 'writer:\n  service: fixture\n  fixture: answers.json\nvoice:\n  service: none\nproduct:\n  enabled: yes\n  app_url: http://127.0.0.1:9\n'
  writeFileSync(settings, `${base}  sign_in:\n    method: form\n    page: /login\n    email_box: Email\n    password_box: Password\n    button: Sign in\n    done_when_you_see: Signed in\n`)
  const stop = cli(['doctor', '--project', dir], { APP_TEST_EMAIL: '', APP_TEST_PASSWORD: '' })
  assert.equal(stop.code, 2, stop.out + stop.err)
  assert.match(stop.err, /Signing in is set to form, but the test account is missing\.\nFix: Open private\.env/)

  writeFileSync(settings, base)
  const ok = cli(['doctor', '--project', dir])
  assert.equal(ok.code, 0, ok.out + ok.err)
  assert.match(ok.out, /• The app is not answering at http:\/\/127\.0\.0\.1:9 right now\. Start it before making a recap/)
  assert.match(ok.out, /Everything is ready\./)
})

// ---- real pictures of the practice tracking page -----------------------------------------------

browserTest('pictures: the practice tracking page is pictured for real, and each circle sits on the words it points at', async () => {
  const s = buildSample(join(temp(), 'parcel-pigeon'))
  const page = await startSamplePage(s.dir)
  try {
    const settings = settingsFromObject(productSettings({ app_url: page.url }))
    const { pictures, warnings } = await takePictures({
      pictures: [{ page: '/track/PP-3003', label: 'busy' }, { page: '/track/PP-2002', label: 'recovers' }, { page: '/track/PP-9999', label: 'unknown' }, { page: 'https://example.test/', label: 'elsewhere' }],
      points: [[BUSY, 'Words that are not on the page'], ['On its way'], [], []],
      settings,
    })
    assert.deepEqual(warnings, ['Picture 4 (https://example.test/) was not taken: it is not a page on the app\'s address.'])
    assert.ok(pictures[0] && pictures[1] && pictures[2], 'the three pages on the app are pictured')
    assert.equal(pictures[3], null)
    assert.deepEqual(Object.keys(pictures[0].boxes), [BUSY], 'words not on the page are not circled')
    assert.deepEqual(Object.keys(pictures[1].boxes), ['On its way'])
    assert.match(pictures[0].src, /^data:image\/jpeg;base64,/)

    // Is the box really on the words? The busy message is amber (#b45309): count amber pixels inside
    // the box, and in a box of the same size well below it, in the picture itself.
    const { chromium } = await import('playwright')
    const browser = await chromium.launch({ headless: true })
    try {
      const tab = await browser.newPage()
      const counts = await tab.evaluate(async ({ src, box }) => {
        const img = new Image()
        img.src = src
        await img.decode()
        const c = document.createElement('canvas')
        c.width = img.naturalWidth
        c.height = img.naturalHeight
        const g = c.getContext('2d')
        g.drawImage(img, 0, 0)
        const amber = (x, y, w, h) => {
          const d = g.getImageData(x, y, w, h).data
          let n = 0
          for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - 180) < 40 && Math.abs(d[i + 1] - 83) < 40 && d[i + 2] < 60) n++
          return n
        }
        return { inside: amber(box.x, box.y, box.w, box.h), below: amber(box.x, box.y + box.h * 3, box.w, box.h), size: [img.naturalWidth, img.naturalHeight] }
      }, { src: pictures[0].src, box: pictures[0].boxes[BUSY] })
      assert.deepEqual(counts.size, [pictures[0].width, pictures[0].height], 'the picture is the size the boxes are measured in')
      assert.ok(counts.inside > 200, `the amber message is inside its box (${counts.inside} amber pixels)`)
      assert.ok(counts.below < 20, `and not below it (${counts.below})`)
    } finally {
      await browser.close()
    }
  } finally {
    await page.stop()
  }
})

browserTest('browser: a recap with real pictures plays every line on the right picture, circling the right words, desktop and phone', async () => {
  const s = buildSample(join(temp(), 'parcel-pigeon'))
  const page = await startSamplePage(s.dir)
  let r
  try {
    r = await explain({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { kind: 'whole' }, { store: null, writer: offlineWriter(), proof: null, settings: productSettings({ app_url: page.url }) })
  } finally {
    await page.stop()
  }
  assert.deepEqual(r.warnings, [])
  assert.ok(r.presentation.pictures.every(Boolean), 'every picture was taken')
  const file = join(temp(), 'recap.html')
  writeFileSync(file, renderHtml(r.presentation))
  const out = await reviewHtml(file, r.presentation, { views: ['unified'], playLines: 2 })
  assert.deepEqual(out.problems, [])
  assert.ok(out.checked > 20)
})

test('the practice tracking page starts on a free port and stops cleanly', async () => {
  const s = buildSample(join(temp(), 'parcel-pigeon'))
  const page = await startSamplePage(s.dir)
  try {
    const home = await fetch(page.url)
    assert.equal(home.status, 200)
    assert.match(await home.text(), /Track a parcel/)
    const busy = await (await fetch(`${page.url}/track/PP-3003`)).text()
    assert.match(busy, /The carrier is busy\. Try again in a minute/)
    assert.match(busy, />Try again</)
  } finally {
    await page.stop()
  }
  await assert.rejects(fetch(page.url, { signal: AbortSignal.timeout(2000) }))
})

// A small server stands in for an app with a sign-in, for the by-hand hook (a test signs in for the person).
browserTest('by-hand sign-in: the hook signs in once, the sign-in is kept, and the next run reuses it', async () => {
  const server = createServer((req, res) => {
    const signedIn = /signed=yes/.test(req.headers.cookie || '')
    const html = (b) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end(`<!doctype html><title>t</title><body>${b}</body>`) }
    if (req.url === '/login') return html('<button onclick="document.cookie=\'signed=yes; path=/\'; location.href=\'/\'">Sign in</button>')
    if (!signedIn) { res.writeHead(302, { location: '/login' }); return res.end() }
    return html('<h1>Welcome back</h1><p>Your parcels</p>')
  })
  await new Promise((done) => server.listen(0, '127.0.0.1', done))
  const appUrl = `http://127.0.0.1:${server.address().port}`
  try {
    const settings = settingsFromObject({ product: { enabled: true, app_url: appUrl, sign_in: { method: 'by-hand', page: '/login', done_when_you_see: 'Welcome back' } } })
    const stateFile = join(temp(), 'product', 'signed-in.json')
    let signIns = 0
    const handSignIn = async (p) => { signIns++; await p.getByText('Sign in').click() }
    const first = await takePictures({ pictures: [{ page: '/', label: 'home' }], points: [['Your parcels']], settings, stateFile, handSignIn })
    assert.deepEqual(first.warnings, [])
    assert.deepEqual(Object.keys(first.pictures[0].boxes), ['Your parcels'])
    assert.equal(signIns, 1)
    const again = await takePictures({ pictures: [{ page: '/', label: 'home' }], points: [[]], settings, stateFile, handSignIn })
    assert.ok(again.pictures[0])
    assert.equal(signIns, 1, 'the kept sign-in is used; nobody is asked again')
  } finally {
    server.close()
  }
})

// The page check must be able to fail: the stand-in browser's "pictures" are not real images.
browserTest('the page check notices a picture that did not load', async () => {
  const { capture } = fakeCapture()
  const r = await explain(source(), { kind: 'whole' }, { store: null, writer: offlineWriter(), capture, proof: null, settings: productSettings() })
  const file = join(temp(), 'recap.html')
  writeFileSync(file, renderHtml(r.presentation))
  const out = await reviewHtml(file, r.presentation, { views: ['unified'], widths: [1280], themes: ['light'], playLines: 0 })
  assert.ok(out.problems.some((m) => /the picture "A parcel while the carrier keeps failing" did not load/.test(m)), out.problems.join('\n'))
})

// A small app with an email-and-password sign-in, for the form method. The account is made up for
// the test and set for this run only; private.env is never read or written.
browserTest('form sign-in: the test account signs in; a wrong password, a never-show word, an error page, a sign-in wall and another site are each said plainly', async () => {
  const EMAIL = 'tester@example.test'
  const PASSWORD = 'not-a-real-password'
  const server = createServer((req, res) => {
    const signedIn = /signed=yes/.test(req.headers.cookie || '')
    const html = (b, status = 200) => { res.writeHead(status, { 'content-type': 'text/html' }); res.end(`<!doctype html><title>Stand-in app</title><body>${b}</body>`) }
    const url = new URL(req.url, 'http://x')
    if (url.pathname === '/login' && req.method === 'POST') {
      let body = ''
      req.on('data', (d) => { body += d })
      req.on('end', () => {
        const f = new URLSearchParams(body)
        if (f.get('email') === EMAIL && f.get('password') === PASSWORD) { res.writeHead(303, { 'set-cookie': 'signed=yes; path=/', location: '/' }); return res.end() }
        html('<p>That password is not right.</p>', 401)
      })
      return
    }
    if (url.pathname === '/login') return html('<form method="post" action="/login"><label>Email <input name="email"></label><label>Password <input name="password" type="password"></label><button>Sign in</button></form>')
    if (!signedIn || url.pathname === '/expired') { res.writeHead(302, { location: '/login' }); return res.end() }
    if (url.pathname === '/') return html('<h1>Welcome back</h1><p>Your parcels</p>')
    if (url.pathname === '/plans') return html('<h1>Plans</h1><p>Project Falcon launches soon</p>')
    if (url.pathname === '/away') { res.writeHead(302, { location: `http://localhost:${server.address().port}/` }); return res.end() }
    return html('<h1>Not found</h1>', 404)
  })
  await new Promise((done) => server.listen(0, '127.0.0.1', done))
  const appUrl = `http://127.0.0.1:${server.address().port}`
  const was = { e: process.env.APP_TEST_EMAIL, p: process.env.APP_TEST_PASSWORD }
  const signIn = { method: 'form', page: '/login', email_box: 'Email', password_box: 'Password', button: 'Sign in', done_when_you_see: 'Welcome back' }
  try {
    process.env.APP_TEST_EMAIL = EMAIL
    process.env.APP_TEST_PASSWORD = PASSWORD
    const settings = settingsFromObject({ product: { enabled: true, app_url: appUrl, sign_in: signIn } })
    const pages = ['/', '/plans', '/missing', '/expired', '/away'].map((page) => ({ page, label: page }))
    const r = await takePictures({ pictures: pages, points: [['Your parcels'], [], [], [], []], settings, neverShow: ['falcon'] })
    assert.ok(r.pictures[0], r.warnings.join('\n'))
    assert.deepEqual(Object.keys(r.pictures[0].boxes), ['Your parcels'])
    assert.deepEqual(r.pictures.slice(1), [null, null, null, null])
    assert.deepEqual(r.warnings, [
      'Picture 2 (/plans) was left out: the page shows a word from the never-show list.',
      'Picture 3 (/missing) was not taken: the app answered with an error (404).',
      'Picture 4 (/expired) was not taken: the app asked to sign in again.',
      'Picture 5 (/away) was not taken: the page sent the browser to another site.',
    ])

    process.env.APP_TEST_PASSWORD = 'a-wrong-password'
    await assert.rejects(takePictures({ pictures: [{ page: '/', label: 'home' }], points: [[]], settings }),
      (e) => e instanceof NeedsYou && /^Signing in to take the pictures did not work \(/.test(e.message) && !e.message.includes('a-wrong-password'))
  } finally {
    for (const [k, v] of [['APP_TEST_EMAIL', was.e], ['APP_TEST_PASSWORD', was.p]]) { if (v === undefined) delete process.env[k]; else process.env[k] = v }
    server.close()
  }
})

// The practice run, as someone trying the skill would start it: the tracking page starts with it,
// the review page's button makes a recap with real pictures, a question gets its ready-made answer,
// and stopping it stops the tracking page too. Its own temporary folder keeps it apart from the
// code-review practice run, which may be running at the same moment.
browserTest('try --product --offline: real pictures of the tracking page, a ready-made follow-up, and both pages stop together', async () => {
  const home = temp()
  const p = spawn(process.execPath, [CLI, 'try', '--product', '--offline', '--port', '0', '--no-open', '--quiet', '--project', temp()], { cwd: SKILL_DIR, env: { ...process.env, EXPLAIN_DEBUG: '', TMPDIR: home } })
  let out = ''
  let err = ''
  p.stdout.on('data', (d) => { out += d })
  p.stderr.on('data', (d) => { err += d })
  const ended = new Promise((done) => p.once('exit', (code) => done(code)))
  try {
    const deadline = Date.now() + 45000
    while (!/Stop it with Ctrl\+C/.test(out) && Date.now() < deadline && p.exitCode === null) await new Promise((r) => setTimeout(r, 100))
    assert.match(out, /Stop it with Ctrl\+C/, out + err)
    const review = /The practice review page: (http:\/\/127\.0\.0\.1:\d+)/.exec(out)[1]
    const tracking = /Parcel Pigeon's tracking page: (http:\/\/127\.0\.0\.1:\d+)/.exec(out)[1]
    assert.notEqual(review, tracking)
    assert.match(out, new RegExp(`In it, ask "${PRODUCT_FOLLOW_UP.replace('?', '\\?')}"`))

    const post = (path, body) => fetch(`${review}${path}`, { method: 'POST', headers: { 'content-type': 'application/json', origin: review }, body: JSON.stringify(body) })
    const lines = (await (await post('/explain', { scope: { kind: 'whole' } })).text()).trim().split('\n').map((l) => JSON.parse(l))
    assert.ok(lines.some((l) => l.stage === 'pictures'), 'it says it is taking the pictures')
    const done = lines.find((l) => l.done)
    assert.ok(done, JSON.stringify(lines))
    assert.deepEqual(done.done.warnings, [])
    const page = await (await fetch(`${review}${done.done.url}`)).text()
    assert.equal((page.match(/data:image\/jpeg;base64,/g) || []).length, 3, 'the three pictures are inside the page')

    const answer = await (await post('/ask', { id: done.done.id, question: PRODUCT_FOLLOW_UP, chapter: 'd3', depth: 'deep' })).json()
    assert.deepEqual(answer.answer.chapter.lines.map((l) => l.show.type), ['picture', 'picture', 'card'])

    const other = (await (await post('/explain', { scope: { kind: 'hunk', id: 'h3' } })).text()).trim().split('\n').map((l) => JSON.parse(l)).pop()
    assert.match(JSON.stringify(other), /ready-made answers for two things only/)

    p.kill('SIGINT')
    assert.equal(await ended, 0, err)
    assert.match(out, /Stopped\./)
    await assert.rejects(fetch(tracking, { signal: AbortSignal.timeout(2000) }), 'the tracking page stopped with it')
  } finally {
    if (p.exitCode === null) p.kill('SIGKILL')
  }
})
