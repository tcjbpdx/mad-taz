// Claude's reasoning: read only when switched on or when a session file is named, only the stretch
// of the session that wrote the changed files, plan notes only from inside the repository, and every
// quote checked word for word. Uses the practice project's made-up session.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { copyFileSync, mkdirSync, mkdtempSync, readFileSync, symlinkSync, utimesSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { explain } from '../index.mjs'
import { CheckFailed } from '../scripts/lib/project.mjs'
import { claudeSessionsFolder, gatherReasoning, readSession, sessionExcerpt } from '../scripts/lib/reasoning.mjs'
import { buildSample } from '../scripts/lib/sample.mjs'
import { defaultSettings } from '../scripts/lib/settings.mjs'
import { openSource } from '../scripts/lib/source.mjs'
import { clone, wholeScript, withReasoning } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

const CHANGED = ['src/carrierClient.js', 'src/format.js', 'src/retry.js', 'src/trackingService.js', 'test/retry.test.js', 'test/trackingService.test.js']

function withReasoningSettings(r) {
  const settings = defaultSettings()
  settings.reasoning = { ...settings.reasoning, ...r }
  return settings
}

const open = (s, extra = {}) => openSource({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo, ...extra }, { settings: defaultSettings() })

/** A made-up session file: one line per entry. */
const sessionLines = (entries) => entries.map((e) => JSON.stringify(e)).join('\n') + '\n'
const entry = (type, content, extra = {}) => ({ type, timestamp: '2026-10-01T09:00:00Z', gitBranch: 'other', message: { role: type, content }, ...extra })

test('a session file reads as what was said and which files were written, without helpers or notes', () => {
  const s = sampleRepo()
  const session = readSession(s.sessionFile)
  assert.equal(session.date, '2026-11-03')
  assert.equal(session.branch, 'retry-carrier-lookups')
  assert.match(session.moments[0].text, /^Customers keep seeing/)
  assert.equal(session.moments[0].who, 'person')
  assert.ok(session.moments.some((m) => m.who === 'claude' && /Two places the retry could live/.test(m.text)))
  assert.ok(session.moments.some((m) => m.edit && m.edit.endsWith('/src/retry.js')))

  const dir = mkdtempSync(join(tmpdir(), 'etc-session-'))
  const file = join(dir, 'a.jsonl')
  writeFileSync(file, sessionLines([
    entry('user', [{ type: 'text', text: '<system-reminder>private note</system-reminder>Please add a cache.' }]),
    entry('assistant', [{ type: 'text', text: 'A helper said this.' }], { isSidechain: true }),
    entry('user', 'Caveat: a meta note', { isMeta: true }),
    entry('user', [{ type: 'tool_result', content: 'the output of a command' }]),
    entry('assistant', [{ type: 'text', text: 'I will add it.' }, { type: 'tool_use', name: 'Read', input: { file_path: '/x/src/a.js' } }, { type: 'tool_use', name: 'Edit', input: { file_path: '/x/src/a.js' } }]),
  ]) + 'not json\n')
  const m = readSession(file).moments
  assert.deepEqual(m, [{ who: 'person', text: 'Please add a cache.' }, { who: 'claude', text: 'I will add it.' }, { edit: '/x/src/a.js' }])
})

test('the excerpt is the stretch around the edits to the changed files, labelled, and cut to fit', () => {
  const s = sampleRepo()
  const session = readSession(s.sessionFile)
  const ex = sessionExcerpt(session, CHANGED)
  assert.match(ex.text, /^The person asked: Customers keep seeing/)
  assert.match(ex.text, /Claude: Two places the retry could live/)
  assert.match(ex.text, /The person asked: When it still fails after all the retries/)
  assert.equal(ex.edits, 3, "retry.js, carrierClient.js and trackingService.js")
  assert.equal(sessionExcerpt(session, ['src/nothing.js']).text, '', 'a session that never wrote the files gives nothing')
  const short = sessionExcerpt(session, CHANGED, 600)
  assert.ok(short.text.length <= 600)
  assert.match(short.text, /^The person asked: Customers keep seeing/, 'the request is always kept')
})

test('off by default: no session is read unless one is named, and nothing is said about it', async () => {
  const s = sampleRepo()
  const r = await gatherReasoning({ src: open(s), settings: defaultSettings() })
  assert.deepEqual(r, { sources: [], notes: [] })
  // Naming one is the say-so, even with read_sessions off.
  const named = await gatherReasoning({ src: open(s, { session: s.sessionFile }), settings: defaultSettings() })
  assert.equal(named.sources.length, 1)
  assert.equal(named.sources[0].id, 'session')
  assert.equal(named.sources[0].label, 'Claude Code session of 2026-11-03')
  assert.match(named.sources[0].text, /In the request layer every carrier call gets it/)
  const missing = await gatherReasoning({ src: open(s, { session: join(tmpdir(), 'no-such-session.jsonl') }), settings: defaultSettings() })
  assert.deepEqual(missing.sources, [])
  assert.match(missing.notes[0], /was not found/)
})

test('read_sessions: picks the session that wrote these files from Claude Code\'s folder for the project', async () => {
  const s = sampleRepo()
  const home = mkdtempSync(join(tmpdir(), 'etc-claude-home-'))
  const before = process.env.CLAUDE_CONFIG_DIR
  process.env.CLAUDE_CONFIG_DIR = home
  try {
    const folder = claudeSessionsFolder(s.dir)
    assert.ok(folder.startsWith(join(home, 'projects', '-')))
    mkdirSync(folder, { recursive: true })
    // Unrelated, mentions the files without writing them, and the real one (oldest of the three).
    writeFileSync(join(folder, 'unrelated.jsonl'), sessionLines([entry('user', 'Tidy the README'), entry('assistant', [{ type: 'tool_use', name: 'Edit', input: { file_path: '/p/README.md' } }])]))
    writeFileSync(join(folder, 'mentions.jsonl'), sessionLines([entry('user', 'What does src/retry.js do?'), entry('assistant', [{ type: 'text', text: 'It retries.' }])]))
    copyFileSync(s.sessionFile, join(folder, 'wrote-it.jsonl'))
    utimesSync(join(folder, 'wrote-it.jsonl'), new Date('2026-11-03'), new Date('2026-11-03'))
    const r = await gatherReasoning({ src: open(s), settings: withReasoningSettings({ read_sessions: true }) })
    assert.equal(r.sources.length, 1)
    assert.match(r.sources[0].text, /Two places the retry could live/)
    assert.deepEqual(r.notes, [])
  } finally {
    if (before === undefined) delete process.env.CLAUDE_CONFIG_DIR
    else process.env.CLAUDE_CONFIG_DIR = before
  }
  // A folder set in the settings, with nothing in it: said plainly, nothing made up.
  const empty = mkdtempSync(join(tmpdir(), 'etc-sessions-'))
  const none = await gatherReasoning({ src: open(s), settings: withReasoningSettings({ read_sessions: true, sessions_folder: empty }) })
  assert.deepEqual(none.sources, [])
  assert.match(none.notes[0], /No Claude Code sessions were found/)
  writeFileSync(join(empty, 'other.jsonl'), sessionLines([entry('user', 'Something else')]))
  const other = await gatherReasoning({ src: open(s), settings: withReasoningSettings({ read_sessions: true, sessions_folder: empty }) })
  assert.match(other.notes[0], /No Claude Code session that wrote these files/)
})

test('plan notes: read from inside the repository only', async () => {
  const s = buildSample(join(mkdtempSync(join(tmpdir(), 'etc-plan-')), 'parcel-pigeon'))
  mkdirSync(join(s.dir, 'notes'))
  writeFileSync(join(s.dir, 'notes', 'plan.md'), '# Plan\nRetry in the request layer; keep the worst case under 15 seconds.\n')
  const outside = mkdtempSync(join(tmpdir(), 'etc-outside-'))
  writeFileSync(join(outside, 'secret.md'), 'not for the explainer')
  symlinkSync(join(outside, 'secret.md'), join(s.dir, 'notes', 'link.md'))
  const settings = withReasoningSettings({ plan_notes: ['./notes/plan.md', '../outside.md', join(outside, 'secret.md'), 'notes/link.md', 'notes/missing.md'] })
  const r = await gatherReasoning({ src: open(s), settings })
  assert.deepEqual(r.sources.map((x) => [x.id, x.label]), [['plan:1', 'Plan notes: notes/plan.md']])
  assert.match(r.sources[0].text, /keep the worst case under 15 seconds/)
  assert.equal(r.notes.length, 4)
  assert.match(r.notes[0], /should be a path inside the repository/)
  assert.match(r.notes[1], /should be a path inside the repository/)
  assert.match(r.notes[2], /leads outside the repository/)
  assert.match(r.notes[3], /was not found/)
  assert.ok(!r.sources.some((x) => /not for the explainer/.test(x.text)))
})

test('explain: the session goes to Claude, each point keeps its source, and the chapter sits before the focus', async () => {
  const s = sampleRepo()
  const prompts = []
  const writer = async ({ prompt }) => { prompts.push(prompt); return withReasoning(wholeScript()) }
  const r = await explain(open(s, { session: s.sessionFile }), { kind: 'whole' }, { store: null, writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.equal(prompts.length, 1, 'passed the fact-check first time')
  assert.match(prompts[0], /### source "session" · Claude Code session of 2026-11-03/)
  assert.match(prompts[0], /Claude: I looked at honouring Retry-After/)
  assert.deepEqual(r.presentation.reasoning.map((p) => p.kind), ['asked', 'approach', 'alternative', 'tradeoff'])
  assert.ok(r.presentation.reasoning.every((p) => p.label === 'Claude Code session of 2026-11-03'))
  const kinds = r.presentation.depths.deep.map((c) => c.kind)
  assert.deepEqual(kinds.slice(-3), ['proof', 'reasoning', 'focus'])
  assert.ok(!r.presentation.depths.quick.some((c) => c.kind === 'reasoning'))
  assert.match(r.html, /Claude Code session of 2026-11-03/)
})

test('explain: a quote that is not word for word is refused, and reasoning with no source is refused', async () => {
  const s = sampleRepo()
  const bent = withReasoning(wholeScript())
  bent.reasoning[2].quote = 'I looked at honouring Retry-After, but it was too much work'
  await assert.rejects(
    explain(open(s, { session: s.sessionFile }), { kind: 'whole' }, { store: null, writer: async () => clone(bent), settings: { project_name: 'Parcel Pigeon' } }),
    (e) => e instanceof CheckFailed && e.details.some((p) => /reasoning\[2\]'s quote is not word for word/.test(p)),
  )
  // Without a session, any reasoning at all is made up.
  await assert.rejects(
    explain(open(s), { kind: 'whole' }, { store: null, writer: async () => withReasoning(wholeScript()), settings: { project_name: 'Parcel Pigeon' } }),
    (e) => e instanceof CheckFailed && e.details.some((p) => /no reasoning sources were given/.test(p)),
  )
  assert.ok(readFileSync(s.sessionFile, 'utf8').length > 0)
})
