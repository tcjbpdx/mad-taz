// Saving: off until switched on; the history on this computer, searchable; and one comment on the
// pull request, updated (never doubled) when saved again, that leaves out Claude's reasoning and
// never notifies anyone. GitHub is a stand-in here (fixtures/fake-gh.cjs): nothing reaches it.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { request as httpRequest } from 'node:http'
import { spawnSync } from 'node:child_process'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { runInNewContext } from 'node:vm'
import { ask, explain, history, save } from '../index.mjs'
import { readHistory, searchHistory, wordFound } from '../scripts/lib/history.mjs'
import { NeedsYou, Problem, SKILL_DIR, pathsFor } from '../scripts/lib/project.mjs'
import { commentBody, commentMark, prTarget, saveExplanation, saveLabelFor } from '../scripts/lib/save.mjs'
import { buildSample, sampleInfo } from '../scripts/lib/sample.mjs'
import { startServer } from '../scripts/lib/server.mjs'
import { defaultSettings, settingsFromObject } from '../scripts/lib/settings.mjs'
import { H2_FOLLOW_UP, clone, h2FollowUpAnswer, wholeScript, withReasoning } from './fixtures/parcel-pigeon-scripts.mjs'

const GH_URL = 'https://github.com/sample-org/parcel-pigeon/pull/42'
const CHECKS = [{ name: 'unit tests', bucket: 'pass', workflow: 'CI' }, { name: 'lint', bucket: 'fail', workflow: 'CI' }]
const SAVE_ON = { project_name: 'Parcel Pigeon', save_to_pr: { enabled: true } }

const freshSample = () => buildSample(join(mkdtempSync(join(tmpdir(), 'etc-save-')), 'parcel-pigeon'))
const git = (s) => ({ kind: 'git', repo: s.dir, base: s.base, head: s.head })

/**
 * Puts the stand-in gh first on PATH for this test (and for anything the test starts), knowing the
 * sample's pull request as #42 on github.com with two checks, one failing.
 */
function fakeGh(t, state = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'etc-fake-gh-'))
  const bin = join(dir, 'bin')
  mkdirSync(bin)
  writeFileSync(join(bin, 'gh'), `#!/bin/sh\nexec "${process.execPath}" "${join(SKILL_DIR, 'test', 'fixtures', 'fake-gh.cjs')}" "$@"\n`)
  chmodSync(join(bin, 'gh'), 0o755)
  const pr = sampleInfo().prInfo
  writeFileSync(join(dir, 'pr.json'), JSON.stringify({
    number: 42, title: pr.title, body: pr.body, url: GH_URL, state: 'OPEN', baseRefName: 'main', headRefName: 'retry-carrier-lookups',
    author: { login: 'sample-author' }, closingIssuesReferences: [{ number: 41 }], commits: [],
  }))
  writeFileSync(join(dir, 'issues.json'), JSON.stringify(pr.issues))
  writeFileSync(join(dir, 'state.json'), JSON.stringify({ login: 'sample-reviewer', checks: CHECKS, ...state }))
  const before = { PATH: process.env.PATH, FAKE_GH_DIR: process.env.FAKE_GH_DIR }
  process.env.PATH = `${bin}:${process.env.PATH}`
  process.env.FAKE_GH_DIR = dir
  t.after(() => {
    process.env.PATH = before.PATH
    if (before.FAKE_GH_DIR === undefined) delete process.env.FAKE_GH_DIR
    else process.env.FAKE_GH_DIR = before.FAKE_GH_DIR
  })
  const statePath = join(dir, 'state.json')
  return {
    env: { PATH: process.env.PATH, FAKE_GH_DIR: dir },
    state: () => JSON.parse(readFileSync(statePath, 'utf8')),
    set: (patch) => writeFileSync(statePath, JSON.stringify({ ...JSON.parse(readFileSync(statePath, 'utf8')), ...patch })),
    calls: () => (existsSync(join(dir, 'calls.jsonl')) ? readFileSync(join(dir, 'calls.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) : []),
  }
}

/** The whole practice change explained with a hand-given description, Claude's reasoning and one question asked. */
async function explainedWithEverything() {
  const s = freshSample()
  const settings = { project_name: 'Parcel Pigeon', source: { use_github: false } }
  const r = await explain({ ...git(s), prInfo: s.prInfo, session: s.sessionFile }, { kind: 'whole' }, { store: null, settings, writer: async () => withReasoning(wholeScript()) })
  const a = await ask(r, { question: H2_FOLLOW_UP }, { settings, writer: async () => h2FollowUpAnswer() })
  return { s, presentation: a.presentation }
}

// ---- the comment ----------------------------------------------------------------------------------

test('the comment: title, what changed with where each why came from, review focus, proof and the questions', async () => {
  const { presentation: p } = await explainedWithEverything()
  const body = commentBody(p)
  assert.ok(body.startsWith(`${commentMark(p.id)}\n### Explain This Change: Carrier requests retry up to three times\n`))
  assert.match(body, /\n#### What changed\n- \*\*A retry helper with backoff\*\*: withRetry\(\) tries up to three times/)
  assert.match(body, /\*Why:\* So a short carrier outage does not fail the lookup\. \(from commit daf6be6\)/)
  assert.match(body, /\n#### Review focus\n- \*\*High\*\* · risk · `src\/carrierClient\.js` lines 37–43: registerWebhook\(\) sends a POST/)
  assert.match(body, /- \*\*Medium\*\* · behavior change · `src\/trackingService\.js`/)
  assert.match(body, /\n#### Proof\n/)
  assert.match(body, /\*\*Nothing here shows the change passing its tests or checks\.\*\*/, 'nothing ran, so nothing is said to pass')
  assert.doesNotMatch(body, /✅/)
  assert.match(body, /<details><summary>One question asked while it played<\/summary>\n\n\*\*Asked:\*\* “What happens when the carrier stays down\?”/)
  assert.match(body, /> \*\*Avery:\*\* Each try gets four seconds/)
  assert.match(body, /<sub>Made with Explain This Change\..* Claude's reasoning from the session notes is left out here\./)
})

test('the comment answers the question it was asked first, in the two voices\' own words', async () => {
  const { presentation } = await explainedWithEverything()
  const p = clone(presentation)
  p.scope.question = 'Is it safe to retry <every> request?'
  p.depths.deep.unshift({ id: 'q1', kind: 'answer', title: 'Your question', lines: [
    { id: 'q1.1', who: 1, say: 'Is it safe to retry every request?' },
    { id: 'q1.2', who: 0, say: 'Not every one: a POST that reached @carrier\nbefore failing can be sent twice.' },
  ] })
  const body = commentBody(p)
  const at = (text) => body.indexOf(text)
  assert.match(body, /\n#### The answer\n\*\*Asked:\*\* “Is it safe to retry &lt;every&gt; request\?”\n\n> \*\*[^*]+:\*\* Is it safe/)
  assert.match(body, /:\*\* Not every one: a POST that reached @\u200bcarrier before failing can be sent twice\./)
  assert.ok(at('#### The answer') > at('<sub>') && at('#### The answer') < at('#### What changed'), 'the answer comes before what changed')
  assert.doesNotMatch(body, /<sub>[^\n]*asked:/, 'the question is not said twice')
  // Without a question, no answer section, even if a chapter of that kind turned up.
  p.scope.question = ''
  assert.doesNotMatch(commentBody(p), /#### The answer/)
})

test('the comment never carries Claude\'s reasoning from the session, even where a why came from it', async () => {
  const { presentation } = await explainedWithEverything()
  const p = clone(presentation)
  assert.equal(p.reasoning.length, 4)
  const change = p.depths.deep.filter((c) => c.kind === 'change')
  change[0].why = p.reasoning[1].quote
  change[0].why_source = 'session'
  change[1].why = 'Intent not stated.'
  change[1].why_source = 'none'
  const body = commentBody(p)
  for (const r of withReasoning(wholeScript()).reasoning) {
    assert.ok(!body.includes(r.quote), `quote left out: ${r.quote}`)
    assert.ok(!body.includes(r.text), `summary left out: ${r.text}`)
  }
  assert.doesNotMatch(body, /Claude's notes from the session/, 'the reasoning chapter is not in it')
  assert.match(body, /\*Why:\* given in the Claude Code session notes, which stay on the reviewer's computer\./)
  assert.match(body, /\*Why:\* intent not stated\./)
})

test('the comment is safe text: no HTML from the explanation, no second mark, and nobody is notified', async () => {
  const { presentation } = await explainedWithEverything()
  const p = clone(presentation)
  p.title = `Retry <script>x</script> for @octocat ${commentMark('0000000000000000')}`
  p.summary = 'Line one\n\nline two, cc @sample-org/reviewers & friends'
  const body = commentBody(p)
  assert.equal(body.split('<!-- explain-this-change:').length, 2, 'only its own mark, at the top')
  assert.doesNotMatch(body, /<script>/)
  assert.match(body, /Retry &lt;script&gt;x&lt;\/script&gt; for @​octocat &lt;!-- explain-this-change:0000000000000000 --&gt;/)
  assert.match(body, /Line one line two, cc @​sample-org\/reviewers &amp; friends/)
  assert.doesNotMatch(body, /@(?!​)[A-Za-z0-9]/, 'every @name is broken so GitHub notifies no one')
})

test('a very long list of questions keeps the latest ones and stays under GitHub\'s limit', async () => {
  const { presentation } = await explainedWithEverything()
  const p = clone(presentation)
  const one = p.answers[0]
  p.answers = Array.from({ length: 80 }, (_, i) => ({ ...clone(one), id: `a${i + 1}`, question: `Question number ${i + 1}?`, chapter: { ...one.chapter, lines: one.chapter.lines.map((l) => ({ ...l, say: `${l.say} ${'and more '.repeat(120)}` })) } }))
  const body = commentBody(p)
  assert.ok(body.length <= 60000, `${body.length} characters`)
  assert.match(body, /questions asked while it played \(the latest \d+ of 80\)/)
  assert.match(body, /Question number 80\?/)
  assert.doesNotMatch(body, /Question number 1\?/)
  assert.match(body, /Saving it again updates this comment\.<\/sub>$/)
})

// ---- where it goes ----------------------------------------------------------------------------------

test('the pull request to post to: from GitHub\'s own address, then its repository, else the folder\'s', () => {
  const at = (github) => prTarget({ source: { github } })
  assert.deepEqual(at({ number: 42, url: GH_URL, repo: '' }), { number: 42, host: 'github.com', repo: 'sample-org/parcel-pigeon' })
  assert.deepEqual(at({ number: 7, url: 'https://git.example.test/team/app/pull/7', repo: '' }), { number: 7, host: 'git.example.test', repo: 'team/app' })
  assert.deepEqual(at({ number: 7, url: 'https://github.com/a/b/pull/8', repo: 'sample-org/parcel-pigeon' }), { number: 7, host: '', repo: 'sample-org/parcel-pigeon' }, 'an address for another number is not trusted')
  assert.deepEqual(at({ number: 5, url: '', repo: 'git.example.test/team/app' }), { number: 5, host: 'git.example.test', repo: 'team/app' })
  assert.deepEqual(at({ number: 5, url: '', repo: '' }), { number: 5, host: '', repo: '' })
  assert.deepEqual(at({ number: 5, url: 'https://github.com/a b/c/pull/5', repo: 'x/y z' }), { number: 5, host: '', repo: '' }, 'odd names are not passed to gh')
  assert.equal(at(null), null)
  assert.equal(at({ number: 0, url: GH_URL }), null)
  assert.equal(prTarget({ source: {} }), null)
})

test('the save button: none while saving is off; "to pull request" only when there is one and posting is on', () => {
  const p = { source: { github: { number: 42, url: GH_URL, repo: '' } } }
  const none = { source: { github: null } }
  assert.equal(saveLabelFor(p, defaultSettings()), '')
  assert.equal(saveLabelFor(p, settingsFromObject(SAVE_ON)), 'Save to pull request #42')
  assert.equal(saveLabelFor(none, settingsFromObject(SAVE_ON)), 'Save to history')
  assert.equal(saveLabelFor(p, settingsFromObject({ save_to_pr: { enabled: true, post_comment: false } })), 'Save to history')
})

test('saving: refused while off; a hand-given description is kept in the history only, and says why', async (t) => {
  const g = fakeGh(t)
  const s = freshSample()
  const history = join(s.dir, 'history.json')
  const r = await explain({ ...git(s), prInfo: s.prInfo }, { kind: 'whole' }, { store: null, settings: { project_name: 'Parcel Pigeon' }, writer: async () => wholeScript() })
  assert.equal(r.presentation.source.github, null, 'a description given by hand is not a pull request GitHub knows')
  assert.throws(() => saveExplanation(r.presentation, { settings: defaultSettings(), historyFile: history, cwd: s.dir }), NeedsYou)
  assert.throws(() => saveExplanation(r.presentation, { settings: settingsFromObject(SAVE_ON), historyFile: null, cwd: s.dir }), Problem)
  const saved = saveExplanation(r.presentation, { settings: settingsFromObject(SAVE_ON), historyFile: history, cwd: s.dir })
  assert.deepEqual(saved, { label: 'Saved to history', message: 'Kept in the history. Not posted: this change has no pull request on GitHub.', url: '', posted: false })
  const [entry] = readHistory(history)
  assert.equal(entry.id, r.id)
  assert.equal(entry.saved.to, 'history')
  assert.equal(entry.pr.number, 42, 'the hand-given number is still searchable')
  // Posting switched off: the history only, without asking GitHub anything.
  const p = clone(r.presentation)
  p.source.github = { number: 42, url: GH_URL, repo: '' }
  const off = saveExplanation(p, { settings: settingsFromObject({ save_to_pr: { enabled: true, post_comment: false } }), historyFile: history, cwd: s.dir })
  assert.equal(off.message, 'Kept in the history. Posting to the pull request is switched off (save_to_pr → post_comment).')
  assert.deepEqual(g.calls(), [])
})

// ---- with GitHub ----------------------------------------------------------------------------------

test('with GitHub: the branch\'s pull request is found, its checks are proof, and saving posts one comment then updates it', async (t) => {
  const g = fakeGh(t)
  const s = freshSample()
  const opts = { project: s.dir, settings: SAVE_ON }
  const paths = pathsFor(s.dir, settingsFromObject(SAVE_ON))

  const r = await explain(git(s), { kind: 'whole' }, { ...opts, writer: async () => wholeScript() })
  const p = r.presentation
  assert.deepEqual(p.source.github, { number: 42, url: GH_URL, repo: '' })
  const lint = p.proof.items.find((i) => i.label === 'Check: CI · lint')
  assert.equal(lint.status, 'fail')
  assert.equal(p.proof.items.find((i) => i.label === 'Check: CI · unit tests').status, 'pass')
  assert.equal(p.proof.passing, false, 'a failing check means it is not shown passing')
  assert.match(commentBody(p), /- ❌ failed · \*\*Check: CI · lint\*\*: GitHub reports it failed\./)
  assert.match(commentBody(p), /- ✅ passed · \*\*Check: CI · unit tests\*\*/)
  const [noted] = readHistory(paths.history)
  assert.equal(noted.id, r.id, 'explaining puts it in the history while saving is on')
  assert.equal(noted.saved, null)

  const first = await save(r.id, opts)
  assert.equal(first.posted, true)
  assert.equal(first.label, 'Saved to #42')
  assert.equal(first.message, 'Posted a comment to pull request #42.')
  assert.equal(first.url, `${GH_URL}#issuecomment-9001`)
  let comments = g.state().comments
  assert.equal(comments.length, 1)
  assert.equal(comments[0].repo, 'sample-org/parcel-pigeon')
  assert.equal(comments[0].issue, 42)
  assert.ok(comments[0].body.startsWith(commentMark(r.id)))
  assert.deepEqual(readHistory(paths.history)[0].saved.url, first.url)

  // Someone else's comment carrying the same mark is not this person's to change.
  g.set({ comments: [{ id: 500, repo: 'sample-org/parcel-pigeon', issue: 42, login: 'someone-else', body: `${commentMark(r.id)}\nnot mine`, url: `${GH_URL}#issuecomment-500` }, ...comments] })
  await ask(r.id, { question: H2_FOLLOW_UP }, { ...opts, writer: async () => h2FollowUpAnswer() })
  const again = await save(r.id, opts)
  assert.equal(again.message, 'Updated the comment on pull request #42.')
  assert.equal(again.url, first.url)
  comments = g.state().comments
  assert.equal(comments.length, 2, 'updated, not posted twice')
  assert.equal(comments.find((c) => c.id === 500).body, `${commentMark(r.id)}\nnot mine`)
  assert.match(comments.find((c) => c.id === 9001).body, /What happens when the carrier stays down\?/)
  const writes = g.calls().filter((c) => c.args.includes('--method'))
  assert.deepEqual(writes.map((c) => c.args[c.args.indexOf('--method') + 1]), ['POST', 'PATCH'])
  assert.ok(writes[1].args.includes('repos/sample-org/parcel-pigeon/issues/comments/9001'))

  // The history finds it by pull request, file, question and where it went; every word must match.
  const rows = await history({ ...opts, search: '#42' })
  assert.deepEqual(rows.map((e) => e.id), [r.id])
  assert.equal(rows[0].kept, true)
  assert.equal(rows[0].saved.to, 'pull request #42')
  assert.equal((await history({ ...opts, search: 'carrierClient.js stays down' })).length, 1)
  assert.equal((await history({ ...opts, search: 'retry zebra' })).length, 0)

  // GitHub refusing is said plainly, and the history keeps the record.
  g.set({ comments: [], refuse: true })
  await assert.rejects(save(r.id, opts), (e) => e instanceof Problem && /HTTP 403/.test(e.message))
  assert.equal(readHistory(paths.history).length, 1)
  g.set({ refuse: false, loggedOut: true })
  await assert.rejects(save(r.id, opts), (e) => e instanceof NeedsYou && /not signed in\. Run: gh auth login/.test(e.message))
})

test('with saving off, explaining writes no history and asks GitHub nothing about saving', async (t) => {
  const g = fakeGh(t)
  const s = freshSample()
  const r = await explain(git(s), { kind: 'whole' }, { project: s.dir, settings: { project_name: 'Parcel Pigeon' }, writer: async () => wholeScript() })
  assert.equal(r.presentation.source.github.number, 42)
  assert.ok(!existsSync(pathsFor(s.dir, defaultSettings()).history))
  await assert.rejects(save(r.id, { project: s.dir, settings: { project_name: 'Parcel Pigeon' } }), NeedsYou)
  assert.ok(!g.calls().some((c) => c.args.includes('--method')))
})

// ---- the helper and the command ------------------------------------------------------------------

function call(h, method, path, body = null) {
  return new Promise((resolve, reject) => {
    const data = body == null ? null : JSON.stringify(body)
    const req = httpRequest({
      host: '127.0.0.1', port: h.port, method, path,
      headers: { host: `127.0.0.1:${h.port}`, origin: `http://127.0.0.1:${h.port}`, ...(data ? { 'content-type': 'application/json' } : {}) },
    }, (res) => {
      const chunks = []
      res.on('data', (c) => chunks.push(c))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        let json = null
        try { json = JSON.parse(text) } catch { /* not JSON */ }
        resolve({ status: res.statusCode, headers: res.headers, text, json })
      })
    })
    req.on('error', reject)
    if (data) req.write(data)
    req.end()
  })
}

test('the helper: the page\'s button names the pull request, saving answers with where it went, and the list is searchable', async (t) => {
  fakeGh(t)
  const s = freshSample()
  const h = await startServer({ project: s.dir, store: mkdtempSync(join(tmpdir(), 'etc-save-store-')), settings: SAVE_ON, port: 0, writer: async () => wholeScript(), sourceDefaults: { base: s.base, head: s.head } })
  t.after(() => h.close())
  const made = await call(h, 'POST', '/explain', { scope: { kind: 'whole' } })
  assert.equal(made.status, 200)
  const done = made.text.split('\n').filter(Boolean).map((l) => JSON.parse(l)).at(-1).done
  const page = await call(h, 'GET', done.url)
  assert.match(page.text, /"save":"\/save"/)
  assert.match(page.text, /"saveLabel":"Save to pull request #42"/)
  assert.match(page.text, /id="etc-saved"/)

  const saved = await call(h, 'POST', '/save', { id: done.id })
  assert.equal(saved.status, 200)
  assert.deepEqual(saved.json, { label: 'Saved to #42', message: 'Posted a comment to pull request #42.', url: `${GH_URL}#issuecomment-9001`, posted: true })
  assert.equal((await call(h, 'POST', '/save', { id: 'nothing' })).status, 400)

  const index = await call(h, 'GET', '/')
  assert.match(index.text, /<input[^>]+type="search"/)
  assert.match(index.text, /data-find="[^"]*#42 pull request 42/)
  assert.match(index.text, new RegExp(`href="${GH_URL}#issuecomment-9001"`))
  assert.match(index.headers['content-security-policy'], /script-src 'sha256-[A-Za-z0-9+/=]+'/)

  // The list page's own search script, run on a stand-in page: "#4" is not pull request 42.
  const script = /<script>([\s\S]*?)<\/script>/.exec(index.text)[1]
  const rows = ['x #42 pull request 42 carrierclient.js', 'y #4 pull request 4 webhook', 'z no pull request'].map((find) => ({ dataset: { find }, hidden: false }))
  const box = { value: '', on: null, addEventListener(_, fn) { this.on = fn } }
  const none = { hidden: true }
  runInNewContext(script, { document: { getElementById: (id) => (id === 'find' ? box : none), querySelectorAll: () => rows } })
  const shownFor = (typed) => { box.value = typed; box.on(); return rows.filter((r) => !r.hidden).map((r) => r.dataset.find[0]).join('') }
  assert.equal(shownFor('#42'), 'x')
  assert.equal(shownFor('#4'), 'y')
  assert.equal(shownFor('pull request'), 'xyz')
  assert.equal(shownFor('#4 carrier'), '')
  assert.equal(none.hidden, false)
  assert.equal(shownFor(''), 'xyz')
})

test('history search: "#4" finds pull request 4 and not 42; other words match anywhere', () => {
  const rec = (id, n, title) => ({ id, created: id, title, pr: n ? { number: n, url: '' } : null, files: [], focus: [], asked: [] })
  const all = [rec('a', 42, 'Retry on errors'), rec('b', 4, 'Webhook check'), rec('c', 0, 'Tidy #4x note')]
  const ids = (q) => searchHistory(all, q).map((e) => e.id).join('')
  assert.equal(ids('#42'), 'a')
  assert.equal(ids('#4'), 'bc') // "#4x" is still #4 followed by a non-digit
  assert.equal(ids('retry #42'), 'a')
  assert.equal(ids('retry #4'), '')
  assert.equal(ids('4'), 'abc')
  assert.equal(ids(''), 'abc')
  assert.equal(wordFound('see #400 and #4.', '#4'), true)
  assert.equal(wordFound('see #400', '#4'), false)
})

test('the command: save <id> posts, and history --search finds it by its pull request', async (t) => {
  const g = fakeGh(t)
  const dir = freshSample().dir
  const cli = (...args) => {
    const r = spawnSync(process.execPath, [join(SKILL_DIR, 'scripts', 'explain.mjs'), ...args, '--project', dir], { encoding: 'utf8', timeout: 60000, env: { ...process.env, ...g.env, EXPLAIN_DEBUG: '' } })
    return { code: r.status, out: r.stdout, err: r.stderr }
  }
  assert.equal(cli('new').code, 0)
  writeFileSync(join(dir, 'answers.json'), JSON.stringify({ explain: [wholeScript()], ask: [] }))
  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'project_name: Parcel Pigeon\nwriter:\n  service: fixture\n  fixture: answers.json\nvoice:\n  service: none\nsave_to_pr:\n  enabled: yes\n')
  const made = cli('explain', '--base', 'main', '--head', 'retry-carrier-lookups', '--json', '--no-open')
  assert.equal(made.code, 0, made.err)
  const { id } = JSON.parse(made.out)

  const saved = cli('save', id)
  assert.equal(saved.code, 0, saved.err)
  assert.match(saved.out, /Posted a comment to pull request #42\.\n/)
  assert.match(saved.out, /issuecomment-9001/)

  const found = cli('history', '--search', '#42')
  assert.equal(found.code, 0, found.err)
  assert.match(found.out, new RegExp(`${id}  .*Carrier requests retry up to three times`))
  assert.match(found.out, /pull request #42/)
  assert.match(found.out, /saved to pull request #42: https:\/\/github\.com\/sample-org\/parcel-pigeon\/pull\/42#issuecomment-9001/)
  assert.match(found.out, /1 explanation with "#42"\./)
  const none = cli('search', 'zebra')
  assert.equal(none.code, 0)
  assert.match(none.out, /Nothing matches "zebra"\./)
})
