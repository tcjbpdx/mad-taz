// The button's helper: it explains and answers for the helper's own pages and the review apps on
// its list, and refuses everything else: other sites, other addresses for this computer, requests
// that are not JSON or are too big, a missing token, and a branch name that is really an option.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { request as httpRequest } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { NeedsYou } from '../scripts/lib/project.mjs'
import { hostIsLocal, sameToken, scopeFromRequest, sourceFromRequest, startServer } from '../scripts/lib/server.mjs'
import { H2_FOLLOW_UP, H2_QUESTION, clone, h2FollowUpAnswer, h2QuestionScript } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

const REVIEW_APP = 'http://localhost:3000'

function fakeWriter({ explain: e = [h2QuestionScript()], ask: a = [h2FollowUpAnswer()], delay = 0 } = {}) {
  const calls = { explain: 0, ask: 0, active: 0, most: 0 }
  const writer = async ({ purpose }) => {
    calls.active++
    calls.most = Math.max(calls.most, calls.active)
    if (delay) await new Promise((r) => setTimeout(r, delay))
    calls.active--
    const list = purpose === 'ask' ? a : e
    const n = calls[purpose]++
    return clone(list[Math.min(n, list.length - 1)])
  }
  return { writer, calls }
}

async function helper(extra = {}) {
  const s = sampleRepo()
  const w = fakeWriter(extra.writerOptions)
  const h = await startServer({
    project: s.dir,
    store: mkdtempSync(join(tmpdir(), 'etc-server-')),
    settings: { project_name: 'Parcel Pigeon', server: { allow_origins: [REVIEW_APP] } },
    port: 0,
    writer: w.writer,
    sourceDefaults: { base: s.base, head: s.head, prInfo: s.prInfo },
    ...extra.options,
  })
  return { ...h, ...w, sample: s }
}

/** A raw request, so the test can set any header (Host and Origin included). */
function call(h, method, path, { headers = {}, body = null, json = true } = {}) {
  return new Promise((resolve, reject) => {
    const data = body == null ? null : typeof body === 'string' ? body : JSON.stringify(body)
    const req = httpRequest({
      host: '127.0.0.1', port: h.port, method, path,
      headers: { host: `127.0.0.1:${h.port}`, ...(data != null && json ? { 'content-type': 'application/json' } : {}), ...headers },
    }, (res) => {
      const chunks = []
      res.on('data', (c) => chunks.push(c))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        let parsed = null
        try { parsed = JSON.parse(text) } catch { /* not JSON */ }
        resolve({ status: res.statusCode, headers: res.headers, text, json: parsed })
      })
    })
    req.on('error', reject)
    if (data != null) req.write(data)
    req.end()
  })
}

const lines = (text) => text.split('\n').filter(Boolean).map((l) => JSON.parse(l))
const explainH2 = (h, extra = {}) => call(h, 'POST', '/explain', { body: { scope: { kind: 'hunk', id: 'h2' }, question: H2_QUESTION }, ...extra })

// ---- the parts on their own ----------------------------------------------------------------------

test('server parts: the address must be this computer at this port; tokens compare exactly', () => {
  assert.equal(hostIsLocal('127.0.0.1:4317', 4317), true)
  assert.equal(hostIsLocal('localhost:4317', 4317), true)
  assert.equal(hostIsLocal('[::1]:4317', 4317), true)
  assert.equal(hostIsLocal('evil.example:4317', 4317), false, 'a site that points its name here')
  assert.equal(hostIsLocal('127.0.0.1:9999', 4317), false)
  assert.equal(hostIsLocal('', 4317), false)
  assert.equal(sameToken('abc', 'abc'), true)
  assert.equal(sameToken('abd', 'abc'), false)
  assert.equal(sameToken('', 'abc'), false)
  assert.equal(sameToken(undefined, ''), true, 'no token set: nothing to check')
})

test('server parts: a request can name a branch, a pull request or a diff, never a folder', () => {
  const repo = '/the/project'
  assert.deepEqual(sourceFromRequest({ source: { kind: 'git', repo: '/etc', base: 'main', head: 'feature/x' } }, repo), { kind: 'git', repo, base: 'main', head: 'feature/x' })
  assert.deepEqual(sourceFromRequest({ source: { number: 42, repo: 'someone/else' } }, repo), { kind: 'github', number: 42 })
  assert.deepEqual(sourceFromRequest({ source: { text: 'diff --git a/x b/x' } }, repo), { kind: 'diff', text: 'diff --git a/x b/x' })
  assert.throws(() => sourceFromRequest({ source: { base: '--output=/tmp/x' } }, repo), /branch or commit name/)
  assert.throws(() => sourceFromRequest({ source: { head: 'HEAD:secret.txt' } }, repo), /branch or commit name/)
  assert.throws(() => sourceFromRequest({ source: { kind: 'github', number: '1; rm -rf /' } }, repo), /pull request number/)
  assert.throws(() => sourceFromRequest({ source: { kind: 'file', path: '/etc/passwd' } }, repo), /kind is git, github or diff/)
  assert.deepEqual(scopeFromRequest({ scope: { kind: 'hunk', file: 'a.js', line: '12', extra: 'x' }, question: '  why\n now? ' }), { kind: 'hunk', file: 'a.js', line: 12, question: 'why now?' })
  assert.throws(() => scopeFromRequest({ question: 'x'.repeat(501) }), /keep it under 500/)
})

// ---- working ------------------------------------------------------------------------------------

test('server: explains with progress as it goes, serves the page, and answers a question on it', async (t) => {
  const h = await helper()
  t.after(() => h.close())
  assert.equal((await call(h, 'GET', '/health')).json.ok, true)

  const r = await explainH2(h, { headers: { origin: REVIEW_APP } })
  assert.equal(r.status, 200)
  assert.equal(r.headers['access-control-allow-origin'], REVIEW_APP)
  const out = lines(r.text)
  assert.ok(out.some((o) => o.stage === 'write'), 'progress came before the end')
  const done = out.at(-1).done
  assert.match(done.id, /^[0-9a-f]{16}$/)
  assert.equal(done.url, `/x/${done.id}`)

  const page = await call(h, 'GET', done.url)
  assert.equal(page.status, 200)
  assert.equal(page.headers['content-security-policy'], `frame-ancestors 'self' ${REVIEW_APP}`)
  assert.match(page.text, /connect-src &#x27;self&#x27;/)
  assert.match(page.text, /"ask":"\/ask"/)
  assert.match(page.text, /"save":""/, 'saving is off until it is switched on')

  const asked = await call(h, 'POST', '/ask', { headers: { origin: `http://127.0.0.1:${h.port}` }, body: { id: done.id, question: H2_FOLLOW_UP, chapter: 'd3', line: 'd3.2', depth: 'deep' } })
  assert.equal(asked.status, 200)
  assert.equal(asked.json.answer.id, 'a1')
  assert.equal(asked.json.answer.after, 'd3')
  assert.ok(Array.isArray(asked.json.files))

  const index = await call(h, 'GET', '/')
  assert.match(index.text, /Retrying every carrier request/)
  assert.match(index.headers['content-security-policy'], /default-src 'none'/)
})

test('server: a failed fact-check comes back as a plain problem with its reasons', async (t) => {
  const bad = h2FollowUpAnswer()
  bad.lines[0].say = 'The tests pass, so nothing to worry about.'
  const h = await helper({ writerOptions: { ask: [bad] } })
  t.after(() => h.close())
  const { id } = lines((await explainH2(h)).text).at(-1).done
  const r = await call(h, 'POST', '/ask', { body: { id, question: H2_FOLLOW_UP, chapter: 'd2', depth: 'deep' } })
  assert.equal(r.status, 422)
  assert.match(r.json.error, /did not pass the fact-check/)
  assert.ok(r.json.details.some((d) => /nothing shows tests or checks passing/.test(d)))
})

test('server: a change outside the scope, or a part that is not in it, ends the stream with the problem', async (t) => {
  const h = await helper()
  t.after(() => h.close())
  const r = await call(h, 'POST', '/explain', { body: { scope: { kind: 'file', file: 'src/nope.js' } } })
  assert.equal(r.status, 200)
  const last = lines(r.text).at(-1)
  assert.equal(last.status, 400)
  assert.match(last.error, /not one of the files this change touches/)
  assert.equal(h.calls.explain, 0)
})

test('server: one explanation at a time; the next one says it is waiting', async (t) => {
  const h = await helper({ writerOptions: { delay: 150 } })
  t.after(() => h.close())
  const [a, b] = await Promise.all([
    explainH2(h),
    call(h, 'POST', '/explain', { body: { scope: { kind: 'hunk', id: 'h2' }, question: `${H2_QUESTION} Twice?` } }),
  ])
  assert.equal(h.calls.most, 1, 'the writer never ran twice at once')
  assert.ok(lines(a.text).at(-1).done && lines(b.text).at(-1).done)
  assert.ok([...lines(a.text), ...lines(b.text)].some((o) => o.stage === 'queue'), 'the second one was told it is waiting')
})

test('server: the example review page and the button are served, with their own strict rules', async (t) => {
  const h = await helper()
  t.after(() => h.close())
  const page = await call(h, 'GET', '/example')
  assert.equal(page.status, 200)
  assert.match(page.headers['content-security-policy'], /script-src 'self'/)
  assert.doesNotMatch(page.text, /\{\{TOKEN\}\}/)
  const js = await call(h, 'GET', '/button.js')
  assert.equal(js.status, 200)
  assert.match(js.headers['content-type'], /javascript/)
  assert.match(js.text, /customElements\.define\('explain-change'/)
  const diff = await call(h, 'POST', '/diff', { body: { source: { kind: 'git', repo: '/' } } })
  assert.equal(diff.status, 200)
  assert.ok(diff.json.files.some((f) => f.path === 'src/carrierClient.js'), 'it read the project, not the folder it was handed')
})

// ---- refusing -----------------------------------------------------------------------------------

test('server refuses: another site, a site pointing its name here, and anything that is not JSON', async (t) => {
  const h = await helper()
  t.after(() => h.close())
  const other = await explainH2(h, { headers: { origin: 'https://evil.example' } })
  assert.equal(other.status, 403)
  assert.equal(other.headers['access-control-allow-origin'], undefined)

  const rebound = await call(h, 'GET', '/', { headers: { host: `evil.example:${h.port}` } })
  assert.equal(rebound.status, 403)
  const rebound2 = await explainH2(h, { headers: { host: `evil.example:${h.port}`, origin: `http://evil.example:${h.port}` } })
  assert.equal(rebound2.status, 403)

  const plain = await call(h, 'POST', '/explain', { body: '{"scope":{"kind":"whole"}}', json: false, headers: { 'content-type': 'text/plain' } })
  assert.equal(plain.status, 415)
  const fileOrigin = await explainH2(h, { headers: { origin: 'null' } })
  assert.equal(fileOrigin.status, 403)
  assert.equal(h.calls.explain, 0, 'nothing reached the writer')
})

test('server refuses: an unlisted site asking permission first, and a listed one is let in', async (t) => {
  const h = await helper()
  t.after(() => h.close())
  const listed = await call(h, 'OPTIONS', '/explain', { headers: { origin: REVIEW_APP, 'access-control-request-method': 'POST', 'access-control-request-headers': 'content-type' } })
  assert.equal(listed.status, 204)
  assert.equal(listed.headers['access-control-allow-origin'], REVIEW_APP)
  assert.match(listed.headers['access-control-allow-headers'], /x-explain-token/)
  const unlisted = await call(h, 'OPTIONS', '/explain', { headers: { origin: 'https://evil.example', 'access-control-request-method': 'POST' } })
  assert.equal(unlisted.status, 403)
  assert.equal(unlisted.headers['access-control-allow-origin'], undefined)
})

test('server refuses: a kept page holding a word added to the never-show list since is not served', async (t) => {
  const store = mkdtempSync(join(tmpdir(), 'etc-server-'))
  const first = await helper({ options: { store } })
  const done = lines((await explainH2(first)).text).at(-1).done
  await first.close()
  const later = await helper({ options: { store, neverShow: ['registerWebhook'] } })
  t.after(() => later.close())
  const page = await call(later, 'GET', done.url)
  assert.equal(page.status, 403)
  assert.match(page.text, /never-show list/)
  assert.doesNotMatch(page.text, /registerWebhook/, 'the refusal does not show the word either')
  assert.equal(page.headers['content-security-policy'], "default-src 'none'; frame-ancestors 'none'")
})

test('server refuses: too big, a bad id, an id that is not there, an unknown address', async (t) => {
  const h = await helper()
  t.after(() => h.close())
  const big = await call(h, 'POST', '/ask', { body: { id: '0123456789abcdef', question: 'x'.repeat(40 * 1024) } })
  assert.equal(big.status, 413)
  const badId = await call(h, 'GET', '/x/..%2F..%2Fetc')
  assert.equal(badId.status, 400)
  assert.match(badId.json.error, /not an explainer id/)
  assert.equal((await call(h, 'GET', '/x/0123456789abcdef')).status, 404)
  assert.equal((await call(h, 'POST', '/ask', { body: { id: '0123456789abcdef', question: 'why?' } })).status, 400)
  assert.equal((await call(h, 'GET', '/nothing-here')).status, 404)
  assert.equal((await call(h, 'POST', '/save', { body: { id: '0123456789abcdef' } })).status, 409)
  const sneaky = await call(h, 'POST', '/explain', { body: { source: { base: '--output=/tmp/owned' } } })
  assert.equal(sneaky.status, 400)
  assert.match(sneaky.json.error, /branch or commit name/)
})

test('server with a token: every page and request needs it; the health check and the button do not', async (t) => {
  const TOKEN = 'a-long-test-token-that-is-only-for-this-test'
  const h = await helper({ options: { token: TOKEN } })
  t.after(() => h.close())
  assert.equal((await call(h, 'GET', '/health')).status, 200)
  assert.equal((await call(h, 'GET', '/button.js')).status, 200)
  assert.equal((await call(h, 'GET', '/')).status, 401)
  assert.equal((await explainH2(h)).status, 401)
  assert.equal((await explainH2(h, { headers: { 'x-explain-token': 'wrong' } })).status, 401)
  const ok = await explainH2(h, { headers: { 'x-explain-token': TOKEN } })
  const { id } = lines(ok.text).at(-1).done
  assert.equal((await call(h, 'GET', `/x/${id}`)).status, 401)
  const page = await call(h, 'GET', `/x/${id}?token=${TOKEN}`)
  assert.equal(page.status, 200)
  assert.match(page.text, /"token":"a-long-test-token/, 'the page carries it, so its questions get through')
  assert.equal(h.calls.explain, 1)
})

test('server: listening beyond this computer needs a token', async () => {
  const s = sampleRepo()
  await assert.rejects(
    startServer({ project: s.dir, store: mkdtempSync(join(tmpdir(), 'etc-server-')), settings: {}, host: '0.0.0.0', port: 0 }),
    (e) => e instanceof NeedsYou && /needs a token/.test(e.message),
  )
})

// ---- in a real browser: the button, the window, and a question asked inside it -----------------

let pw = null
try { pw = await import('playwright') } catch { pw = null }

test('browser: the example page\'s button explains a part, plays it in a window, and the player asks a question', { skip: pw ? false : 'the browser helper (optional) is not installed here', timeout: 60000 }, async (t) => {
  const h = await helper()
  t.after(() => h.close())
  const browser = await pw.chromium.launch({ headless: true })
  t.after(() => browser.close())
  const page = await browser.newPage({ viewport: { width: 1280, height: 860 } })
  const problems = []
  page.on('pageerror', (e) => problems.push(e.message))
  page.on('console', (m) => { if (m.type() === 'error') problems.push(m.text()) })
  await page.goto(`${h.url}/example`)

  const diff = await call(h, 'POST', '/diff', { body: {} })
  const file = diff.json.files.find((f) => f.hunks.some((x) => x.id === 'h2'))
  const hunk = file.hunks.find((x) => x.id === 'h2')
  const line = hunk.rows.find((r) => r.t === 'add').new
  const button = page.locator(`explain-change[file="${file.path}"][line="${line}"]`)
  await button.locator('input').fill(H2_QUESTION)
  await button.locator('button').click()

  const player = page.frameLocator('iframe[title="Explain This Change player"]')
  await player.locator('#etc-q').waitFor({ state: 'visible', timeout: 20000 })
  await assert.doesNotReject(player.locator('.etc-title').filter({ hasText: 'Retrying every carrier request' }).waitFor({ timeout: 10000 }))
  await player.locator('#etc-q').fill(H2_FOLLOW_UP)
  await player.locator('#etc-go').click()
  await player.locator('.etc-rail').getByText('When the carrier stays down').waitFor({ timeout: 20000 })
  assert.equal(h.calls.explain, 1)
  assert.equal(h.calls.ask, 1)

  await page.locator('[data-explain-change-viewer]').locator('button', { hasText: 'Close' }).click()
  await page.waitForFunction(() => !document.querySelector('[data-explain-change-viewer]').shadowRoot.querySelector('dialog').open)
  assert.deepEqual(problems, [])
})
