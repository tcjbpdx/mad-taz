// The engine between the change and the player: settings, code highlighting, the context Claude is
// shown, the fact-checker, the write → check → fix loop, the cache and the presentation.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { openSource } from '../scripts/lib/source.mjs'
import { applyScope } from '../scripts/lib/scope.mjs'
import { buildContext } from '../scripts/lib/context.mjs'
import { checkScript, tidyScript } from '../scripts/lib/checks.mjs'
import { checkContext, writeScript } from '../scripts/lib/script.mjs'
import { cacheKey, fileCache } from '../scripts/lib/cache.mjs'
import { buildPresentation } from '../scripts/lib/present.mjs'
import { highlightKnown, highlightLines, splitHighlighted } from '../scripts/lib/highlight.mjs'
import { defaultSettings, parseSettings, settingsFromObject, writerFingerprint } from '../scripts/lib/settings.mjs'
import { resetFixtures, write } from '../scripts/lib/writer.mjs'
import { CheckFailed, ENGINE_VERSION, FORMAT } from '../scripts/lib/project.mjs'
import { H2_QUESTION, clone, h2QuestionScript, wholeScript } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

const temp = () => mkdtempSync(join(tmpdir(), 'etc-engine-'))

let opened = null
function sample() {
  if (!opened) {
    const s = sampleRepo()
    opened = openSource({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { settings: { source: { use_github: false } } })
  }
  return opened
}

/** The source, scope, context and checker context for a scope. */
function setup(scope = { kind: 'whole' }, extra = {}) {
  const src = sample()
  const scoped = applyScope(src.diff, scope)
  const context = buildContext(src, scoped)
  const ctx = checkContext({ src, scoped, context, ...extra })
  return { src, scoped, context, ctx }
}

const check = (script, ctx) => checkScript(tidyScript(script, ctx), ctx)

// ---- settings ---------------------------------------------------------------------------------

test('settings: an empty file gives safe defaults (nothing sent anywhere new, nothing saved to the PR)', async () => {
  const s = await parseSettings('')
  assert.equal(s.mode, 'code-review')
  assert.equal(s.depth, 'deep')
  assert.equal(s.writer.service, 'claude-cli')
  assert.equal(s.voice.service, 'browser')
  assert.equal(s.voice.allow_network_voices, false)
  assert.equal(s.reasoning.read_sessions, false)
  assert.equal(s.save_to_pr.enabled, false)
  assert.equal(s.product.enabled, false)
  assert.equal(s.proof.run_tests, false)
  assert.equal(s.server.host, '127.0.0.1')
  assert.deepEqual(s.voice.speakers, ['Avery', 'Jordan'])
  assert.deepEqual(defaultSettings().voice.speakers, s.voice.speakers)
})

test('settings: a misspelt name or value gets a "did you mean"', async () => {
  await assert.rejects(parseSettings('depht: quick\n'), /depht is not a setting I know \(did you mean depth\?\)/)
  await assert.rejects(parseSettings('depth: quik\n'), /did you mean quick\?/)
})

test('settings: every problem is listed at once', async () => {
  const err = await parseSettings('depth: sideways\nvoice:\n  speakers: [Sam]\nserver:\n  port: 80\n').catch((e) => e)
  assert.equal(err.problems.length, 3)
  assert.match(err.message, /needs 3 fixes/)
})

test('settings: a key or password in settings.yaml is refused', async () => {
  await assert.rejects(parseSettings('writer:\n  api_key: abc\n'), /private\.env/)
  await assert.rejects(parseSettings(`project_name: sk-ant-api03-${'x'.repeat(40)}\n`), /looks like a key or password/)
})

test('settings: switches that depend on each other are checked', async () => {
  await assert.rejects(parseSettings('mode: product\n'), /Turn product mode on first/)
  await assert.rejects(parseSettings('writer:\n  service: fixture\n'), /writer → fixture is empty/)
  await assert.rejects(parseSettings('proof:\n  run_tests: yes\n'), /test_command is empty/)
  await assert.rejects(parseSettings('look:\n  accent_color: #2E7D5B\n'), /needs quote marks/)
})

test('settings: a host app can pass an object, and checked settings pass straight through', () => {
  const s = settingsFromObject({ depth: 'quick', voice: { speakers: ['Ana', 'Bo'] } })
  assert.equal(s.depth, 'quick')
  assert.equal(settingsFromObject(s), s)
  assert.throws(() => settingsFromObject({ depth: 'long' }), /depth/)
})

test('settings: the cache fingerprint changes with what changes the writing, not with the look', () => {
  const a = writerFingerprint(settingsFromObject({}))
  assert.deepEqual(a, writerFingerprint(settingsFromObject({ look: { theme: 'dark' } })))
  assert.notDeepEqual(a, writerFingerprint(settingsFromObject({ voice: { speakers: ['Ana', 'Bo'] } })))
})

// ---- code highlighting ---------------------------------------------------------------------------

test('highlighting: a comment over several lines is closed and reopened on each line', () => {
  const lines = highlightLines('/* one\n   two */\nconst x = 1\n', 'a.js')
  assert.equal(lines.length, 3)
  for (const l of lines) assert.equal((l.match(/<span/g) || []).length, (l.match(/<\/span>/g) || []).length, l)
  assert.match(lines[1], /^<span class="hljs-comment">/)
  assert.ok(splitHighlighted('<span class="a">x\ny</span>').every((l) => l.endsWith('</span>')))
})

test('highlighting: scattered known lines come back in place, with gaps empty', () => {
  const out = highlightKnown(new Map([[2, 'let a = 1'], [3, 'let b = 2'], [7, 'return a']]), 'x.js')
  assert.equal(out.length, 7)
  assert.equal(out[0], null)
  assert.match(out[1], /hljs-keyword/)
  assert.equal(out[4], null)
  assert.match(out[6], /return/)
  assert.deepEqual(highlightLines('<b> & "q"', 'notes.unknownext'), ['&lt;b&gt; &amp; &quot;q&quot;'])
})

// ---- context ----------------------------------------------------------------------------------

test('context: short changed files are shown whole, so registerWebhook (unchanged) is in front of Claude', () => {
  const { context } = setup()
  const client = context.excerpts.find((e) => e.file === 'src/carrierClient.js' && e.side === 'after')
  assert.ok(client, 'carrierClient.js is an excerpt')
  assert.equal(client.from, 1)
  assert.equal(client.to, 43)
  assert.match(client.lines.slice(36, 43).join('\n'), /registerWebhook[\s\S]*method: 'POST'/)
  assert.equal(context.fileLines('after', 'src/carrierClient.js'), 43)
  assert.equal(context.fileLines('before', 'src/retry.js'), null)
  assert.match(context.listingText, /### h2 · src\/carrierClient\.js/)
})

test('context: one hunk in scope keeps the listing to that hunk', () => {
  const { context } = setup({ kind: 'hunk', id: 'h2' })
  assert.match(context.listingText, /### h2/)
  assert.doesNotMatch(context.listingText, /### h1|### h5/)
})

// ---- the fact-checker -------------------------------------------------------------------------

test('checker: the hand-written explanation of the whole pull request passes cleanly', () => {
  const { ctx } = setup()
  const { hard, soft } = check(wholeScript(), ctx)
  assert.deepEqual(hard, [])
  assert.deepEqual(soft, [])
})

test('checker: the single-hunk explanation with a question passes cleanly', () => {
  const { ctx } = setup({ kind: 'hunk', id: 'h2', question: H2_QUESTION })
  const { hard, soft } = check(h2QuestionScript(), ctx)
  assert.deepEqual(hard, [])
  assert.deepEqual(soft, [])
})

test('checker: a hunk that does not exist, or is outside the scope, is caught', () => {
  const whole = setup()
  const s = clone(wholeScript())
  s.deep[1].lines[0].show.hunk = 'h9'
  assert.match(check(s, whole.ctx).hard.join('\n'), /"h9", which is not a hunk in this change/)

  const one = setup({ kind: 'hunk', id: 'h2', question: H2_QUESTION })
  const t = clone(h2QuestionScript())
  t.deep[2].lines[0].show = { type: 'code', hunk: 'h5', file: '', side: 'after', from: 10, to: 13, item: -1 }
  assert.match(check(t, one.ctx).hard.join('\n'), /"h5", which is not in scope/)
})

test('checker: lines outside the hunk they name are caught', () => {
  const { ctx } = setup()
  const s = clone(wholeScript())
  s.deep[2].lines[0].show.to = 40 // h2's new lines end at 28
  assert.match(check(s, ctx).hard.join('\n'), /new lines 20–40 of h2, but that hunk's new lines are 14–28/)
})

test('checker: lines of a file Claude was not shown are caught, even when the file exists', () => {
  const { ctx } = setup()
  const s = clone(wholeScript())
  s.deep[0].lines[0].show = { type: 'code', hunk: '', file: 'README.md', side: 'after', from: 1, to: 2, item: -1 }
  assert.match(check(s, ctx).hard.join('\n'), /outside the excerpts and hunks you were shown/)
  s.deep[0].lines[0].show.file = 'src/nowhere.js'
  assert.match(check(s, ctx).hard.join('\n'), /not a file you were shown/)
  s.deep[0].lines[0].show = { type: 'code', hunk: '', file: 'src/carrierClient.js', side: 'after', from: 40, to: 60, item: -1 }
  assert.match(check(s, ctx).hard.join('\n'), /which has 43 lines/)
})

test('checker: "intent not stated" goes with why_source none, and only with it', () => {
  const { ctx } = setup()
  const s = clone(wholeScript())
  s.deep[4].why = 'To make the suite stronger.' // why_source is none
  assert.match(check(s, ctx).hard.join('\n'), /why_source none, so its why must be exactly "Intent not stated\."/)
  const t = clone(wholeScript())
  t.deep[1].why = 'Intent not stated.' // names a commit
  assert.match(check(t, ctx).hard.join('\n'), /names a source; use why_source none/)
  const u = clone(wholeScript())
  u.deep[1].why_source = 'commit:deadbee'
  assert.match(check(u, ctx).hard.join('\n'), /commit deadbee, which is not one of this change's commits/)
  u.deep[1].why_source = 'issue:7'
  assert.match(check(u, ctx).hard.join('\n'), /issue 7, which you were not shown/)
})

test('checker: a question is answered first; no answer chapter without one', () => {
  const asked = setup({ kind: 'hunk', id: 'h2', question: H2_QUESTION })
  const s = clone(h2QuestionScript())
  s.deep.shift()
  assert.match(check(s, asked.ctx).hard.join('\n'), /deep must start with an answer chapter/)
  const unasked = setup({ kind: 'hunk', id: 'h2' })
  assert.match(check(h2QuestionScript(), unasked.ctx).hard.join('\n'), /has an answer chapter, but no question was asked/)
})

test('checker: a claim that tests pass needs proof; describing tests or hedging does not', () => {
  const { ctx } = setup()
  const claim = (text, extra = {}) => {
    const s = clone(wholeScript())
    s.deep[4].lines[0].say = text
    return check(s, { ...ctx, ...extra }).hard.filter((h) => /nothing shows tests or checks passing/.test(h))
  }
  assert.equal(claim('All the new tests pass.').length, 1)
  assert.equal(claim('CI is green on this branch.').length, 1)
  assert.equal(claim('With passing tests for every path, this is ready.').length, 1)
  assert.equal(claim('The checks are all green.').length, 1)
  assert.equal(claim('All the new tests pass.', { proofPassing: true }).length, 0)
  assert.equal(claim('It is not known whether the tests pass.').length, 0)
  assert.equal(claim('The tests cover recovery after two 503s.').length, 0)
  assert.equal(claim('The isRetryable check passes 5xx errors through to another try.').length, 0)
})

test('checker: reasoning must quote its source word for word, and needs a source at all', () => {
  const sources = [{ id: 'session', label: 'Claude Code session', text: 'In the request layer every carrier call gets it, and the caller stays simple.' }]
  const { ctx } = setup({ kind: 'whole' }, { reasoningSources: sources })
  const s = clone(wholeScript())
  s.reasoning = [{ kind: 'approach', text: 'Retry lives in the request layer.', quote: 'In the request layer every carrier call gets it', source: 'session' }]
  s.deep.splice(6, 0, { kind: 'reasoning', title: 'Why the request layer', hunks: [], before: '', after: '', why: '', why_source: '', affects: '', nodes: [], edges: [],
    lines: [{ who: 0, say: 'The session says it went in the request layer so every call gets it.', show: { type: 'card', hunk: '', file: '', side: 'after', from: 0, to: 0, item: 0 } }] })
  assert.deepEqual(check(s, ctx).hard, [])
  s.reasoning[0].quote = 'Retries everywhere are always safe'
  assert.match(check(s, ctx).hard.join('\n'), /quote is not word for word in source "session"/)

  const none = setup()
  assert.match(check(s, none.ctx).hard.join('\n'), /no reasoning sources were given/)
})

test('checker: a never-show word is caught in the narration', () => {
  const { ctx } = setup()
  const s = clone(wholeScript())
  s.deep[0].lines[1].say += ' Project Bluebird depends on it.'
  assert.match(check(s, { ...ctx, neverShow: ['bluebird'] }).hard.join('\n'), /never-show list/)
})

test('checker: soft problems (a hunk left out, too long) are reported separately', () => {
  const { ctx } = setup()
  const s = clone(wholeScript())
  s.deep[3].hunks = ['h5'] // h3 now in no chapter
  s.quick[0].lines[0].say += ' ' + 'word '.repeat(60)
  const { hard, soft } = check(s, ctx)
  assert.deepEqual(hard, [])
  assert.match(soft.join('\n'), /leave out h3/)
  assert.match(soft.join('\n'), /quick is \d+ words/)
})

// ---- write → check → fix ----------------------------------------------------------------------

test('writing: a script that fails the check is sent back once with the problems, and the fix is used', async () => {
  const { src, scoped } = setup()
  const bad = clone(wholeScript())
  bad.deep[2].lines[0].show.to = 40
  const prompts = []
  const answers = [bad, wholeScript()]
  const writer = async ({ prompt }) => { prompts.push(prompt); return answers.shift() }
  const stages = []
  const out = await writeScript({ src, scoped, settings: defaultSettings(), writer, onProgress: (p) => stages.push(p.stage) })
  assert.equal(prompts.length, 2)
  assert.match(prompts[1], /that hunk's new lines are 14–28/)
  assert.equal(out.repaired, true)
  assert.deepEqual(out.warnings, [])
  assert.deepEqual(stages, ['context', 'write', 'check', 'repair', 'check'])
})

test('writing: a script still failing after one fix is refused, with the reasons', async () => {
  const { src, scoped } = setup()
  const bad = clone(wholeScript())
  bad.deep[4].lines[0].say = 'All the new tests pass.'
  const writer = async () => clone(bad)
  const err = await writeScript({ src, scoped, settings: defaultSettings(), writer }).catch((e) => e)
  assert.ok(err instanceof CheckFailed, String(err))
  assert.match(err.message, /did not pass the fact-check/)
  assert.ok(err.details.some((d) => /tests or checks passing/.test(d)))
})

test('writing: soft problems left after the fix become warnings, not a refusal', async () => {
  const { src, scoped } = setup()
  const soft = clone(wholeScript())
  soft.deep[3].hunks = ['h5']
  let n = 0
  const out = await writeScript({ src, scoped, settings: defaultSettings(), writer: async () => { n++; return clone(soft) } })
  assert.equal(n, 2)
  assert.match(out.warnings.join('\n'), /leave out h3/)
})

test('writing: the fixture writer hands out its answers in order, then repeats the last', async () => {
  const dir = temp()
  const file = join(dir, 'answers.json')
  writeFileSync(file, JSON.stringify({ explain: [{ n: 1 }, { n: 2 }], ask: [{ a: 1 }] }))
  const settings = settingsFromObject({ writer: { service: 'fixture', fixture: file } })
  resetFixtures()
  const got = []
  for (let i = 0; i < 3; i++) got.push((await write({ settings, purpose: 'explain' })).data.n)
  assert.deepEqual(got, [1, 2, 2])
  assert.equal((await write({ settings, purpose: 'ask' })).data.a, 1)
})

// ---- cache ------------------------------------------------------------------------------------

test('cache: the same change, scope and question give the same key; a new question does not', () => {
  const { context, src } = setup()
  const base = { listingText: context.listingText, excerpts: context.excerpts, question: '', pr: src.pr, commits: src.commits, proofText: '', reasoningSources: [], fingerprint: writerFingerprint(defaultSettings()) }
  const k = cacheKey(base)
  assert.equal(k, cacheKey({ ...base }))
  assert.notEqual(k, cacheKey({ ...base, question: 'Why four seconds?' }))
  assert.notEqual(k, cacheKey({ ...base, purpose: 'ask' }))
  assert.notEqual(k, cacheKey({ ...base, fingerprint: writerFingerprint(settingsFromObject({ writer: { effort: 'low' } })) }))
  assert.match(k, /^[0-9a-f]{64}$/)
})

test('cache: entries round-trip, and one from another format is ignored', () => {
  const c = fileCache(temp())
  c.put('k1', { format: FORMAT, engine: ENGINE_VERSION, title: 'x' })
  assert.equal(c.get('k1').title, 'x')
  c.put('k2', { format: 'something-else/9', engine: ENGINE_VERSION })
  assert.equal(c.get('k2'), null)
  assert.equal(c.get('missing'), null)
  assert.equal(fileCache(null).get('k1'), null)
})

// ---- presentation -----------------------------------------------------------------------------

test('presentation: highlighted files, hunks, and the function each shown line sits in', () => {
  const { src, scoped, ctx } = setup()
  const script = tidyScript(wholeScript(), ctx)
  const p = buildPresentation({ src, scoped, settings: defaultSettings(), script, id: 'test', created: '2026-11-22T00:00:00Z' })
  assert.equal(p.format, FORMAT)
  const client = p.files.find((f) => f.path === 'src/carrierClient.js')
  assert.equal(client.after.length, 43)
  assert.equal(client.afterCount, 43)
  assert.equal(client.beforeCount, 34)
  assert.match(client.after[36], /registerWebhook/)
  const retry = p.files.find((f) => f.path === 'src/retry.js')
  assert.deepEqual(retry.before, [])
  assert.equal(retry.status, 'added')
  assert.equal(p.hunks.length, 7)
  const req = p.depths.deep[2].lines[0]
  assert.equal(req.id, 'd3.1')
  assert.equal(req.show.fn, 'request')
  assert.equal(p.depths.deep[5].lines[0].show.fn, 'registerWebhook')
  assert.equal(p.depths.deep.at(-1).kind, 'focus')
  assert.equal(p.player.depth, 'deep')
  assert.equal(p.source.pr.number, 42)
})

test('presentation: a proof chapter goes in before the review focus', () => {
  const { src, scoped, ctx } = setup()
  const script = tidyScript(wholeScript(), ctx)
  const proof = { facts: { tests: [] }, chapter: { kind: 'proof', title: 'What the evidence shows', lines: [{ id: 'p1', who: 0, say: 'No test run was recorded.', show: { type: 'card', item: -1 } }] } }
  const p = buildPresentation({ src, scoped, settings: defaultSettings(), script, proof, id: 't' })
  const kinds = p.depths.deep.map((c) => c.kind)
  assert.deepEqual(kinds.slice(-2), ['proof', 'focus'])
  assert.ok(!p.depths.quick.some((c) => c.kind === 'proof'))
})

test('presentation: a never-show word in the code itself refuses the whole presentation', () => {
  const { src, scoped, ctx } = setup()
  const script = tidyScript(wholeScript(), ctx)
  assert.throws(
    () => buildPresentation({ src, scoped, settings: defaultSettings(), script, id: 't', neverShow: ['example-carrier'] }),
    (e) => e instanceof CheckFailed && /never-show list/.test(e.message) && !/example-carrier/.test(e.message + e.details.join(' ')),
  )
})

test('presentation: with only a diff (no files), the changed lines are still highlighted in place', () => {
  const src = openSource({ kind: 'diff', text: 'diff --git a/x.js b/x.js\n--- a/x.js\n+++ b/x.js\n@@ -10,2 +10,2 @@\n const a = 1\n-let b = 2\n+const b = 2\n' })
  const scoped = applyScope(src.diff, { kind: 'whole' })
  const script = { title: 't', summary: 's', focus_items: [], reasoning: [], quick: [], deep: [] }
  const p = buildPresentation({ src, scoped, settings: defaultSettings(), script, id: 't' })
  const f = p.files[0]
  assert.equal(f.after[8], null)
  assert.match(f.after[10], /hljs-keyword">const/)
  assert.match(f.before[10], /hljs-keyword">let/)
  assert.equal(f.afterCount, null)
})
