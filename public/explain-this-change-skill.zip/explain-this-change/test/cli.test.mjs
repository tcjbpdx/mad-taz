// The command, run the way a person (or Claude) runs it: on a copy of the practice project, with
// ready-made answers in place of Claude, so nothing is sent anywhere. Checks what it prints and the
// number it finishes with (0 done, 1 broke, 2 needs you, 3 a check failed).
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { SKILL_DIR } from '../scripts/lib/project.mjs'
import { buildSample } from '../scripts/lib/sample.mjs'
import { H2_FOLLOW_UP, H2_QUESTION, clone, h2FollowUpAnswer, h2QuestionScript, wholeScript } from './fixtures/parcel-pigeon-scripts.mjs'

const CLI = join(SKILL_DIR, 'scripts', 'explain.mjs')
const PR = join(SKILL_DIR, 'examples', 'parcel-pigeon', 'pr.json') // the practice pull request's description
const BRANCH = ['--base', 'main', '--head', 'retry-carrier-lookups', '--description', PR]

/** Runs the command and returns { code, out, err }. Never opens anything: --no-open on every step that would. */
function cli(args, { cwd, input, env = {} } = {}) {
  const r = spawnSync(process.execPath, [CLI, ...args], {
    cwd: cwd || SKILL_DIR,
    input,
    encoding: 'utf8',
    timeout: 60000,
    env: { ...process.env, EXPLAIN_DEBUG: '', ...env },
  })
  return { code: r.status, out: r.stdout, err: r.stderr }
}

/** A practice project of its own, started with the new step and set to use ready-made answers. */
function project({ explain = [wholeScript()], ask = [h2FollowUpAnswer()] } = {}) {
  const dir = buildSample(join(mkdtempSync(join(tmpdir(), 'etc-cli-')), 'parcel-pigeon')).dir
  const made = cli(['new', '--project', dir])
  assert.equal(made.code, 0, made.err)
  writeFileSync(join(dir, 'answers.json'), JSON.stringify({ explain: explain.map(clone), ask: ask.map(clone) }))
  const settings = join(dir, 'explain-this-change', 'settings.yaml')
  writeFileSync(settings, `project_name: Parcel Pigeon\nwriter:\n  service: fixture\n  fixture: answers.json\nvoice:\n  service: none\n`)
  return dir
}

test('no step prints the list of steps and finishes with 0', () => {
  const r = cli([])
  assert.equal(r.code, 0)
  for (const step of ['setup', 'new', 'doctor', 'explain', 'ask', 'serve', 'try', 'history', 'set-private']) assert.match(r.out, new RegExp(`\\n  ${step} `))
})

test('a misspelt step suggests the right one and finishes with 1', () => {
  const r = cli(['explian'])
  assert.equal(r.code, 1)
  assert.match(r.err, /Problem: "explian" is not a step I know\. Did you mean explain\?/)
})

test('a familiar word for a step runs that step', () => {
  const dir = mkdtempSync(join(tmpdir(), 'etc-alias-'))
  const init = cli(['init', '--project', dir])
  assert.equal(init.code, 0, init.err)
  assert.match(init.out, /made .*settings\.yaml/)
  const list = cli(['list', '--project', dir])
  assert.equal(list.code, 0)
  assert.match(list.out, /Nothing has been explained/)
})

test('new makes the settings and a private file only you can read, adds the ignore lines once, and never overwrites', () => {
  const dir = mkdtempSync(join(tmpdir(), 'etc-new-'))
  writeFileSync(join(dir, '.gitignore'), 'node_modules\n')
  const first = cli(['new', '--project', dir])
  assert.equal(first.code, 0, first.err)
  assert.match(first.out, /made .*settings\.yaml/)
  const priv = join(dir, 'explain-this-change', 'private.env')
  assert.equal(statSync(priv).mode & 0o777, 0o600)
  const gi = readFileSync(join(dir, '.gitignore'), 'utf8')
  assert.match(gi, /^node_modules\n\n# Explain This Change/)
  assert.match(gi, /explain-this-change\/private\.env/)

  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'project_name: Mine\n')
  const again = cli(['new', '--project', dir])
  assert.equal(again.code, 0)
  assert.match(again.out, /kept .*settings\.yaml/)
  assert.equal(readFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'utf8'), 'project_name: Mine\n')
  assert.equal(readFileSync(join(dir, '.gitignore'), 'utf8'), gi, 'the ignore lines are added once')
})

test('doctor passes with ready-made answers, and stops with 2 naming the one fix when a setting needs one', () => {
  const dir = project()
  const ok = cli(['doctor', '--project', dir])
  assert.equal(ok.code, 0, ok.out + ok.err)
  assert.match(ok.out, /✓ Ready-made answers are used instead of Claude/)
  assert.match(ok.out, /Everything is ready\./)
  assert.doesNotMatch(ok.out, /GitHub is signed in/, 'the practice project has no remote, so no descriptions are promised')

  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'writer:\n  service: fixture\n  fixture: answers.json\nvoice:\n  service: google\n')
  const stop = cli(['doctor', '--project', dir], { env: { GOOGLE_VOICE_KEY: '', GEMINI_API_KEY: '' } })
  assert.equal(stop.code, 2, stop.out + stop.err)
  assert.match(stop.err, /Needs you: The Google voice has no key\.\nFix: /)
  assert.doesNotMatch(stop.out, /Everything is ready/)

  // A key that is only a stand-in: the setup check never sends it anywhere.
  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'writer:\n  service: fixture\n  fixture: answers.json\nvoice:\n  service: google\n  google_voices: [Kore, kore]\n')
  const same = cli(['doctor', '--project', dir], { env: { GOOGLE_VOICE_KEY: 'stand-in-for-the-check', GEMINI_API_KEY: '' } })
  assert.equal(same.code, 0, same.out + same.err)
  assert.match(same.out, /• Both narrators use the same Google voice \(Kore\), so the captions follow the recording by its pauses alone/)

  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'depht: quick\n')
  const typo = cli(['doctor', '--project', dir])
  assert.equal(typo.code, 2)
  assert.match(typo.err, /settings\.yaml needs a fix\.\nFix: .*did you mean depth\?/s)

  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'writer:\n  service: fixture\n  fixture: missing.json\n')
  const broke = cli(['doctor', '--project', dir])
  assert.equal(broke.code, 1)
  assert.match(broke.err, /Problem: The writer fixture file is missing/)
})

test('doctor says when Claude Code is not installed, without trying to sign in', () => {
  const dir = project()
  writeFileSync(join(dir, 'explain-this-change', 'settings.yaml'), 'voice:\n  service: none\n')
  const r = cli(['doctor', '--project', dir], { env: { EXPLAIN_CLAUDE_BIN: join(dir, 'no-such-claude') } })
  assert.equal(r.code, 2)
  assert.match(r.err, /Needs you: Claude Code \(the claude command\) is not installed here/)
})

test('explain the whole branch: prints the title and the kept page, then a second run spends nothing', () => {
  const dir = project()
  const r = cli(['explain', '--project', dir, ...BRANCH, '--no-open'])
  assert.equal(r.code, 0, r.out + r.err)
  assert.match(r.out, /Explaining…/)
  const id = r.out.match(/Kept as ([0-9a-f]{16}):/)[1]
  const page = join(dir, 'explain-this-change', 'output', 'explainers', id, 'explain.html')
  assert.ok(existsSync(page), `the page is kept at ${page}`)
  assert.match(r.out, new RegExp(`then /x/${id}`))

  const again = cli(['explain', '--project', dir, ...BRANCH, '--no-open'])
  assert.equal(again.code, 0)
  assert.match(again.out, /explained before: nothing was spent/)
  assert.match(again.out, new RegExp(`Kept as ${id}`))
})

test('explain one change with a question, then ask a follow-up and see it in history', () => {
  const dir = project({ explain: [h2QuestionScript()] })
  const r = cli(['explain', '--project', dir, ...BRANCH, '--hunk', 'h2', '--question', H2_QUESTION, '--json'])
  assert.equal(r.code, 0, r.out + r.err)
  const done = JSON.parse(r.out)
  assert.match(done.id, /^[0-9a-f]{16}$/)
  assert.equal(done.cached, false)
  assert.ok(existsSync(done.path))

  const a = cli(['ask', done.id, '--project', dir, '--question', H2_FOLLOW_UP])
  assert.equal(a.code, 0, a.out + a.err)
  assert.match(a.out, /When the carrier stays down/)
  assert.match(a.out, /\n  (Avery|Jordan): /, 'each answer line is printed with its speaker')
  assert.match(readFileSync(done.path, 'utf8'), /When the carrier stays down/, 'the answer is added to the kept page')

  const h = cli(['history', '--project', dir])
  assert.equal(h.code, 0)
  assert.match(h.out, new RegExp(`^${done.id}  \\d{4}-\\d\\d-\\d\\d \\d\\d:\\d\\d  `))
  assert.match(h.out, /asked: Is it safe to retry every request\? · 1 follow-up question/)
})

test('an explanation that fails the fact-check, twice, is refused with 3 and the reasons', () => {
  const bad = h2QuestionScript()
  bad.quick[0].lines[0].say = 'The tests pass, so this is fine.'
  bad.deep[0].lines[0].say = 'The tests pass, so this is fine.'
  const dir = project({ explain: [bad] })
  const r = cli(['explain', '--project', dir, ...BRANCH, '--hunk', 'h2', '--question', H2_QUESTION, '--no-open'])
  assert.equal(r.code, 3, r.out + r.err)
  assert.match(r.err, /Check failed: /)
  assert.match(r.err, /  • .*nothing shows tests or checks passing/)
  assert.doesNotMatch(r.out, /Kept as/)
})

test('a why credited to the pull request needs its description: refused without it, accepted from a Markdown file', () => {
  const dir = project({ explain: [h2QuestionScript()] })
  const args = ['--hunk', 'h2', '--question', H2_QUESTION, '--no-open']
  const without = cli(['explain', '--project', dir, ...BRANCH.slice(0, 4), ...args])
  assert.equal(without.code, 3)
  assert.match(without.err, /names the pull request as its source, but there is no pull request description/)
  const md = join(dir, 'pr.md')
  const pr = JSON.parse(readFileSync(PR, 'utf8'))
  writeFileSync(md, `# ${pr.title}\n\n${pr.body}`)
  const withIt = cli(['explain', '--project', dir, ...BRANCH.slice(0, 4), '--description', md, ...args])
  assert.equal(withIt.code, 0, withIt.out + withIt.err)
})

test('the wrong things to explain are named plainly', () => {
  const dir = project()
  const two = cli(['explain', '--project', dir, '--pr', '4', '--staged', '--no-open'])
  assert.equal(two.code, 1)
  assert.match(two.err, /Name one change at a time: --pr and --staged/)
  const pr = cli(['explain', '--project', dir, '--pr', 'four', '--no-open'])
  assert.match(pr.err, /--pr should be a pull request number/)
  const both = cli(['explain', '--project', dir, '--pr', '4', '--description', PR, '--no-open'])
  assert.match(both.err, /--pr reads the description from GitHub/)
  const nodesc = cli(['explain', '--project', dir, ...BRANCH.slice(0, 4), '--description', join(dir, 'nope.md'), '--no-open'])
  assert.match(nodesc.err, /--description: there is no file/)
  const hunk = cli(['explain', '--project', dir, ...BRANCH, '--hunk', 'h99', '--no-open'])
  assert.equal(hunk.code, 1)
  assert.match(hunk.err, /h99/)
  const ask = cli(['ask', '--project', dir, '--question', 'Why?'])
  assert.match(ask.err, /Say which explanation/)
  const none = cli(['ask', '0123456789abcdef', '--project', dir, '--question', 'Why?'])
  assert.match(none.err, /There is no explainer "0123456789abcdef" here/)
})

test('an option the step does not have stops it before anything is done, and says what was meant', () => {
  const dir = project()
  const typo = cli(['explain', '--project', dir, ...BRANCH, '--flie', 'src/retry.js', '--no-open'])
  assert.equal(typo.code, 1)
  assert.match(typo.err, /--flie is not an option of the explain step, so nothing was done\. Did you mean --file\?/)
  assert.doesNotMatch(typo.out, /Explaining/)
  const elsewhere = cli(['history', '--project', dir, '--chapter', 'd2'])
  assert.equal(elsewhere.code, 1)
  assert.match(elsewhere.err, /--chapter is not an option of the history step, so nothing was done\. It belongs to the ask step\./)
  const noValue = cli(['explain', '--project', dir, '--pr', '--no-open'])
  assert.equal(noValue.code, 1)
  assert.match(noValue.err, /--pr needs a value after it, such as --pr 42\./)
  const bare = cli(['explain', '--project', dir, ...BRANCH, '--question', '--no-open'])
  assert.equal(bare.code, 1)
  assert.match(bare.err, /--question needs the question after it, in quotes/)
  const two = cli(['explain', '--project', dir, ...BRANCH, '--file', 'src/retry.js', '--hunk', 'h2', '--no-open'])
  assert.equal(two.code, 1)
  assert.match(two.err, /Name one part at a time: --file and --hunk were both given/)
  assert.doesNotMatch(two.out, /Kept as/)
})

test('--help after a step shows the help, and with --json a refusal comes back as JSON too', () => {
  const help = cli(['explain', '--help'])
  assert.equal(help.code, 0, help.err)
  assert.match(help.out, /The usual order/)

  const dir = project()
  const wrong = cli(['explain', '--project', dir, ...BRANCH, '--hunk', 'h99', '--json'])
  assert.equal(wrong.code, 1)
  const j = JSON.parse(wrong.out)
  assert.equal(j.ok, false)
  assert.equal(j.exitCode, 1)
  assert.match(j.problem, /h99/)
  assert.deepEqual(j.details, [])

  const bad = h2QuestionScript()
  bad.quick[0].lines[0].say = 'The tests pass, so this is fine.'
  bad.deep[0].lines[0].say = 'The tests pass, so this is fine.'
  const refused = cli(['explain', '--project', project({ explain: [bad] }), ...BRANCH, '--hunk', 'h2', '--question', H2_QUESTION, '--json'])
  assert.equal(refused.code, 3)
  const r = JSON.parse(refused.out)
  assert.equal(r.ok, false)
  assert.equal(r.exitCode, 3)
  assert.ok(r.details.some((d) => /nothing shows tests or checks passing/.test(d)), r.details.join(' | '))
})

test('ask names its mistakes: too short a question, a chapter that is not there, a depth that is not one', () => {
  const dir = project()
  const made = cli(['explain', '--project', dir, ...BRANCH, '--json'])
  assert.equal(made.code, 0, made.out + made.err)
  const { id, ok } = JSON.parse(made.out)
  assert.equal(ok, true)
  const short = cli(['ask', id, '--project', dir, '--question', 'ok'])
  assert.equal(short.code, 1)
  assert.match(short.err, /"ok" is too short to answer: ask it in a few words\./)
  const chapter = cli(['ask', id, '--project', dir, '--question', 'Why four seconds?', '--chapter', 'd99'])
  assert.equal(chapter.code, 1)
  assert.match(chapter.err, /There is no chapter "d99" in the (QUICK|DEEP DIVE) version of this explanation\. Its chapters are: [qd]1 \(/)
  const depth = cli(['ask', id, '--project', dir, '--question', 'Why four seconds?', '--depth', 'medium'])
  assert.equal(depth.code, 1)
  assert.match(depth.err, /--depth is quick or deep \(not "medium"\)\./)
})

test('history with nothing kept says so', () => {
  const r = cli(['history', '--project', mkdtempSync(join(tmpdir(), 'etc-empty-'))])
  assert.equal(r.code, 0)
  assert.match(r.out, /Nothing has been explained in this project yet\./)
})

test('set-private writes a line from what is piped in, never shows it, and refuses an empty pipe', () => {
  const dir = mkdtempSync(join(tmpdir(), 'etc-private-'))
  assert.equal(cli(['new', '--project', dir]).code, 0)
  const value = 'a-long-random-helper-phrase-for-the-test-only'
  const r = cli(['set-private', 'explain_server_token', '--project', dir], { input: `${value}\n` })
  assert.equal(r.code, 0, r.err)
  assert.doesNotMatch(r.out + r.err, new RegExp(value))
  assert.match(readFileSync(join(dir, 'explain-this-change', 'private.env'), 'utf8'), new RegExp(`^EXPLAIN_SERVER_TOKEN=${value}$`, 'm'))
  const empty = cli(['set-private', 'EXPLAIN_SERVER_TOKEN', '--project', dir], { input: '' })
  assert.equal(empty.code, 1)
  assert.match(empty.err, /Nothing was piped in/)
  const unnamed = cli(['set-private', '--project', dir], { input: 'x' })
  assert.match(unnamed.err, /Name the line to write/)
})

/** Starts a long-running step, waits for its address, and returns { url, stop() → { code, out } }. */
function startLong(args) {
  return new Promise((ok, fail) => {
    const p = spawn(process.execPath, [CLI, ...args], { cwd: SKILL_DIR, env: { ...process.env, EXPLAIN_DEBUG: '' } })
    let out = ''
    let err = ''
    const timer = setTimeout(() => { p.kill('SIGKILL'); fail(new Error(`no address after 30s:\n${out}\n${err}`)) }, 30000)
    p.stderr.on('data', (d) => { err += d })
    p.stdout.on('data', (d) => {
      out += d
      const m = /Stop it with Ctrl\+C/.test(out) && out.match(/(http:\/\/127\.0\.0\.1:\d+)/)
      if (m) {
        clearTimeout(timer)
        ok({ url: m[1], out: () => out, stop: () => new Promise((done) => { p.once('exit', (code) => done({ code, out, err })); p.kill('SIGINT') }) })
      }
    })
    p.once('exit', (code) => { clearTimeout(timer); fail(new Error(`ended with ${code} before it started:\n${out}\n${err}`)) })
  })
}

test('serve runs the helper until Ctrl+C, then stops cleanly with 0', async () => {
  const dir = project()
  const s = await startLong(['serve', '--project', dir, '--port', '0', '--no-open', '--quiet'])
  const health = await fetch(`${s.url}/health`).then((r) => r.json())
  assert.equal(health.ok, true)
  const index = await fetch(`${s.url}/`).then((r) => r.text())
  assert.match(index, /The helper is running/)
  const end = await s.stop()
  assert.equal(end.code, 0)
  assert.match(end.out, /Stopped\./)
})

test('try --offline serves the practice review page and answers the ready-made questions with nothing sent', async () => {
  const s = await startLong(['try', '--offline', '--port', '0', '--no-open', '--quiet', '--project', mkdtempSync(join(tmpdir(), 'etc-try-'))])
  try {
    assert.match(s.out(), /Offline: ready-made answers, nothing is sent/)
    const page = await fetch(`${s.url}/example`).then((r) => r.text())
    assert.match(page, /<script src="\/button.js"/)
    const res = await fetch(`${s.url}/explain`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', origin: s.url },
      body: JSON.stringify({ scope: { kind: 'whole' } }),
    })
    const lines = (await res.text()).trim().split('\n').map((l) => JSON.parse(l))
    const done = lines.find((l) => l.done)
    assert.ok(done, JSON.stringify(lines))
    assert.match(done.done.url, /^\/x\/[0-9a-f]{16}/)

    const other = await fetch(`${s.url}/explain`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', origin: s.url },
      body: JSON.stringify({ scope: { kind: 'file', file: 'src/carrierClient.js' } }),
    })
    const tail = (await other.text()).trim().split('\n').map((l) => JSON.parse(l)).pop()
    assert.match(JSON.stringify(tail), /ready-made answers/, 'a part without a ready-made answer says so plainly')
  } finally {
    const end = await s.stop()
    assert.equal(end.code, 0, end.err)
  }
})
