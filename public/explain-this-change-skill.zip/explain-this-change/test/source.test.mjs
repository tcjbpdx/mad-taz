import { test } from 'node:test'
import assert from 'node:assert/strict'
import { openSource } from '../scripts/lib/source.mjs'
import { sampleRepo } from './helpers.mjs'
import { buildSample } from '../scripts/lib/sample.mjs'
import { appendFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

test('reads the sample pull request from its git branch', () => {
  const s = sampleRepo()
  const src = openSource({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { settings: { source: { use_github: false } } })
  assert.deepEqual(src.diff.files.map((f) => f.path).sort(), ['src/carrierClient.js', 'src/format.js', 'src/retry.js', 'src/trackingService.js', 'test/retry.test.js', 'test/trackingService.test.js'])
  assert.equal(src.commits.length, 3)
  assert.ok(src.commits.every((c) => c.claude), 'every sample commit is marked as written with Claude')
  assert.match(src.readFile('before', 'src/carrierClient.js'), /TIMEOUT_MS = 10_000/)
  assert.match(src.readFile('after', 'src/carrierClient.js'), /TIMEOUT_MS = 4_000/)
  assert.equal(src.readFile('before', 'src/retry.js'), null)
  assert.equal(src.pr.number, 42)
  assert.match(src.label, /retry-carrier-lookups compared with main/)
})

/** A sample of its own, for the tests that change files (the shared one must stay untouched). */
function freshSample(t) {
  const home = mkdtempSync(join(tmpdir(), 'etc-uncommitted-'))
  t.after(() => rmSync(home, { recursive: true, force: true }))
  return buildSample(join(home, 'parcel-pigeon'))
}
const LOCAL = { settings: { source: { use_github: false } } }
const gitIn = (dir, ...args) => execFileSync('git', args, { cwd: dir, encoding: 'utf8', env: { ...process.env, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' } })
const paths = (src) => src.diff.files.map((f) => f.path).sort()

test('uncommitted work is measured against the last commit: only what is not committed yet', (t) => {
  const s = freshSample(t)
  appendFileSync(join(s.dir, 'README.md'), '\nA line not committed yet.\n')
  const src = openSource({ kind: 'git', repo: s.dir, head: 'worktree' }, LOCAL)
  assert.deepEqual(src.diff.files.map((f) => [f.path, f.status]), [['README.md', 'modified']])
  assert.equal(src.commits.length, 0)
  assert.equal(src.label, 'uncommitted work')
  assert.deepEqual(src.notes, [])
  assert.match(src.readFile('after', 'README.md'), /A line not committed yet/)
  // The usual base in settings does not widen it; only a base named for this run does.
  const withSetting = openSource({ kind: 'git', repo: s.dir, head: 'worktree' }, { settings: { source: { use_github: false, base: 'main' } } })
  assert.deepEqual(paths(withSetting), ['README.md'])
})

test('naming a base with uncommitted work gives everything since that branch, committed or not', (t) => {
  const s = freshSample(t)
  appendFileSync(join(s.dir, 'README.md'), '\nA line not committed yet.\n')
  const src = openSource({ kind: 'git', repo: s.dir, base: 'main', head: 'worktree' }, LOCAL)
  assert.deepEqual(paths(src), ['README.md', 'src/carrierClient.js', 'src/format.js', 'src/retry.js', 'src/trackingService.js', 'test/retry.test.js', 'test/trackingService.test.js'])
  assert.equal(src.commits.length, 3)
  assert.equal(src.label, 'everything since main, committed or not')
})

test('a new file git is not tracking is left out and named, so a stray secrets file cannot slip in', (t) => {
  const s = freshSample(t)
  appendFileSync(join(s.dir, 'README.md'), '\nEdited.\n')
  writeFileSync(join(s.dir, 'secrets.txt'), 'pretend-secret-value\n')
  const src = openSource({ kind: 'git', repo: s.dir, head: 'worktree' }, LOCAL)
  assert.deepEqual(paths(src), ['README.md'])
  assert.doesNotMatch(src.diffText, /pretend-secret-value/)
  assert.equal(src.notes.length, 1)
  assert.match(src.notes[0], /^One new file git is not tracking yet was left out: secrets\.txt\./)
  assert.match(src.notes[0], /git add --intent-to-add <file>/)
  // Marked with --intent-to-add, it becomes part of the change.
  gitIn(s.dir, 'add', '--intent-to-add', 'secrets.txt')
  const added = openSource({ kind: 'git', repo: s.dir, head: 'worktree' }, LOCAL)
  assert.deepEqual(added.diff.files.map((f) => [f.path, f.status]).sort(), [['README.md', 'modified'], ['secrets.txt', 'added']])
  assert.equal(added.readFile('after', 'secrets.txt'), 'pretend-secret-value\n')
  assert.deepEqual(added.notes, [])
})

test('with nothing uncommitted it says so, and names any new files it left out', (t) => {
  const s = freshSample(t)
  assert.throws(() => openSource({ kind: 'git', repo: s.dir, head: 'worktree' }, LOCAL), /There is nothing to explain: uncommitted work has no changes\.$/)
  for (let i = 1; i <= 7; i++) writeFileSync(join(s.dir, `draft-${i}.md`), 'notes\n')
  assert.throws(() => openSource({ kind: 'git', repo: s.dir, head: 'worktree' }, LOCAL), /uncommitted work has no changes\. 7 new files or folders git is not tracking yet were left out: draft-1\.md, draft-2\.md, draft-3\.md, draft-4\.md, draft-5\.md and 2 more\./)
})

test('--staged shows only what is staged', (t) => {
  const s = freshSample(t)
  appendFileSync(join(s.dir, 'README.md'), '\nStaged line.\n')
  gitIn(s.dir, 'add', 'README.md')
  appendFileSync(join(s.dir, 'src', 'format.js'), '\n// not staged\n')
  const src = openSource({ kind: 'git', repo: s.dir, head: 'staged' }, LOCAL)
  assert.deepEqual(paths(src), ['README.md'])
  assert.equal(src.label, 'staged work')
  assert.doesNotMatch(src.diffText, /not staged/)
  assert.match(src.readFile('after', 'README.md'), /Staged line/)
})

test('reads a saved diff file', () => {
  const src = openSource({ kind: 'diff', text: 'diff --git a/x b/x\n--- a/x\n+++ b/x\n@@ -1 +1 @@\n-a\n+b\n' })
  assert.equal(src.diff.hunks.length, 1)
  assert.equal(src.readFile('after', 'x'), null)
})

test('an empty change is said plainly', () => {
  const s = sampleRepo()
  assert.throws(() => openSource({ kind: 'git', repo: s.dir, base: s.head, head: s.head }, { settings: { source: { use_github: false } } }), /nothing to explain/)
})
