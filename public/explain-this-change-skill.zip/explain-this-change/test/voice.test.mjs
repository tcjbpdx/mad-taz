// The Google voice: what is sent, how busy and daily limits are handled, where each line is found in
// a recording, and how recordings are kept and put in the page. Nothing here reaches Google: the
// "recordings" are made up from tones at two pitches, with pauses where a voice would pause.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  DEFAULT_STYLE, addVoice, asWav, encodeTake, findMarks, readWav, recordTake, spokenText, takeHash, takeRequest, takesOf, writeWav,
} from '../scripts/lib/voice.mjs'
import { defaultSettings } from '../scripts/lib/settings.mjs'
import { playerSettings, refuseNeverShow } from '../scripts/lib/present.mjs'
import { forPage, renderHtml } from '../scripts/lib/render.mjs'
import { listExplainers, readExplainer, saveExplainer } from '../scripts/lib/store.mjs'
import { ENGINE_VERSION, FORMAT } from '../scripts/lib/project.mjs'

const FAKE_KEY = `AIza${'Q7'.repeat(17)}x` // the shape of a Google key, not a real one

function googleSettings() {
  const s = defaultSettings()
  s.voice.service = 'google'
  return s
}

// ---- a made-up voice --------------------------------------------------------------------------------

function seeded(seed) {
  let x = seed >>> 0
  return () => { x = (x * 1664525 + 1013904223) >>> 0; return x / 2 ** 32 }
}

/** A buzzy vowel at a pitch, faded in and out. */
function vowel(out, at, seconds, hz, rate) {
  const n = Math.round(seconds * rate)
  let phase = 0
  const fade = 0.012 * rate
  for (let i = 0; i < n && at + i < out.length; i++) {
    phase += (2 * Math.PI * hz * (1 + 0.025 * Math.sin((2 * Math.PI * 4 * i) / rate))) / rate
    let v = 0
    for (let h = 1; h <= 6; h++) v += Math.sin(h * phase) / h
    out[at + i] += 0.22 * v * Math.min(1, i / fade, (n - i) / fade)
  }
}

/**
 * Speech-like sound for lines [{ who, spoken }]: each word a vowel at the narrator's pitch, short gaps
 * between words, longer ones after commas and full stops, and pauses between turns that overlap the
 * long ones in length (so pauses alone cannot say where a line ends). swing makes each phrase higher or
 * lower than the last, as one voice rises and falls; stray is the chance that a phrase is said up or
 * down in the other narrator's range, as real voices now and then are. Returns { samples, starts }.
 */
function speak(lines, { rate = 16000, hz = [118, 205], pace = [0.062, 0.054], seed = 7, turnGap = [0.22, 0.5], commaGap = [0.15, 0.42], swing = 0, stray = 0 } = {}) {
  const r = seeded(seed)
  const between = ([lo, hi]) => lo + r() * (hi - lo)
  const plan = []
  let t = 0.25
  const starts = []
  lines.forEach((l, k) => {
    if (k) t += between(turnGap)
    starts.push(t)
    // how high each phrase is said, as a voice rises and falls (and now and then strays)
    const phrase = () => (1 + swing * (2 * r() - 1)) * (stray && r() < stray ? hz[1 - l.who] / hz[l.who] : 1)
    let tune = phrase()
    const words = l.spoken.split(/\s+/).filter(Boolean)
    words.forEach((w, i) => {
      const len = Math.max(0.09, w.replace(/[^\w]/g, '').length * pace[l.who] + 0.04)
      plan.push([t, len, hz[l.who] * tune * (0.94 + 0.12 * r())])
      t += len
      if (i < words.length - 1 && /[,.;:]$/.test(w)) { t += between(commaGap); tune = phrase() } else if (i < words.length - 1) t += 0.02 + 0.025 * r()
    })
  })
  const samples = new Float32Array(Math.ceil((t + 0.3) * rate))
  for (const [at, len, f] of plan) vowel(samples, Math.round(at * rate), len, f, rate)
  for (let i = 0; i < samples.length; i++) samples[i] += (r() - 0.5) * 0.002
  return { samples, starts }
}

const LINES = [
  [0, 'So this change adds a retry when the carrier rejects a label, and it waits a little longer each time.'],
  [1, 'Right. Before, one failure meant the parcel sat in the queue until someone noticed.'],
  [0, 'Exactly, and that could be hours.'],
  [0, 'The new loop tries three times, doubling the wait, then gives up and flags the parcel.'],
  [1, 'And the wait starts at half a second?'],
  [0, 'Half a second, then one, then two.'],
  [1, 'Good. The tests cover the give-up path, but not a carrier that answers slowly.'],
  [1, 'That is the review focus: what happens when a retry overlaps a slow answer.'],
  [0, 'Worth a look before it merges.'],
].map(([who, spoken], k) => ({ id: `d1.${k + 1}`, who, spoken }))

function assertNear(marks, starts, within, label) {
  assert.equal(marks.length, starts.length)
  assert.equal(marks[0][0], 0)
  for (let k = 1; k < starts.length; k++) {
    const off = Math.abs(marks[k][0] - starts[k])
    assert.ok(off <= within, `${label}: line ${k + 1} starts at ${marks[k][0]}s, the sound starts at ${starts[k].toFixed(3)}s (${off.toFixed(3)}s out)`)
    assert.equal(marks[k - 1][1], marks[k][0], 'each line ends where the next begins')
  }
}

// ---- the words and the request ----------------------------------------------------------------------

test('voice: say_it_like is applied as the player applies it, whole words only', () => {
  assert.equal(spokenText('The API calls the  SQL api.', { API: 'A P I', sql: 'sequel' }), 'The A P I calls the sequel A P I.')
  assert.equal(spokenText('RAPID apis', { API: 'A P I' }), 'RAPID apis')
})

test('voice: the request names each turn\'s narrator and gives each narrator a voice; only the words go', () => {
  const v = googleSettings().voice
  const req = takeRequest(LINES.slice(0, 3), v)
  assert.equal(req.model, v.google_model)
  assert.deepEqual(req.response_format, { type: 'audio' })
  assert.deepEqual(req.generation_config.speech_config, [{ speaker: v.speakers[0], voice: v.google_voices[0] }, { speaker: v.speakers[1], voice: v.google_voices[1] }])
  const content = req.input[0].content
  assert.equal(content.length, 3)
  assert.deepEqual(content.map((c) => c.annotations[0].speaker), [v.speakers[0], v.speakers[1], v.speakers[0]])
  assert.ok(content.every((c) => c.annotations[0].style === DEFAULT_STYLE))
  assert.deepEqual(Object.keys(req).sort(), ['generation_config', 'input', 'model', 'response_format'])
  // One narrator only: one voice, the lines as one text.
  const solo = takeRequest(LINES.slice(2, 4), { ...v, style: 'Calm.' })
  assert.deepEqual(solo.generation_config.speech_config, [{ voice: v.google_voices[0] }])
  assert.equal(solo.input[0].content.length, 1)
  assert.equal(solo.input[0].content[0].text, `${LINES[2].spoken}\n${LINES[3].spoken}`)
  assert.equal(solo.input[0].content[0].annotations[0].style, 'Calm.')
})

test('voice: a recording is named by its words, voices and style, so a change records it again', () => {
  const v = googleSettings().voice
  const h = takeHash(LINES, v)
  assert.match(h, /^[0-9a-f]{16}$/)
  assert.equal(takeHash(LINES.map((l) => ({ ...l })), v), h)
  assert.notEqual(takeHash(LINES, { ...v, google_voices: ['Puck', 'Kore'] }), h)
  assert.notEqual(takeHash(LINES, { ...v, style: 'Faster.' }), h)
  assert.notEqual(takeHash([{ ...LINES[0], spoken: 'Something else.' }, ...LINES.slice(1)], v), h)
})

// ---- asking Google ----------------------------------------------------------------------------------

function answer(status, body) {
  return { ok: status >= 200 && status < 300, status, json: async () => body }
}
const audioBody = (pcm, rate = 24000) => ({ steps: [{ type: 'user_input' }, { type: 'model_output', content: [{ type: 'text', text: 'ok' }, { type: 'audio', mime_type: `audio/L16;codec=pcm;rate=${rate}`, data: pcm.toString('base64') }] }] })

test('voice: a busy minute is waited out; the key goes in a header, never the address', async () => {
  const calls = []
  const waits = []
  const replies = [answer(429, { error: { message: 'Resource exhausted. Please try again later.' } }), answer(503, {}), answer(200, audioBody(Buffer.alloc(4800)))]
  const fetchImpl = async (url, init) => { calls.push({ url, init }); return replies.shift() }
  const wav = await recordTake({ model: 'm' }, { key: FAKE_KEY, fetchImpl, pause: async (ms) => { waits.push(ms) } })
  assert.equal(calls.length, 3)
  assert.equal(waits.length, 2)
  assert.ok(waits[1] > waits[0], 'each wait is longer than the last')
  assert.ok(!calls[0].url.includes(FAKE_KEY))
  assert.equal(calls[0].init.headers['x-goog-api-key'], FAKE_KEY)
  assert.equal(wav.toString('ascii', 0, 4), 'RIFF')
  assert.equal(readWav(wav).rate, 24000)
})

test('voice: the daily limit stops at once, and an error never repeats the key', async () => {
  let calls = 0
  const daily = async () => { calls++; return answer(429, { error: { message: 'Quota exceeded for metric: requests per day. Limit: 100' } }) }
  await assert.rejects(recordTake({ model: 'm' }, { key: FAKE_KEY, fetchImpl: daily, pause: async () => {} }), (e) => e.daily === true && /daily limit/.test(e.message))
  assert.equal(calls, 1, 'no retry against a daily limit')
  const leaky = async () => answer(400, { error: { message: `API key not valid: ${FAKE_KEY}` } })
  await assert.rejects(recordTake({ model: 'm' }, { key: FAKE_KEY, fetchImpl: leaky, pause: async () => {} }), (e) => !e.message.includes(FAKE_KEY) && /key was not accepted/.test(e.message))
  const missing = async () => answer(404, { error: { message: 'model not found' } })
  await assert.rejects(recordTake({ model: 'made-up-tts' }, { key: FAKE_KEY, fetchImpl: missing, pause: async () => {} }), /no voice model called "made-up-tts"/)
})

test('voice: wave files in and out — Google\'s bare samples get a header; stereo is mixed down', () => {
  const samples = new Float32Array([0, 0.5, -0.5, 0.25])
  const wav = writeWav(samples, 22050)
  const back = readWav(wav)
  assert.equal(back.rate, 22050)
  assert.deepEqual([...back.samples].map((v) => Math.round(v * 100) / 100), [0, 0.5, -0.5, 0.25])
  assert.equal(asWav(wav), wav, 'a wave file is passed through')
  const bare = asWav(Buffer.from([0, 64, 0, 192]), 24000)
  assert.deepEqual([...readWav(bare).samples], [0.5, -0.5])
  const stereo = Buffer.from(writeWav(new Float32Array([0.5, 0.5]), 8000))
  stereo.writeUInt16LE(2, 22) // two channels of one sample each: 0.5 and 0.5
  assert.deepEqual([...readWav(stereo).samples], [0.5])
  assert.throws(() => readWav(Buffer.from('not a wave file at all')), /not a wave file/)
})

// ---- where each line starts ---------------------------------------------------------------------------

test('lines: found from the pauses and the two pitches, even where pauses alone would mislead', () => {
  const { samples, starts } = speak(LINES)
  const { marks, method } = findMarks(samples, 16000, LINES)
  assert.equal(method, 'pauses and voices')
  assertNear(marks, starts, 0.12, 'two pitches')
  assert.equal(marks.at(-1)[1], Math.round((samples.length / 16000) * 1000) / 1000, 'the last line runs to the end')
})

test('lines: three other seeds and paces, the same narrator twice in a row included', () => {
  for (const seed of [11, 23, 42]) {
    const pace = seed === 23 ? [0.07, 0.05] : [0.058, 0.064]
    const { samples, starts } = speak(LINES, { seed, pace, hz: seed === 42 ? [190, 125] : [118, 205] })
    assertNear(findMarks(samples, 16000, LINES).marks, starts, 0.12, `seed ${seed}`)
  }
})

test('lines: one voice at one pitch still lines up, when the turns pause longer than the commas', () => {
  const { samples, starts } = speak(LINES, { hz: [150, 150], pace: [0.06, 0.06], turnGap: [0.45, 0.7], commaGap: [0.12, 0.3] })
  const { marks, method } = findMarks(samples, 16000, LINES)
  assert.equal(method, 'pauses')
  assertNear(marks, starts, 0.12, 'one pitch')
})

test('lines: one voice that rises and falls is not taken for two voices', () => {
  // Read by one voice, some phrases high and some low: the pitches split into two groups that look
  // well apart, but laid out as two voices too much of the speech sits with the wrong one, so the
  // pauses decide. (The old test, "two groups far enough apart", called these two voices.)
  for (const seed of [3, 5, 13, 34, 89]) {
    const { samples, starts } = speak(LINES, { seed, hz: [140, 140], pace: [0.06, 0.06], swing: 0.45, turnGap: [0.45, 0.7], commaGap: [0.12, 0.3] })
    const { marks, method } = findMarks(samples, 16000, LINES)
    assert.equal(method, 'pauses', `seed ${seed}`)
    assertNear(marks, starts, 0.12, `one voice, seed ${seed}`)
  }
})

test('lines: two voices are still told apart when each one rises and falls', () => {
  for (const seed of [3, 21, 55]) {
    const { samples, starts } = speak(LINES, { seed, swing: 0.15 })
    const { marks, method } = findMarks(samples, 16000, LINES)
    assert.equal(method, 'pauses and voices', `seed ${seed}`)
    assertNear(marks, starts, 0.12, `two voices that wander, seed ${seed}`)
  }
})

test('lines: two different voices asked for are trusted as far as they prove right', () => {
  // Real voices are untidy: a phrase now and then sits in the other narrator's range. Told that two
  // different voices were recorded, the timing still goes by voice, weighing pitch by how often it
  // was right; not told, it holds pitch to the strict test and falls back on the pauses.
  for (const seed of [2, 7, 10]) {
    const { samples, starts } = speak(LINES, { seed, hz: [163, 104], pace: [0.06, 0.066], swing: 0.15, stray: 0.06 })
    const told = findMarks(samples, 16000, LINES, { voices: 'different' })
    assert.equal(told.method, 'pauses and voices', `seed ${seed}`)
    assertNear(told.marks, starts, 0.12, `two different voices, seed ${seed}`)
    assert.equal(findMarks(samples, 16000, LINES).method, 'pauses', `not told, seed ${seed}`)
  }
  // Untidier still, with long pauses between turns: trusted at full weight, the stray phrases pull
  // turns 0.6–3 seconds out here; weighed by how often pitch was right, every line lands (by voice
  // where it still fits, by the pauses where it does not).
  for (const seed of [4, 10, 22]) {
    const { samples, starts } = speak(LINES, { seed, hz: [163, 104], pace: [0.06, 0.066], swing: 0.2, stray: 0.15, turnGap: [0.4, 0.9], commaGap: [0.1, 0.35] })
    assertNear(findMarks(samples, 16000, LINES, { voices: 'different' }).marks, starts, 0.12, `untidy voices, seed ${seed}`)
  }
})

test('lines: one voice for both narrators goes by the pauses alone, whatever the pitches', () => {
  const { samples } = speak(LINES)
  assert.equal(findMarks(samples, 16000, LINES).method, 'pauses and voices', 'two pitches, not told')
  const same = findMarks(samples, 16000, LINES, { voices: 'same' })
  assert.equal(same.method, 'pauses')
  assert.equal(same.marks.length, LINES.length)
})

test('lines: two similar voices asked for as different are held to the strict test', () => {
  // Two voices a few semitones apart, or two names that sound like one voice: told they are different,
  // the pitch is still not trusted beyond the strict test (the last one would be 6 seconds out), and
  // clear pauses between turns time them.
  for (const [hz, seed] of [[[150, 158], 3], [[150, 158], 5], [[150, 158], 13], [[140, 140], 13]]) {
    const { samples, starts } = speak(LINES, { seed, hz, pace: [0.06, 0.06], swing: 0.1, turnGap: [0.45, 0.7], commaGap: [0.12, 0.3] })
    const { marks, method } = findMarks(samples, 16000, LINES, { voices: 'different' })
    assert.equal(method, 'pauses', `seed ${seed}`)
    assertNear(marks, starts, 0.12, `similar voices, seed ${seed}`)
  }
})

test('lines: a recording with too few pauses is shared out by length, never fails', () => {
  const samples = new Float32Array(16000 * 3)
  for (let i = 0; i < samples.length; i++) samples[i] = Math.sin(i / 5) * 0.3
  const { marks, method } = findMarks(samples, 16000, LINES.slice(0, 3))
  assert.equal(method, 'estimated')
  assert.equal(marks.length, 3)
  assert.equal(marks[0][0], 0)
  assert.equal(marks[2][1], 3)
  assert.deepEqual(findMarks(samples, 16000, LINES.slice(0, 1)).marks, [[0, 3]])
})

// ---- the explanation's recordings ---------------------------------------------------------------------

const say = (spoken) => spoken
function presentationOf() {
  const quick = [{ id: 'q1', lines: LINES.slice(0, 3).map((l, k) => ({ id: `q1.${k + 1}`, who: l.who, say: say(l.spoken), show: { type: 'card' } })) }]
  const deep = [
    { id: 'd1', lines: LINES.slice(0, 5).map((l, k) => ({ id: `d1.${k + 1}`, who: l.who, say: say(l.spoken), show: { type: 'card' } })) },
    { id: 'd2', lines: LINES.slice(5).map((l, k) => ({ id: `d2.${k + 1}`, who: l.who, say: say(l.spoken), show: { type: 'card' } })) },
  ]
  return { format: FORMAT, engine: ENGINE_VERSION, id: 'abcdef0123456789', title: 'Retry labels', depths: { quick, deep }, answers: [], files: [], hunks: [], player: playerSettings(googleSettings()) }
}

/** A stand-in for Google: makes the tones for the turns it is sent, with the pitch of each voice. */
function fakeGoogle({ rate = 16000, log = [] } = {}) {
  return async (url, init) => {
    const req = JSON.parse(init.body)
    log.push(req)
    const cfg = req.generation_config.speech_config
    const content = req.input[0].content
    const turns = cfg.length === 1
      ? content[0].text.split('\n').map((t) => ({ who: 0, spoken: t }))
      : content.map((c) => ({ who: cfg.findIndex((x) => x.speaker === c.annotations[0].speaker), spoken: c.text }))
    const { samples } = speak(turns, { rate, seed: log.length })
    const pcm = writeWav(samples, rate).subarray(44)
    return answer(200, audioBody(Buffer.from(pcm), rate))
  }
}

async function withKey(fn) {
  const before = process.env.GOOGLE_VOICE_KEY
  process.env.GOOGLE_VOICE_KEY = FAKE_KEY
  try { return await fn() } finally { if (before === undefined) delete process.env.GOOGLE_VOICE_KEY; else process.env.GOOGLE_VOICE_KEY = before }
}

test('recordings: one take per version, a mark for every line, and nothing recorded twice', async () => {
  await withKey(async () => {
    const p = presentationOf()
    const log = []
    const progress = []
    const out = await addVoice(p, googleSettings(), { fetchImpl: fakeGoogle({ log }), encoder: 'wav', onProgress: (e) => progress.push(e.message) })
    assert.deepEqual(out.recorded, ['quick', 'deep'])
    assert.equal(log.length, 2, 'one request per version')
    assert.equal(log[1].input[0].content.length, LINES.length, 'the whole deep dive is one take')
    assert.ok(progress.some((m) => /Recording the deep dive in Google's voices \(Kore and Charon\)/.test(m)))
    const deep = p.audio.tracks.deep
    assert.equal(deep.mime, 'audio/wav')
    assert.match(deep.src, /^data:audio\/wav;base64,/)
    assert.deepEqual(Object.keys(deep.marks), [...LINES.slice(0, 5).map((_, k) => `d1.${k + 1}`), ...LINES.slice(5).map((_, k) => `d2.${k + 1}`)])
    assert.deepEqual(Object.keys(p.audio.tracks.quick.marks), ['q1.1', 'q1.2', 'q1.3'])
    assert.equal(p.audio.note, '')
    // Again, unchanged: kept, not asked for.
    const again = await addVoice(p, googleSettings(), { fetchImpl: fakeGoogle({ log }), encoder: 'wav' })
    assert.deepEqual(again.kept, ['quick', 'deep'])
    assert.equal(log.length, 2)
    // An answer added later is one more take, and only that.
    p.answers.push({ id: 'a1', question: 'Why three tries?', chapter: { title: 'Why three', lines: [{ id: 'a1.1', who: 1, say: 'Three is what the carrier\'s guide suggests.', show: { type: 'card' } }, { id: 'a1.2', who: 0, say: 'The change does not say why.', show: { type: 'card' } }] } })
    const ans = await addVoice(p, googleSettings(), { fetchImpl: fakeGoogle({ log }), encoder: 'wav', only: ['a1'] })
    assert.deepEqual(ans.recorded, ['a1'])
    assert.equal(log.length, 3)
    assert.deepEqual(Object.keys(p.audio.tracks).sort(), ['a1', 'deep', 'quick'])
  })
})

test('recordings: a long version is recorded in parts, joined in order with the marks carried across', async () => {
  await withKey(async () => {
    const long = (k) => ({ id: `d${k}`, lines: Array.from({ length: 6 }, (_, j) => ({ id: `d${k}.${j + 1}`, who: j % 2, say: `${LINES[(k + j) % LINES.length].spoken} ${'Then the next part follows on from there, step by step, '.repeat(9)}`, show: { type: 'card' } })) })
    const p = presentationOf()
    p.depths.deep = [long(1), long(2), long(3)]
    const log = []
    await addVoice(p, googleSettings(), { fetchImpl: fakeGoogle({ log, rate: 8000 }), encoder: 'wav' })
    // Each chapter is over half of what one request holds, so each is a part of its own.
    assert.equal(log.length, 1 + 3, 'the quick version, then the deep dive in three parts')
    assert.ok(log.slice(1).every((r) => r.input[0].content.length === 6))
    const marks = Object.values(p.audio.tracks.deep.marks)
    assert.equal(marks.length, 18)
    for (let k = 1; k < marks.length; k++) assert.equal(marks[k][0], marks[k - 1][1], 'in order with no holes')
    assert.ok(Math.abs(marks.at(-1)[1] - p.audio.tracks.deep.seconds) < 0.1)
  })
})

test('recordings: no key, the daily limit, or a cut-short answer leave a note and the computer\'s voices', async () => {
  const before = process.env.GOOGLE_VOICE_KEY
  delete process.env.GOOGLE_VOICE_KEY
  try {
    const p = presentationOf()
    let calls = 0
    const out = await addVoice(p, googleSettings(), { fetchImpl: async () => { calls++ }, encoder: 'wav' })
    assert.equal(calls, 0)
    assert.match(out.note, /no key \(GOOGLE_VOICE_KEY in private\.env\)/)
    assert.deepEqual(p.audio.tracks, {})
  } finally { if (before !== undefined) process.env.GOOGLE_VOICE_KEY = before }
  await withKey(async () => {
    const p = presentationOf()
    const out = await addVoice(p, googleSettings(), { fetchImpl: async () => answer(429, { error: { message: 'Quota exceeded: requests per day' } }), encoder: 'wav', pause: async () => {} })
    assert.match(out.note, /daily limit .* recorded next time it is opened/)
    assert.deepEqual(p.audio.tracks, {})
    const short = presentationOf()
    const cut = await addVoice(short, googleSettings(), { fetchImpl: async () => answer(200, audioBody(Buffer.alloc(3200), 16000)), encoder: 'wav' })
    assert.match(cut.note, /much shorter than the words/)
  })
})

test('recordings: the takes are the narration as spoken, quick first, then the deep dive, then answers', () => {
  const p = presentationOf()
  p.answers.push({ id: 'a1', question: 'Q?', chapter: { lines: [{ id: 'a1.1', who: 0, say: 'The API, yes.' }] } })
  const takes = takesOf(p, { API: 'A P I' })
  assert.deepEqual(takes.map((t) => t.key), ['quick', 'deep', 'a1'])
  assert.equal(takes[2].lines[0].spoken, 'The A P I, yes.')
  assert.equal(takes[1].chapters.length, 2)
})

test('recordings: shrunk with the Mac\'s converter when there is one', { skip: process.platform === 'darwin' && existsSync('/usr/bin/afconvert') ? false : 'only on a Mac' }, () => {
  const { samples } = speak(LINES.slice(0, 2), { rate: 24000 })
  const wav = writeWav(samples, 24000)
  const small = encodeTake(wav, 'afconvert')
  assert.equal(small.mime, 'audio/mp4')
  assert.ok(small.data.length < wav.length / 4, `${small.data.length} bytes from ${wav.length}`)
})

// ---- kept on disk and put in the page -------------------------------------------------------------------

test('kept: recordings sit in their own folder, not in presentation.json, and come back on reading', async () => {
  await withKey(async () => {
    const store = mkdtempSync(join(tmpdir(), 'etc-voice-'))
    const p = presentationOf()
    await addVoice(p, googleSettings(), { fetchImpl: fakeGoogle(), encoder: 'wav' })
    const dir = saveExplainer(store, { presentation: p, html: '<p>page</p>' })
    const json = readFileSync(join(dir, 'presentation.json'), 'utf8')
    assert.ok(!json.includes('data:audio'), 'no sound in presentation.json')
    assert.equal(readdirSync(join(dir, 'voice')).length, 2)
    const back = readExplainer(store, p.id)
    assert.equal(back.presentation.audio.tracks.deep.src, p.audio.tracks.deep.src)
    assert.deepEqual(back.presentation.audio.tracks.deep.marks, p.audio.tracks.deep.marks)
    assert.equal(listExplainers(store).length, 1)
    // A version recorded again (new voices) replaces its old file.
    const s2 = googleSettings()
    s2.voice.google_voices = ['Puck', 'Aoede']
    await addVoice(back.presentation, s2, { fetchImpl: fakeGoogle(), encoder: 'wav' })
    saveExplainer(store, { presentation: back.presentation })
    assert.equal(readdirSync(join(dir, 'voice')).length, 2, 'the old recordings are gone')
    // A recording whose file has gone is left out, so it is recorded again next time.
    const again = readExplainer(store, p.id)
    assert.deepEqual(Object.keys(again.presentation.audio.tracks).sort(), ['deep', 'quick'])
  })
})

test('page: the recording goes in only while the voice is Google\'s, and the policy lets it play', async () => {
  await withKey(async () => {
    const p = presentationOf()
    await addVoice(p, googleSettings(), { fetchImpl: fakeGoogle(), encoder: 'wav' })
    const data = (html) => JSON.parse(html.match(/<script type="application\/json" id="etc-data">([\s\S]*?)<\/script>/)[1])
    const page = data(renderHtml(p))
    assert.deepEqual(Object.keys(page.audio.tracks).sort(), ['deep', 'quick'])
    assert.deepEqual(page.audio.voices, ['Kore', 'Charon'])
    assert.match(renderHtml(p), /media-src data: blob:/)
    p.player = playerSettings(defaultSettings())
    assert.equal(data(renderHtml(p)).audio, undefined, 'the browser voice: no recording in the page')
    assert.equal(forPage({ id: 'x' }).audio, undefined)
  })
})

test('never-show: the recording is not searched (it is sound), the words still are', () => {
  const p = presentationOf()
  p.audio = { tracks: { quick: { src: 'data:audio/wav;base64,c2VjcmV0cHJvamVjdA==zebra', marks: {} } } }
  assert.doesNotThrow(() => refuseNeverShow(p, ['zebra']))
  p.depths.quick[0].lines[0].say = 'The zebra project.'
  assert.throws(() => refuseNeverShow(p, ['zebra']), /never-show/)
})

test('settings: say_it_like reaches the player, and the Google voices are named only for Google', () => {
  const s = googleSettings()
  s.say_it_like = { SQL: 'sequel' }
  assert.deepEqual(playerSettings(s).voice.say_it_like, { SQL: 'sequel' })
  assert.deepEqual(playerSettings(s).voice.google_voices, ['Kore', 'Charon'])
  assert.deepEqual(playerSettings(defaultSettings()).voice.google_voices, [])
})
