// The practice change's ready-made answers live with the sample, because the offline practice run
// (the try step's --offline) plays them too. The tests take them from here.
export * from '../../examples/parcel-pigeon/answers.mjs'
