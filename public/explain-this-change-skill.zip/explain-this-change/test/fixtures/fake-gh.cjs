#!/usr/bin/env node
// A stand-in for GitHub's gh command, for the tests: it answers the few calls the skill makes, keeps
// its comments in FAKE_GH_DIR/state.json, and writes every call to FAKE_GH_DIR/calls.jsonl.
// Nothing here reaches GitHub. The pull request it knows is FAKE_GH_DIR/pr.json.
const fs = require('node:fs')
const path = require('node:path')

const dir = process.env.FAKE_GH_DIR
const args = process.argv.slice(2)
const stdin = args.includes('--input') ? fs.readFileSync(0, 'utf8') : ''
fs.appendFileSync(path.join(dir, 'calls.jsonl'), `${JSON.stringify({ args, stdin })}\n`)
const statePath = path.join(dir, 'state.json')
const state = fs.existsSync(statePath) ? JSON.parse(fs.readFileSync(statePath, 'utf8')) : {}
state.comments = state.comments || []
state.next = state.next || 9001
const keep = () => fs.writeFileSync(statePath, JSON.stringify(state))
const out = (v) => { process.stdout.write(typeof v === 'string' ? v : JSON.stringify(v)); process.exit(0) }
const fail = (msg) => { process.stderr.write(`${msg}\n`); process.exit(1) }
const read = (name) => JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8'))

if (args[0] === '--version') out('gh version 2.99.0 (fake)\n')
if (args[0] === 'auth' && args[1] === 'status') { if (state.loggedOut) fail('You are not logged into any GitHub hosts.'); out('Logged in to github.com (fake)\n') }
if (args[0] === 'pr' && args[1] === 'view') { if (state.noPr) fail('no pull requests found'); out(read('pr.json')) }
if (args[0] === 'pr' && args[1] === 'checks') out(state.checks || [])
if (args[0] === 'issue' && args[1] === 'view') {
  const issue = (read('issues.json') || []).find((i) => String(i.number) === args[2])
  if (!issue) fail('not found')
  out(issue)
}
if (args[0] === 'api') {
  const rest = args.slice(1)
  const valued = new Set(['--method', '--jq', '--input', '--hostname'])
  const flag = (n) => { const i = rest.indexOf(n); return i >= 0 ? rest[i + 1] : null }
  const method = flag('--method') || 'GET'
  const endpoint = rest.find((a, i) => !a.startsWith('-') && !valued.has(rest[i - 1])) || ''
  let m
  if (endpoint === 'user') out(`${state.login || 'sample-reviewer'}\n`)
  if (method === 'GET' && (m = /^repos\/([^/]+\/[^/]+)\/issues\/(\d+)\/comments/.exec(endpoint))) {
    const mark = (/startswith\("([^"]+)"\)/.exec(flag('--jq') || '') || [])[1] || '\u0000'
    out(state.comments.filter((c) => c.repo === m[1] && c.issue === Number(m[2]) && c.body.startsWith(mark)).map((c) => `${c.id}\t${c.login}\t${c.url}\n`).join(''))
  }
  if (method === 'POST' && (m = /^repos\/([^/]+\/[^/]+)\/issues\/(\d+)\/comments$/.exec(endpoint))) {
    if (state.refuse) fail('gh: Resource not accessible by personal access token (HTTP 403)')
    const id = state.next++
    const c = { id, repo: m[1], issue: Number(m[2]), login: state.login || 'sample-reviewer', body: JSON.parse(stdin).body, url: `https://github.com/${m[1]}/pull/${m[2]}#issuecomment-${id}` }
    state.comments.push(c)
    keep()
    out({ id, html_url: c.url })
  }
  if (method === 'PATCH' && (m = /^repos\/([^/]+\/[^/]+)\/issues\/comments\/(\d+)$/.exec(endpoint))) {
    const c = state.comments.find((x) => x.id === Number(m[2]))
    if (!c) fail('gh: Not Found (HTTP 404)')
    c.body = JSON.parse(stdin).body
    keep()
    out({ id: c.id, html_url: c.url })
  }
}
fail(`fake gh: nothing for "${args.join(' ')}"`)
