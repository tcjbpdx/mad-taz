// Proof: every row says where it comes from, nothing passes unless something ran and passed, and
// running the tests never touches the folder you work in. Runs the practice project's own tests
// (node --test) and its sample command, before and after the change.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { chmodSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { delimiter, join } from 'node:path'
import { explain } from '../index.mjs'
import { gatherProof, isTestFile, summariseOutput } from '../scripts/lib/proof.mjs'
import { defaultSettings } from '../scripts/lib/settings.mjs'
import { codeWords } from '../scripts/lib/product.mjs'
import { applyScope, normaliseScope } from '../scripts/lib/scope.mjs'
import { openSource } from '../scripts/lib/source.mjs'
import { clone, wholeScript } from './fixtures/parcel-pigeon-scripts.mjs'
import { sampleRepo } from './helpers.mjs'

const opened = () => {
  const s = sampleRepo()
  const src = openSource({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { settings: defaultSettings() })
  return { s, src, scoped: applyScope(src.diff, normaliseScope({ kind: 'whole' })) }
}

/** The default settings with some proof settings changed (straight in, so a short timeout is allowed). */
function withProof(proof) {
  const settings = defaultSettings()
  settings.proof = { ...settings.proof, ...proof }
  return settings
}

const worktrees = (dir) => execFileSync('git', ['worktree', 'list', '--porcelain'], { cwd: dir, encoding: 'utf8' }).split('\n').filter((l) => l.startsWith('worktree ')).length

test('test files are told apart from code by their names and folders', () => {
  for (const yes of ['test/retry.test.js', 'src/__tests__/a.js', 'spec/model_spec.rb', 'pkg/x_test.go', 'tests/test_api.py', 'web/App.spec.tsx']) assert.ok(isTestFile(yes), yes)
  for (const no of ['src/retry.js', 'src/testing.js', 'latest/notes.md', 'src/contest.py']) assert.ok(!isTestFile(no), no)
})

test('command output is cut to its result lines, with colors, timings and keys taken out', () => {
  const out = '\x1b[32m✔ retries\x1b[0m (3.2ms)\nℹ tests 7\nℹ pass 7\nℹ fail 0\nℹ duration_ms 81.5\nANTHROPIC_API_KEY=sk-ant-api03-abcdefghijklmnopqrstuvwxyz0123456789\n'
  const s = summariseOutput(out)
  assert.equal(s, 'tests 7 · pass 7 · fail 0')
  assert.doesNotMatch(summariseOutput(out, 10), /sk-ant-api03-abcdef/)
  assert.equal(summariseOutput(''), '')
})

test('by default: the tests the change touches and the code whose tests did not change; nothing is said to pass', async () => {
  const { src, scoped } = opened()
  const p = await gatherProof({ src, scoped, settings: defaultSettings() })
  const tests = p.items.find((i) => i.kind === 'tests')
  assert.equal(tests.status, 'info')
  assert.match(tests.detail, /test\/retry\.test\.js \(new\)/)
  assert.match(tests.detail, /test\/trackingService\.test\.js/)
  const gaps = p.items.find((i) => i.kind === 'gaps')
  assert.match(gaps.detail, /src\/carrierClient\.js/, 'the carrier client changed and has no test of its own')
  assert.doesNotMatch(gaps.detail, /src\/retry\.js|src\/trackingService\.js/, 'these had their tests changed with them')
  const none = p.items.find((i) => i.kind === 'none')
  assert.equal(none.status, 'unknown')
  assert.match(none.detail, /run_tests is off/)
  assert.equal(p.passing, false)
  assert.match(p.text, /Nothing above shows the change passing/)
  assert.ok(p.items.every((i) => i.status !== 'pass'))
  // The chapter: one line per row, each pointing at its own row, speakers taking turns.
  assert.equal(p.chapter.kind, 'proof')
  assert.equal(p.chapter.lines.length, p.items.length)
  p.chapter.lines.forEach((l, i) => { assert.equal(l.show.item, i); assert.equal(l.who, i % 2) })
  assert.match(p.chapter.summary, /Nothing here shows the change passing/)
  assert.deepEqual(p.facts.items.map((i) => Object.keys(i)), p.items.map(() => ['label', 'status', 'detail']))
})

test('switched off: no rows of its own, still the honest "nothing ran" row', async () => {
  const { src, scoped } = opened()
  const p = await gatherProof({ src, scoped, settings: withProof({ find_tests: false, read_ci: false }) })
  assert.deepEqual(p.items.map((i) => i.kind), ['none'])
  assert.equal(p.passing, false)
})

test('a description given by hand has no checks to read, even with a number', async () => {
  const { src, scoped } = opened()
  assert.equal(src.pr.number, 42)
  assert.equal(src.prNumber, null)
  const p = await gatherProof({ src, scoped, settings: defaultSettings() })
  assert.ok(!p.items.some((i) => i.kind === 'ci'))
})

test('run_tests: runs the tests and the sample before and after, in throwaway copies, and the folder is untouched', async () => {
  const { s, src, scoped } = opened()
  const branchBefore = execFileSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd: s.dir, encoding: 'utf8' }).trim()
  const fileBefore = readFileSync(join(s.dir, 'src', 'carrierClient.js'), 'utf8')
  const stages = []
  const p = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: s.testCommand, sample_command: s.sampleCommand }), onProgress: (e) => stages.push(e.message) })

  const runs = p.items.filter((i) => i.side)
  assert.deepEqual(runs.map((i) => `${i.kind} ${i.side}`), ['tests before', 'sample before', 'tests after', 'sample after'])
  const [testsBefore, sampleBefore, testsAfter, sampleAfter] = runs
  assert.equal(testsBefore.status, 'pass', testsBefore.detail)
  assert.equal(testsAfter.status, 'pass', testsAfter.detail)
  assert.match(testsAfter.detail, /pass \d+ · fail 0/)
  assert.match(testsAfter.label, /after the change \(node --test\)/)
  // The sample's output is a note, not a pass: it shows what happened, before and after.
  assert.equal(sampleBefore.status, 'info')
  assert.match(sampleBefore.detail, /carrier calls: 1/)
  assert.match(sampleAfter.detail, /carrier calls: 3/)
  assert.ok(!p.items.some((i) => i.kind === 'none'))
  assert.equal(p.passing, true)
  assert.match(p.chapter.summary, /passed/)
  assert.doesNotMatch(p.text, /Nothing above shows/)
  assert.ok(stages.includes('Running the tests before the change'))

  assert.equal(worktrees(s.dir), 1, 'the throwaway copies are gone')
  assert.equal(execFileSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd: s.dir, encoding: 'utf8' }).trim(), branchBefore)
  assert.equal(readFileSync(join(s.dir, 'src', 'carrierClient.js'), 'utf8'), fileBefore)
  assert.equal(execFileSync('git', ['status', '--porcelain'], { cwd: s.dir, encoding: 'utf8' }).trim(), '')
})

test('run_tests: a failing command is a fail, and nothing passes', async () => {
  const { src, scoped } = opened()
  const p = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: 'node -e "console.log(\'tests 3 pass 2 fail 1\'); process.exit(1)"' }) })
  const after = p.items.find((i) => i.side === 'after')
  assert.equal(after.status, 'fail')
  assert.match(after.detail, /exit code 1: tests 3 pass 2 fail 1/)
  assert.equal(p.passing, false)
  assert.match(p.chapter.summary, /failed/)
})

test('run_tests: a run that finishes but ran no tests is no result, not a pass', async () => {
  const { src, scoped } = opened()
  for (const said of ['ℹ tests 0\\nℹ pass 0', 'Ran 0 tests in 0.000s', 'collected 0 items', 'No tests found, exiting with code 0']) {
    const p = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: `node -e "console.log('${said}')"` }) })
    const after = p.items.find((i) => i.side === 'after')
    assert.equal(after.status, 'unknown', said)
    assert.match(after.detail, /ran no tests/)
    assert.equal(p.passing, false)
  }
})

test('run_tests: the run gets none of the keys this skill knows by name', async () => {
  const { src, scoped } = opened()
  process.env.EXPLAIN_SERVER_TOKEN = 'a-test-token-not-a-real-one'
  try {
    const p = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: 'node -e "process.exit(process.env.EXPLAIN_SERVER_TOKEN ? 1 : 0)"' }) })
    assert.equal(p.items.find((i) => i.side === 'after').status, 'pass')
  } finally { delete process.env.EXPLAIN_SERVER_TOKEN }
})

test('run_tests: a command that runs too long is stopped and has no result', async () => {
  const { s, src, scoped } = opened()
  const started = Date.now()
  const p = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: 'node -e "setTimeout(() => {}, 60000)"', timeout_seconds: 1 }) })
  assert.ok(Date.now() - started < 20000, 'both sides were stopped')
  for (const r of p.items.filter((i) => i.side)) {
    assert.equal(r.status, 'unknown')
    assert.match(r.detail, /Stopped after 1 seconds/)
  }
  assert.equal(p.passing, false)
  assert.equal(worktrees(s.dir), 1)
})

test('run_tests: a saved diff has no code to run, and says so', async () => {
  const { src } = opened()
  const diffSrc = openSource({ kind: 'diff', text: src.diffText }, { settings: defaultSettings() })
  const scoped = applyScope(diffSrc.diff, normaliseScope({ kind: 'whole' }))
  const p = await gatherProof({ src: diffSrc, scoped, settings: withProof({ run_tests: true, test_command: 'node --test' }) })
  const row = p.items.find((i) => i.kind === 'tests' && i.side)
  assert.equal(row.status, 'unknown')
  assert.match(row.detail, /a saved diff has no code to run/)
  assert.match(p.items.find((i) => i.kind === 'gaps').detail, /not looked for/)
})

test('explain: the proof goes to Claude and into the deep version, before the review focus', async () => {
  const s = sampleRepo()
  const prompts = []
  const writer = async ({ prompt }) => { prompts.push(prompt); return clone(wholeScript()) }
  const r = await explain({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { kind: 'whole' }, { store: null, writer, settings: { project_name: 'Parcel Pigeon' } })
  assert.match(prompts[0], /test\/retry\.test\.js \(new\)/)
  assert.match(prompts[0], /Nothing above shows the change passing/)
  const deep = r.presentation.depths.deep
  const at = deep.findIndex((c) => c.kind === 'proof')
  assert.ok(at > 0)
  assert.equal(deep[at].id, 'd-proof')
  assert.ok(deep.slice(at + 1).some((c) => c.kind === 'focus'))
  assert.ok(!deep.slice(0, at).some((c) => c.kind === 'focus' || c.kind === 'reasoning'))
  assert.ok(!r.presentation.depths.quick.some((c) => c.kind === 'proof'), 'the quick version stays short')
  assert.equal(r.presentation.proof.items.length, deep[at].lines.length)
  // A host can hand in its own proof, or none at all.
  const none = await explain({ kind: 'git', repo: s.dir, base: s.base, head: s.head, prInfo: s.prInfo }, { kind: 'whole' }, { store: null, writer, proof: null, settings: { project_name: 'Parcel Pigeon' } })
  assert.equal(none.presentation.proof, null)
  assert.ok(!none.presentation.depths.deep.some((c) => c.kind === 'proof'))
})

// ---- product mode: the same proof, said in plain words -------------------------------------------

/** Every word the viewer sees or hears: the table's rows, the summary and the chapter's lines. */
const shownWords = (p) => [p.facts.summary, ...p.facts.items.flatMap((i) => [i.label, i.detail]), ...p.chapter.lines.map((l) => l.say)].filter(Boolean)

function assertPlain(p, extra = []) {
  for (const w of shownWords(p)) {
    assert.deepEqual(codeWords(w), [], `code words in: ${w}`)
    assert.doesNotMatch(w, /\/|→|run_tests|node --test|exit code|\bcommit\b|\bdiff\b/, w)
    for (const x of extra) assert.ok(!w.includes(x), `"${x}" in: ${w}`)
  }
}

test('plain (product mode): the table and the chapter say it without file names or settings; Claude still gets the exact rows', async () => {
  const { src, scoped } = opened()
  const exact = await gatherProof({ src, scoped, settings: defaultSettings() })
  const p = await gatherProof({ src, scoped, settings: defaultSettings(), plain: true })
  assertPlain(p)
  // What Claude is told, what counts as passing and the returned rows are the exact ones.
  assert.equal(p.text, exact.text)
  assert.match(p.text, /test\/retry\.test\.js \(new\)/)
  assert.equal(p.passing, false)
  assert.deepEqual(p.items, exact.items)
  assert.ok(p.items.every((i) => !('plain' in i) && !('totals' in i)), 'the plain words are not left on the exact rows')
  assert.deepEqual(p.facts.items.map((i) => `${i.label} · ${i.status}`), ['Automatic checks in this change · info', 'Changed parts without updated checks · info', 'Automatic checks run · unknown'])
  assert.equal(p.facts.items[0].detail, '1 new set and 1 updated set.')
  assert.match(p.facts.items[1].detail, /^\d+ changed parts? of the code (has|have) no automatic checks of (its|their) own that could be found/)
  assert.equal(p.facts.items[2].detail, 'None. No results were read either, so nothing here says the change works.')
  assert.equal(p.facts.summary, 'Nothing here shows the change working: no automatic checks were run and no results were read.')
  assert.equal(p.chapter.lines.length, p.facts.items.length)
  assert.equal(p.chapter.lines[0].say, 'Automatic checks in this change: 1 new set and 1 updated set.')
  // Code-review mode is unchanged by any of it.
  assert.match(exact.facts.items[0].detail, /test\/retry\.test\.js \(new\)/)
  assert.match(exact.facts.summary, /no tests were run/)
})

test('plain (product mode): real runs are said as automatic checks and a trial run, with no command and no output', async () => {
  const { s, src, scoped } = opened()
  const p = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: s.testCommand, sample_command: s.sampleCommand }), plain: true })
  assertPlain(p, ['carrier calls'])
  assert.deepEqual(p.facts.items.slice(-4).map((i) => `${i.label} · ${i.status} · ${i.detail}`), [
    'The automatic checks before the change · pass · Finished with no failures.',
    'A trial run before the change · info · It ran.',
    'The automatic checks after the change · pass · Finished with no failures.',
    'A trial run after the change · info · It ran.',
  ])
  assert.equal(p.passing, true)
  assert.equal(p.facts.summary, 'The automatic checks passed. Each row says where that comes from.')
  assert.ok(p.chapter.lines.some((l) => l.say === 'The automatic checks after the change: passed. Finished with no failures.'))
  // Claude is still told the command and what it printed.
  assert.match(p.text, /node --test/)
  assert.match(p.text, /carrier calls: 3/)

  const failing = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: 'node -e "process.exit(1)"' }), plain: true })
  assertPlain(failing)
  assert.equal(failing.facts.summary, 'Some automatic checks failed. Each row says which.')
  assert.equal(failing.facts.items.find((i) => i.label === 'The automatic checks after the change').detail, 'Finished with a failure or an error.')
  assert.equal(failing.passing, false)
  const slow = await gatherProof({ src, scoped, settings: withProof({ run_tests: true, test_command: 'node -e "setTimeout(() => {}, 60000)"', timeout_seconds: 1 }), plain: true })
  assertPlain(slow)
  assert.equal(slow.facts.summary, 'Nothing here shows the change working.', 'a run that was stopped is not "nothing was run"')
})

test('plain (product mode): GitHub\'s checks become one row of totals; code-review mode keeps one row per check', async () => {
  // A stand-in for the GitHub command that reports 8 checks: 5 passed, 2 failed, 1 still running.
  const bin = mkdtempSync(join(tmpdir(), 'etc-fake-gh-'))
  const checks = [
    ...['unit', 'lint', 'types', 'build', 'e2e'].map((name) => ({ name, workflow: 'ci', bucket: 'pass' })),
    { name: 'deploy-preview', workflow: 'preview', bucket: 'fail' },
    { name: 'bundle-size', workflow: 'ci', bucket: 'cancel' },
    { name: 'audit', workflow: 'security', bucket: 'pending' },
  ]
  writeFileSync(join(bin, 'gh'), `#!/usr/bin/env node
const a = process.argv.slice(2)
if (a[0] === '--version') { console.log('gh version 0.0.0 (stand-in)'); process.exit(0) }
if (a[0] === 'auth') process.exit(0)
if (a[0] === 'pr' && a[1] === 'checks') { console.log(${JSON.stringify(JSON.stringify(checks))}); process.exit(0) }
process.exit(1)
`)
  chmodSync(join(bin, 'gh'), 0o755)
  const was = process.env.PATH
  process.env.PATH = `${bin}${delimiter}${was}`
  try {
    const { src, scoped } = opened()
    src.prNumber = 7
    const exact = await gatherProof({ src, scoped, settings: defaultSettings() })
    const p = await gatherProof({ src, scoped, settings: defaultSettings(), plain: true })
    const ciRows = exact.facts.items.filter((i) => /^Check: |more checks$/.test(i.label))
    assert.equal(ciRows.length, 7, 'six checks shown and one "2 more checks" row')
    assert.match(ciRows[0].label, /^Check: (preview · deploy-preview|ci · bundle-size)$/, 'failures first')
    const gh = p.facts.items.filter((i) => /GitHub/.test(i.label))
    assert.deepEqual(gh, [{ label: 'Automatic checks on GitHub', status: 'fail', detail: '5 of 8 passed, 2 failed, 1 not finished or skipped.' }])
    assertPlain(p, ['deploy-preview', 'bundle-size', 'preview ·'])
    assert.equal(p.facts.summary, 'Some automatic checks failed. Each row says which.')
    assert.equal(p.passing, false)
    assert.match(p.text, /deploy-preview/, 'Claude is told which check failed')
    assert.ok(!p.facts.items.some((i) => i.label === 'Automatic checks run'), 'results were read, so there is no "nothing ran" row')
  } finally {
    process.env.PATH = was
  }
})
