---
name: explain-this-change
description: Use when someone wants a code change explained — a pull request, a branch, staged work, one file, a few lines or one hunk, optionally with a question ("why does this retry?", "is this safe?"). Makes a short narrated two-voice walkthrough in one self-contained page, with the code lit up line by line as it is talked about, a proof section that never claims tests pass without evidence, and a review focus. Also adds an "Explain this" button to a review app, answers follow-up questions, and (when switched on) makes a plain-English recap with pictures of the app for people who don't read code.
---

# Explain This Change

You are explaining a code change as a short narrated walkthrough. The person may be a senior
engineer or may not read code at all: match how they talk. Ask questions with pop-up choices
(the AskUserQuestion tool) wherever you can.

Every step is one command, run from the project's top folder:

```
node .claude/skills/explain-this-change/scripts/explain.mjs <step>
```

Below, `explain <step>` means that command. Each step prints what happened and ends with an
exit code: **0** done · **1** something broke, or the request was wrong, such as an option the
step doesn't have (the message says what, and nothing was done) · **2** it needs the person (a
setting, a key, a sign-in) · **3** a check failed (the explanation was refused; the message
lists why). Read the whole message before deciding what to do.

## The rules that matter most

1. **Never open, read, print or search `explain-this-change/private.env`.** It holds keys and a
   test account, one per line: `ANTHROPIC_API_KEY`, `GOOGLE_VOICE_KEY` (a `GEMINI_API_KEY`
   line is read the same way), `EXPLAIN_SERVER_TOKEN`, `APP_TEST_EMAIL`, `APP_TEST_PASSWORD`
   and `NEVER_SHOW`. Most people need none of them. Don't
   `cat` it, `grep` it or echo environment variables: the doctor step checks it without showing
   it. When they need to fill a line in, open the file for them (`open -e
   explain-this-change/private.env` on a Mac; otherwise tell them its location) and wait for
   them to say it is saved. If they paste a key into the chat anyway, don't repeat it back: pipe
   it into `explain set-private`, which writes that one line without showing it, then suggest
   they replace the key later because it has been in a chat.

   ```
   node .claude/skills/explain-this-change/scripts/explain.mjs set-private GOOGLE_VOICE_KEY <<'VALUE'
   (the pasted value, exactly as they sent it)
   VALUE
   ```
2. **The code goes only to the writer they chose.** By default that is their own Claude Code
   sign-in, run from an empty folder with no tools, MCP servers or skills (their own account,
   gateway and personal setup still apply, on purpose). Don't paste the
   code, the diff or the explanation anywhere else, and don't switch on a setting that sends
   something further (the Google voice, posting to the pull request, reading session notes)
   unless they ask for it.
3. **Never write or edit an explanation by hand.** Every line in it is checked against the
   change: the code it lights up must be in the change, a reason ("why") must come from a commit
   message, the pull request or an issue, or say exactly "Intent not stated.", and nothing may
   say tests pass unless the proof shows them passing. If a check fails (exit 3), don't work
   around it: say what was refused and offer to try again (`--fresh`) or to explain a smaller
   part. Never tell them tests pass, or that the change works, unless the proof section shows it.
4. **Nothing is posted anywhere unless they ask.** Saving to the pull request is off until
   `save_to_pr → enabled` is yes, and even then only `explain save <id>` (or the page's save
   button) posts. Ask before running it. The comment never holds the code or Claude's reasoning.
5. **Running their tests runs their code.** `proof → run_tests` is off by default. Only suggest
   turning it on for code they trust, never for a pull request from someone they don't know.
6. Kept explanations, the cache and the history live in `explain-this-change/output/`, which
   is kept out of git. Never commit it, and never delete an explanation unless they ask. (The
   try step's practice project and its explanations live in the computer's temporary folder
   instead; its code is made up.)

## First time in a project

1. **Setup.** If `.claude/skills/explain-this-change/node_modules` is missing, run `explain
   setup`. It installs a few small helpers into this copy of the skill (under a minute, once
   per copy). Only if
   they want product mode (pictures of the app), add `--browser`: it also downloads a hidden
   browser, about 150 MB, once per computer. If Node is missing or older than 20, tell them to
   install it from nodejs.org, then start Claude Code fresh.
2. **Start the folder.** If there is no `explain-this-change/` folder, run `explain new`. It
   makes `settings.yaml` and `private.env`, and adds `private.env`, the `output/` folder and the
   skill's installed helpers to `.gitignore`. It never overwrites a file.
3. **Settings.** Every line is optional and the defaults work. Fill in `project_name` from the
   project yourself. Only ask about what they care about, in one pop-up round, such as:
   - The voice: the computer's own voices (free, nothing leaves the computer, recommended to
     start), Google's voices (more natural; needs their own Google AI Studio key in
     `GOOGLE_VOICE_KEY`; the spoken words are sent to Google), or text only.
   - Proof: whether to run their tests before and after the change (`run_tests`, with
     `test_command`), only for code they trust.
   - Whether to keep a searchable history and offer to post to the pull request (`save_to_pr`).
   Words that must never be shown or spoken (a customer's name, an internal code name) go under
   `never_show`. Personal ones go on the private file's `NEVER_SHOW` line instead.
4. **Run `explain doctor`.** It checks everything in order and stops at the first thing to fix,
   with the fix spelled out. Fix it (or walk them through it) and run it again until it says
   everything is ready. Notes (no GitHub sign-in, say) are not stops.

If they just want to see it first, `explain try --offline` opens a practice review page for a
made-up project, Parcel Pigeon, with ready-made answers: nothing is sent to Claude. Without
`--offline` it uses their Claude sign-in. Run it in the background and stop it when done.

## Explaining a change

Turn what they asked for into flags on `explain explain`:

| They said | Which change | Which part |
|---|---|---|
| "this branch", "what I just did" | (nothing): this branch against the main branch | (nothing): all of it |
| "my uncommitted changes" | `--worktree` (or `--staged`): against the last commit | |
| "everything since main, committed or not" | `--worktree --base main` | |
| "pull request 42" | `--pr 42` (needs `gh` signed in) | |
| "main against feature-x" | `--base main --head feature-x` | |
| "this diff file" | `--diff path/to/file.diff` | |
| "the retry file" | | `--file src/retry.js` |
| "lines 10 to 20" | | `--lines src/retry.js:10-20` |
| "the part around line 34" | | `--hunk src/retry.js:34` |

New files git isn't tracking yet are left out of `--worktree` (so a stray secrets file can't
slip in); the message names them. If they want one included, ask first, then run `git add
--intent-to-add <file>` and explain again.

An option a step doesn't have stops it with exit 1 and nothing done; read the suggestion in the
message and run it again with the right one.

Add `--question "…"` when they asked something: the walkthrough answers it first, then explains.
`--description pr.md` gives the pull request's title and description when GitHub isn't used.
`--session file.jsonl` reads Claude Code's notes of the session that wrote the change, for why
it was built that way; only the stretch about the change goes to the writer, and every reason
taken from it is quoted word for word and labelled with where it came from.

It takes about a minute (the same change, part and question again costs nothing; `--fresh`
writes it anew). Then it opens the page in their browser and prints `Kept as <id>`. Tell them,
in two or three sentences, what it covers and what the review focus is. Don't paste the
narration back at them; the page has a text-only view (press T) for reading.

The page: play/pause (Space), line by line (← →), chapters ([ ]), QUICK about 30 seconds (Q)
or DEEP DIVE (D), ask a question (A), text only (T), all keys (?). To ask questions while it
plays, the page must be opened through the helper: run `explain serve` in the background and
open the address it prints followed by `/x/<id>`. Without it, use `explain ask <id> --question
"…"`, which adds the answer to the same page as a new chapter.

## Other steps

- `explain ask <id> --question "…"` (`--chapter d2` to ask about one chapter: QUICK's are
  `q1`, `q2`…, DEEP DIVE's `d1`, `d2`…, answers `a1`…; `--depth quick` or `deep`). An unknown
  chapter is refused with the list of real ones.
- `explain save <id>`: into the searchable history, and as one pull request comment when
  `save_to_pr → post_comment` is on. Ask first. Saving again updates that comment.
- `explain history` (`--search "retry #42"`): the explanations for this project, newest first.
- `explain serve`: the helper the page's question box and the review-app button talk to, on
  this computer only. Run it in the background; stop it when done.
- `explain selftest`: proves every safeguard can refuse a bad explanation (offline, a few
  seconds). Run it if a check ever seems wrong.

## The button in a review app

If they are building a review app and want an "Explain this" button, show them
`.claude/skills/explain-this-change/examples/button/` and "The button, in any review app" in the README beside this file: one
script tag from the helper, then `<explain-change file="…" line="…" ask>` wherever a button
should go. Their app's address must be listed under `server → allow_origins`. Don't change
`server → host` from 127.0.0.1 unless they understand that the helper then needs a token.

## Product mode (plain English, pictures of the app)

For someone who doesn't read code: no code on screen, pictures of their app instead, and no
code words in the narration. It is off until they switch it on. In settings, set `product →
enabled` to yes and `app_url` to the address their app opens at; `pages` lists pages worth a
picture; `audience` says who it is for. Sign-in: `none`, `form` (a **test** account with tidy,
made-up data in private.env, since anything in it can appear in a picture), or `by-hand` (a
browser window opens on the first recap; they sign in there within five minutes, and the
sign-in is kept on this computer and asked for again only when it runs out). It
needs `explain setup --browser` once. Start their app if it isn't running, then add `--product`
to `explain explain`. The pictures stay on this computer and never go into a pull request
comment.

## Coming back to it

Don't start over. `explain history` lists what was already made; `explain doctor` says what is
missing. A kept explanation opens again from its folder in `explain-this-change/output/explainers/`.

## The feedback form

When they ask for help with the feedback form, read `FEEDBACK.md` beside this file. Ask its
questions a few at a time in plain chat, and save their answers in their own words as
`explain-this-change/feedback.md` (never inside the skill folder). Leave out any email address,
key or code. Tell them the file's name and that it's the one to send back.

## When something goes wrong

| What it says | What to do |
|---|---|
| Helpers not installed | `explain setup` |
| The hidden browser is not downloaded | `explain setup --browser` (only for product mode) |
| Claude Code is not installed (from doctor) | They install Claude Code, run `claude` once and sign in, or set `writer → service: anthropic-api` and put a key in private.env |
| Claude Code is not signed in (on the first explanation; doctor can't see this) | They run `claude` once and sign in, then try again |
| Claude took more than 10 minutes | Explain a smaller part, or lower `writer → effort` |
| This change is too big to explain in one go | Explain one file (`--file`) or a range of lines (`--lines`) |
| There is nothing to explain | The branch matches its base, or (with `--worktree` / `--staged`) nothing changed since the last commit. Try the branch itself, `--worktree --base main`, or name `--base`. If it lists new files left out, see `git add --intent-to-add` above |
| … is not an option of the … step | A typo or the wrong step: use the option it suggests |
| … is not one of the files this change touches | The message lists the files it does touch; pick one of those |
| Line … is not inside a changed part / There is no hunk … / Lines … did not change and sit outside every changed part | Pick lines inside a changed part, or explain the whole file with `--file` |
| There is no chapter … | Use one of the chapter ids the message lists |
| I could not tell which branch this change is measured against | Add `--base main` (or set `source → base`) |
| GitHub is not signed in | `gh auth login`, or explain the branch instead of `--pr` |
| The fact-check refused it (exit 3) | Read the listed problems out in plain words. Try `--fresh`, or a smaller part. Never edit around it |
| The never-show list refused it | A listed word is in the code or narration. Explain a part without it, or check the list |
| The Google voice refused / ran out | The message says why; the page falls back to the computer's own voices. Missing recordings are made next time |
| Product mode: the app is not answering | Start their app; check `app_url` (the port especially) |
| Signing in to take the pictures did not work | Check the test account and the words under `product → sign_in` (the two boxes, the button, `done_when_you_see`) |
| Signing in by hand did not finish | Run it again and sign in within five minutes |
| The helper is busy | One explanation is written at a time; wait a minute |

Anything still unclear: show them the exact message, explain it in a sentence, and suggest the
fix.
