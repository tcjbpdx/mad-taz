// Explain This Change: the engine, for a host app and for the command line alike.
//
//   import { explain, ask } from 'explain-this-change'
//
//   const result = await explain(
//     { kind: 'git', repo: '.', base: 'main' },                    // or { kind: 'github', number: 42 }, { kind: 'diff', text }
//     { kind: 'hunk', id: 'h2', question: 'Is it safe to retry?' }, // or whole, file, lines
//     { project: '.', onProgress: (e) => console.log(e.message) },
//   )
//   result.html          // one self-contained page: the player, the code and the narration
//   result.presentation  // the same thing as data (format explain-this-change/1)
//
//   const { answer } = await ask(result, { question: 'What if the carrier is down for good?', chapter: 'd2' })
//
// explain() reads the change, gathers the code around it, has Claude write a two-voice script,
// checks every line against the change (one round of fixes, then it refuses), and builds the
// presentation and its player page. With a project (or a store folder) the result is kept, so the
// same change, scope and question costs nothing the second time.
//
// Where things go: the code in scope is sent only to the writer you chose (your own Claude Code
// sign-in by default, or the Anthropic API with your key). Nothing else leaves the computer unless
// a setting you switched on says so: see the README's "What goes where".

import { join, resolve } from 'node:path'
import { addAnswer, askContextOf, cleanQuestion, filesFor, keptAnswer, placeOf, writeAnswer } from './scripts/lib/answer.mjs'
import { cacheKey } from './scripts/lib/cache.mjs'
import { buildContext } from './scripts/lib/context.mjs'
import { buildPresentation, playerSettings, refuseNeverShow } from './scripts/lib/present.mjs'
import { takePictures, productPreflight } from './scripts/lib/pictures.mjs'
import { allowedPages } from './scripts/lib/product.mjs'
import { NeedsYou, Problem, pathsFor } from './scripts/lib/project.mjs'
import { gatherProof } from './scripts/lib/proof.mjs'
import { mergeHistory, readHistory, recordHistory, searchHistory } from './scripts/lib/history.mjs'
import { gatherReasoning } from './scripts/lib/reasoning.mjs'
import { renderHtml } from './scripts/lib/render.mjs'
import { saveExplanation, saveLabelFor } from './scripts/lib/save.mjs'
import { applyScope, normaliseScope } from './scripts/lib/scope.mjs'
import { promptParts, writeScript } from './scripts/lib/script.mjs'
import { loadPrivateEnv, neverShowWords } from './scripts/lib/secrets.mjs'
import { MODES, defaultSettings, loadSettings, settingsFromObject, writerFingerprint } from './scripts/lib/settings.mjs'
import { openSource } from './scripts/lib/source.mjs'
import { checkId, listExplainers, readExplainer, saveExplainer } from './scripts/lib/store.mjs'
import { addVoice } from './scripts/lib/voice.mjs'

export { CheckFailed, ENGINE_VERSION, FORMAT, NeedsYou, Problem } from './scripts/lib/project.mjs'
export { defaultSettings, parseSettings, settingsFromObject } from './scripts/lib/settings.mjs'
export { scopeFromFlags } from './scripts/lib/scope.mjs'
export { renderHtml } from './scripts/lib/render.mjs'
export { listExplainers, readExplainer } from './scripts/lib/store.mjs'
export { commentBody } from './scripts/lib/save.mjs'

/** The settings, paths, store and never-show words one call works with. */
async function prepare(options = {}) {
  const project = options.project ? resolve(String(options.project)) : null
  let settings
  if (options.settings) settings = settingsFromObject(options.settings)
  else if (project) settings = await loadSettings(pathsFor(project))
  else settings = defaultSettings()
  // options.mode picks the mode for this one call (the CLI's --product), over settings → mode.
  if (options.mode != null && options.mode !== settings.mode) {
    if (!MODES.includes(options.mode)) throw new Problem(`mode must be one of: ${MODES.join(', ')}.`)
    if (options.mode === 'product' && !settings.product.enabled) {
      throw new NeedsYou("Product mode is off. Switch it on in settings.yaml: under product, set enabled to yes and app_url to the address your app opens at (such as http://localhost:3000).")
    }
    settings = { ...settings, mode: options.mode }
  }
  const paths = project ? pathsFor(project, settings) : null
  if (paths) loadPrivateEnv(paths.privateEnv)
  const store = options.store !== undefined ? (options.store ? resolve(String(options.store)) : null) : paths ? paths.explainers : null
  const neverShow = [...neverShowWords(settings), ...(options.neverShow || [])]
  return { settings, paths, store, neverShow, cwd: options.cwd || project || process.cwd() }
}

/** Keeps the history's record up to date, while save_to_pr → enabled is yes (and there is a project). */
function noteInHistory(prep, presentation) {
  if (prep.paths && prep.settings.save_to_pr.enabled) recordHistory(prep.paths.history, presentation)
}

const isOpenedSource = (s) => Boolean(s && s.diff && Array.isArray(s.diff.hunks) && typeof s.readFile === 'function')

/**
 * Records what the Google voice is missing, when voice → service is google (and options.voice is not
 * false). Never fails the explanation: a problem leaves a note and the computer's own voices.
 */
async function voiceFor(presentation, settings, options, onProgress, only = null) {
  if (settings.voice.service !== 'google' || options.voice === false) return null
  return addVoice(presentation, settings, { onProgress, only, fetchImpl: options.voiceFetch, encoder: options.voiceEncoder, pause: options.voicePause })
}

/** An answer's recording, as the player takes it (null without one). */
function answerTrack(presentation, settings, id) {
  const t = settings.voice.service === 'google' && presentation.audio && presentation.audio.tracks ? presentation.audio.tracks[id] : null
  return t && t.src ? { marks: t.marks, src: t.src, seconds: t.seconds } : null
}

/**
 * What makes a kept explanation the same as a new one would be, besides the change itself: the
 * settings that shape the writing, and who writes it. A host's own writer gets its own keys, so a
 * practice or custom writer's text is never served as Claude's (or the other way round). A writer
 * can name itself with a cacheKey property; otherwise its function name is used.
 */
function fingerprintFor(settings, writer) {
  const base = writerFingerprint(settings)
  if (!writer) return base
  return { ...base, host_writer: String(writer.cacheKey || writer.name || 'custom') }
}

/**
 * Explains a change. source: a source spec ({ kind: 'git' | 'github' | 'diff', … }) or a source
 * already opened. scope: { kind: 'whole' } (the default), { kind: 'file', file },
 * { kind: 'lines', file, from, to, side? } or { kind: 'hunk', id } / { kind: 'hunk', file, line },
 * each with an optional question.
 *
 * options: project (folder with explain-this-change/settings.yaml), settings (an object, instead of
 * the file), store (folder to keep explainers in; null keeps nothing), writer (a host function
 * that writes instead of Claude Code or the API), onProgress, askEndpoint / saveEndpoint / token
 * (for the page), proof, reasoningSources, neverShow (extra words), cache (false writes afresh),
 * voice (false skips recording the Google voice, when settings ask for it), mode ('product' or
 * 'code-review', over settings → mode), capture (a host function that takes the pictures in product
 * mode instead of the hidden browser: given { pictures, points, settings, … }, it resolves
 * { pictures, warnings }), handSignIn (for tests of signing in by hand).
 *
 * Product mode (settings → mode, or options.mode) is the plain-English recap: no code on screen,
 * pictures of the app instead, taken after the script passes its check. It is off until
 * product → enabled is yes.
 *
 * Returns { id, presentation, html, dir, path, cached, warnings, usage, askContext, voice }: voice
 * is what the Google voice did ({ recorded, kept, note }), or null when it was not asked for.
 */
export async function explain(source, scope = { kind: 'whole' }, options = {}) {
  const onProgress = options.onProgress || (() => {})
  const prep = await prepare(options)
  const { settings, paths, store, neverShow, cwd } = prep
  if (!source) throw new Problem('Say which change to explain: a git branch, a pull request or a diff.')
  const src = isOpenedSource(source) ? source : openSource(source, { cwd, settings, onProgress })
  const scoped = applyScope(src.diff, normaliseScope(scope || { kind: 'whole' }))
  onProgress({ stage: 'context', message: 'Gathering the code around the change' })
  const context = buildContext(src, scoped)
  // Proof: what is known about tests and checks, gathered before the prompt so Claude is told only
  // that (and the cache key changes when a result does). A host can pass its own, or null for none.
  const proof = options.proof !== undefined ? options.proof : await gatherProof({ src, scoped, settings, plain: settings.mode === 'product', onProgress })
  // Claude's reasoning: only from a session file (read_sessions, or one named for this explanation)
  // or the plan notes listed in settings. What was looked for and not found is said, not filled in.
  let reasoningSources = options.reasoningSources
  if (reasoningSources === undefined) {
    const found = await gatherReasoning({ src, settings, project: paths ? paths.project : null, onProgress })
    for (const note of found.notes) onProgress({ stage: 'reasoning', message: note })
    reasoningSources = found.sources
  }
  const parts = promptParts({ src, scoped, settings, context, proof, reasoningSources })
  const id = cacheKey({ ...parts, fingerprint: fingerprintFor(settings, options.writer) }).slice(0, 16)
  // What the person should know about what was read (untracked files left out, say), every time.
  const sourceNotes = src.notes || []
  const page = (p) => renderHtml(p, {
    askEndpoint: options.askEndpoint || '', saveEndpoint: options.saveEndpoint || '', saveLabel: options.saveEndpoint ? saveLabelFor(p, settings) : '', token: options.token || '',
  })

  if (store && options.cache !== false) {
    const kept = readExplainer(store, id)
    if (kept && kept.askContext) {
      onProgress({ stage: 'cache', message: 'Already explained: using the copy kept from last time' })
      const presentation = kept.presentation
      presentation.player = playerSettings(settings) // the look and voice follow today's settings
      refuseNeverShow(presentation, neverShow) // and so does the never-show list
      const voice = await voiceFor(presentation, settings, options, onProgress) // a recording missed last time is made now
      saveExplainer(store, { presentation, html: renderHtml(presentation) })
      noteInHistory(prep, presentation)
      return { id, presentation, html: page(presentation), dir: kept.dir, path: kept.path, cached: true, warnings: [...sourceNotes, ...(presentation.warnings || [])], usage: { usd: 0, model: '', requests: 0 }, askContext: kept.askContext, voice }
    }
  }

  const product = settings.mode === 'product'
  // Before paying for a script, make sure the pictures can be taken: the app answers, the browser
  // is there, and the test account is in private.env when the app signs in with a form.
  if (product && !options.capture) await productPreflight(settings)
  const pages = product ? allowedPages(settings, scoped, context) : []
  const { script, warnings, usage } = await writeScript({ src, scoped, settings, writer: options.writer, proof, reasoningSources, neverShow, onProgress, context, pages })
  const pictures = product ? await picturesFor(script, { settings, paths, neverShow, onProgress, options, warnings }) : null
  onProgress({ stage: 'build', message: 'Building the player' })
  const presentation = buildPresentation({ src, scoped, settings, script, warnings, usage, proof, reasoningSources, id, neverShow, pictures })
  const askContext = askContextOf({ src, scoped, context, parts, proof })
  const voice = await voiceFor(presentation, settings, options, onProgress)
  let dir = null
  let path = null
  if (store) {
    dir = saveExplainer(store, { presentation, askContext, html: renderHtml(presentation) })
    path = resolve(dir, 'explain.html')
  }
  noteInHistory(prep, presentation)
  onProgress({ stage: 'done', message: 'Ready' })
  return { id, presentation, html: page(presentation), dir, path, cached: false, warnings: [...sourceNotes, ...warnings], usage: presentation.usage, askContext, voice }
}

/**
 * Product mode: takes the pictures the script asked for, looking on each for the words its lines
 * point at (so the player can circle them). Adds a warning for each picture not taken.
 */
async function picturesFor(script, { settings, paths, neverShow, onProgress, options, warnings }) {
  const points = script.pictures.map(() => new Set())
  for (const depth of ['quick', 'deep']) {
    for (const c of script[depth] || []) {
      for (const l of c.lines) if (l.show.type === 'picture' && l.show.point_at && points[l.show.item]) points[l.show.item].add(l.show.point_at)
    }
  }
  const capture = options.capture || takePictures
  const taken = await capture({
    pictures: script.pictures, points: points.map((s) => [...s]), settings, neverShow, onProgress,
    stateFile: paths ? join(paths.product, 'signed-in.json') : null, handSignIn: options.handSignIn || null,
  })
  const got = (taken && taken.pictures) || []
  for (const w of (taken && taken.warnings) || []) warnings.push(w)
  const missing = script.pictures.filter((_, i) => !got[i]).length
  if (missing && missing === script.pictures.length) warnings.push('No pictures of the app could be taken, so every line shows its card instead.')
  return script.pictures.map((_, i) => got[i] || null)
}

/**
 * Answers a question asked while an explainer plays, and adds the answer to it as a chapter.
 * explainer: an id (with a project or store holding it) or { presentation, askContext } (such as
 * what explain() returned). request: { question, chapter, line, depth }, as the player sends it.
 *
 * Returns { answer, files, hunks, cached, warnings, usage, presentation, audio }: the first three
 * and audio (the answer's recording, when the voice is Google's) are what the player takes;
 * presentation is the explainer with the answer added.
 */
export async function ask(explainer, request = {}, options = {}) {
  const onProgress = options.onProgress || (() => {})
  const prep = await prepare(options)
  const { settings, store, neverShow } = prep
  const question = cleanQuestion(request.question)
  let kept
  if (typeof explainer === 'string') {
    checkId(explainer)
    if (!store) throw new Problem('To answer by id, say which project (or store folder) holds the explainer.')
    kept = readExplainer(store, explainer)
    if (!kept) throw new Problem(`There is no explainer "${explainer}" here. It may have been made in another project, or its output folder was cleared. Explain the change again.`)
  } else if (explainer && explainer.presentation) {
    kept = { presentation: explainer.presentation, askContext: explainer.askContext || null }
  } else {
    throw new Problem('Say which explainer the question is about.')
  }
  if (!kept.askContext) {
    throw new NeedsYou('This explainer was made without what questions need (it was not kept by this version). Explain the change again, then ask.')
  }

  const presentation = structuredClone(kept.presentation) // nothing changes unless the answer passes
  const place = placeOf(presentation, request)
  if (typeof request.chapter === 'string' && request.chapter) {
    // A chapter id the explainer does not have would quietly become a general question; say so instead.
    const chapters = [...((presentation.depths && presentation.depths[place.depth]) || []), ...(presentation.answers || []).map((a) => ({ id: a.id, title: a.chapter && a.chapter.title }))]
    if (!chapters.some((c) => c.id === request.chapter)) {
      const which = place.depth === 'quick' ? 'QUICK' : 'DEEP DIVE'
      const list = chapters.map((c) => `${c.id} (${String(c.title || '').slice(0, 40)})`).join(', ')
      throw new Problem(`There is no chapter "${String(request.chapter).slice(0, 40)}" in the ${which} version of this explanation. Its chapters are: ${list || 'none'}.`)
    }
  }
  const same = keptAnswer(presentation, question, place)
  if (same) {
    onProgress({ stage: 'cache', message: 'Already answered: playing that answer again' })
    if (!answerTrack(presentation, settings, same.id)) {
      const voice = await voiceFor(presentation, settings, options, onProgress, [same.id])
      if (voice && voice.recorded.length && store && typeof explainer === 'string') saveExplainer(store, { presentation, html: renderHtml(presentation) })
    }
    return { answer: same, files: filesFor(presentation, same), hunks: [], audio: answerTrack(presentation, settings, same.id), cached: true, warnings: [], usage: { usd: 0, model: '', requests: 0 }, presentation }
  }

  const { data, warnings, usage } = await writeAnswer({ askContext: kept.askContext, presentation, question, place, settings, writer: options.writer, neverShow, onProgress })
  const added = addAnswer(presentation, kept.askContext, { data, question, place, neverShow })
  await voiceFor(presentation, settings, options, onProgress, [added.answer.id])
  if (store && typeof explainer === 'string') saveExplainer(store, { presentation, html: renderHtml(presentation) })
  noteInHistory(prep, presentation)
  onProgress({ stage: 'done', message: 'Answered' })
  return {
    ...added,
    audio: answerTrack(presentation, settings, added.answer.id),
    cached: false,
    warnings,
    usage: {
      usd: usage.every((u) => typeof u.usd === 'number') ? Number(usage.reduce((n, u) => n + u.usd, 0).toFixed(4)) : null,
      model: [...new Set(usage.map((u) => u.model).filter(Boolean))].join(', '),
      requests: usage.length,
    },
    presentation,
  }
}

/**
 * Saves an explainer (an id, with the project holding it, or { presentation }): into the searchable
 * history, and as a comment on its pull request when save_to_pr → post_comment is on and GitHub
 * knows the pull request. Off until save_to_pr → enabled is yes.
 * Returns { label, message, url, posted }.
 */
export async function save(explainer, options = {}) {
  const { settings, paths, store } = await prepare(options)
  let presentation
  if (typeof explainer === 'string') {
    checkId(explainer)
    const kept = store ? readExplainer(store, explainer) : null
    if (!kept) throw new Problem(`There is no explainer "${explainer}" here to save. Explain the change again, then save it.`)
    presentation = kept.presentation
  } else if (explainer && explainer.presentation) {
    presentation = explainer.presentation
  } else {
    throw new Problem('Say which explainer to save.')
  }
  return saveExplanation(presentation, { settings, historyFile: paths ? paths.history : null, cwd: paths ? paths.project : process.cwd(), onProgress: options.onProgress })
}

/**
 * The explanations for a project, newest first: the ones kept (which can still be opened) and the
 * ones in the history (save_to_pr), one row each. options.search keeps only the rows with every
 * word in them ("retry timeout", "#42", a file name). Each row: { id, created, title, summary,
 * scope, question, source, pr, files, focus, asked, answers, kept, saved }.
 */
export async function history(options = {}) {
  const { store, paths, neverShow } = await prepare(options)
  const rows = mergeHistory(listExplainers(store), paths ? readHistory(paths.history) : [])
  return searchHistory(rows.map((e) => hideNeverShow(e, neverShow)), options.search)
}

/**
 * A history row that holds a word from today's never-show list (added after it was explained, say)
 * keeps only its id and date, so the list and its search never show the word.
 */
function hideNeverShow(entry, neverShow) {
  const words = (neverShow || []).filter(Boolean).map((w) => String(w).toLowerCase())
  if (!words.length) return entry
  const text = JSON.stringify(entry).toLowerCase()
  if (!words.some((w) => text.includes(w))) return entry
  return { id: entry.id, created: entry.created, title: 'Hidden: it holds a word from the never-show list', kept: entry.kept, hidden: true }
}
