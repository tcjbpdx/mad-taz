# Explain This Change: an on-demand code review explainer

Press a button on a change and hear a short, narrated walkthrough of it: two voices talking it
through like a pair of senior engineers, with the code on screen and the exact lines lit up as
they are talked about. Ask a question first ("Is it safe to retry every request?") and the
walkthrough answers it before anything else. Ask more while it plays.

It works on a whole pull request, a branch, your uncommitted work, one file, a line range or a
single hunk. It runs on your own computer, with your own Claude Code sign-in, and it is a Claude
Code skill, a command-line tool, a JavaScript library and a drop-in `<explain-change>` button
for any review app.

**It never makes things up.** Every line of narration is checked against the change before you
see it: the code it lights up must be in the change, a reason ("why") must come from a commit
message, the pull request or an issue (otherwise it says *"Intent not stated."*), and nothing
may say the tests pass unless something actually ran or reported them passing. An explanation
that fails the check is sent back to Claude once with the problems; if it fails again, it is
refused, not shown.

What you get each time:

- **One self-contained page** (HTML, no internet needed to open it): before/after code with
  syntax colors, lines lit in step with the narration, the file and function on screen, a flow
  diagram when one helps, chapters, a transcript and a text-only view.
- **Two depths**, switchable while it plays: QUICK (about 30 seconds, the gist) and DEEP DIVE
  (every part of the change, the proof, and a closing **review focus**: what a reviewer should
  look at hardest).
- **The proof**, labelled by where it came from: tests the change touches (or doesn't), the pull
  request's check results, and, if you switch it on, your tests run before and after the change.
- **Claude's reasoning** (optional): why it was built this way, quoted word for word from the
  Claude Code session that wrote it, each quote labelled with its source.
- **Save to the pull request** (optional, off by default): one comment, plus a searchable
  history of every explanation for the repository.

---

## What goes where

This is the part to read before you point it at private code.

| What | Where it goes | When |
|---|---|---|
| The code in scope, the code around it, commit messages, the pull request's description and linked issues | **Your writer only:** your own Claude Code sign-in (the default), or the Anthropic API with your own key | Every explanation and every question |
| Claude Code session notes (for "why it was built this way") | Read on this computer; only the stretch about this change goes to your writer | Only with `reasoning → read_sessions: yes` or `--session file.jsonl` |
| The pull request's description, issues and check results | Read from GitHub with **your own** `gh` login | Only when `gh` is signed in and `source → use_github` is yes (the default) |
| A comment on the pull request | Posted with your own `gh` login | Only with `save_to_pr → enabled: yes`, and only when you press Save (or run `save`) |
| The searchable history | `explain-this-change/output/history.json`, on this computer | Only with `save_to_pr → enabled: yes` |
| The words the narrators say (which can include names from the code, said aloud), the narrators' names, the two voice names and the style line. Never the code, the diff or Claude's reasoning | **Google**, with your own key, sent in a request header | Only with `voice → service: google` |
| Everything else: the page, the cache, kept explanations, recordings, product-mode pictures | `explain-this-change/output/`, on this computer, kept out of git | Always |

Details worth knowing:

- **The default writer is your own Claude Code**, run as `claude -p` from an empty folder (so no
  project's notes or settings come along) with no tools, no MCP servers and no slash commands or
  skills, and without saving the session. Claude can't read other files or run anything while
  writing: it sees only what the skill hands it. Your own Claude Code setup still applies, on
  purpose: the account you signed in with, a company gateway if you use one, and anything you
  set up for every project (personal hooks, a personal `CLAUDE.md`). So the code goes exactly
  where your Claude Code already sends it, and if you use Claude Code on this code already,
  nothing new leaves your computer.
- **Nothing else is sent anywhere.** No analytics, no telemetry, no calls home. The page has a
  strict security policy (`default-src 'none'`): it loads nothing from the internet, and talks
  only to the helper on your own computer, when you opened it through the helper.
- **The page holds the code it explains.** Sharing the page shares that code (and, in product
  mode, the pictures of your app). The pull request comment never holds the code beyond file
  names and line numbers, never holds Claude's session reasoning, and never holds the audio.
- **Browser voices** (the default) are the computer's own. Some browsers also offer voices that
  run on a server, which would hear every word; `voice → allow_network_voices: no` (the default)
  keeps to the ones that run on the computer.
- **Running your tests runs the change's code.** `proof → run_tests` is off by default. Only turn
  it on for code you trust.
- **Keys** live in `explain-this-change/private.env`, which only you can read (mode 600), is kept
  out of git, and which Claude is told never to open. Keys are never printed: error messages and
  logs have anything key-shaped blanked out.
- **`never_show`**: words that must never be shown or spoken (a customer's name, an internal
  code name). An explanation that holds one, in the code or the narration, is refused.

## What you need

- **Node 20 or newer** and **git**.
- **Claude Code**, signed in (the default writer). Or an Anthropic API key instead.
- Optional: the **GitHub CLI** (`gh`), signed in, for pull requests, their checks, and saving.
- Optional: a **Google AI Studio key**, for Google's more natural voices.
- Optional, for product mode only: a hidden browser (Playwright's Chromium), about 150 MB, once.

**Cost:** with your Claude Code sign-in, it comes out of your plan's usage like any other Claude
Code request. On the practice project, Claude Code reported about $0.18 for one hunk with a
question, and about $0.28 for a whole pull request plus one follow-up question (what the same
work would cost on the API). Asking the same thing about the same change again costs nothing:
results are kept and reused. The Google voice is billed by Google to your key; a free-tier key
has a small daily limit, after which the page uses the computer's own voices.

## Put the skill in your project

1. Unzip the download. Inside is a folder called `explain-this-change` (this README is in it).
2. In your project, make a folder `.claude/skills/` (it starts with a dot, so it may be hidden)
   and put the `explain-this-change` folder inside it:

   ```
   your-project/.claude/skills/explain-this-change/SKILL.md
   ```

3. Open Claude Code in your project and say **"Explain this branch"** (or "Explain pull request
   42", or "Explain the change to src/retry.js and tell me whether it's safe to retry
   everything"). The first time, Claude installs the helpers, makes the settings file and checks
   everything is ready. That takes a minute or two.

Or do it yourself from the project's top folder:

```sh
SKILL=.claude/skills/explain-this-change/scripts/explain.mjs
node $SKILL setup     # installs its helpers into this copy of the skill only, once per copy
                      #   (add --browser for product mode: a hidden browser, once per computer)
node $SKILL new       # makes explain-this-change/settings.yaml and private.env
node $SKILL doctor    # checks everything is installed and set, stops at the first thing to fix, and says how
node $SKILL explain   # explains this branch, and opens it
```

Two folders share the name. `.claude/skills/explain-this-change/` is the skill itself, the same
in every project. `explain-this-change/`, at the top of your project, is yours: the settings,
the private file and the kept explanations.

What goes into git: `new` adds three lines to `.gitignore` so `explain-this-change/private.env`,
`explain-this-change/output/` and the skill's installed helpers
(`.claude/skills/explain-this-change/node_modules/`) never are. Commit
`explain-this-change/settings.yaml` if your team should share the settings, and the skill
folder if everyone should have the same version of it (each person then runs `setup` once).

Every step takes `--project path/to/project` (the default is the folder you are in). An option a
step doesn't have stops it before anything is done, so a typo (`--flie`) never quietly explains
the whole change instead; the message suggests what you meant. Familiar words work as steps
too: `init` (new), `install` (setup), `check` (doctor), `start` or `server` (serve), `practice`
or `demo` (try), `list` or `search` (history).

## Try it on the practice project first

```sh
node .claude/skills/explain-this-change/scripts/explain.mjs try --offline
```

This opens a pretend review page for a made-up project, **Parcel Pigeon** (a parcel tracker that
learns to retry when the carrier is busy), with an **Explain this part** button on every change.
`--offline` uses ready-made answers, so nothing is sent to Claude: try **Explain the whole
change**, and the retry change in `carrierClient.js` with the question *"Is it safe to retry
every request?"*. Without `--offline`, every button asks Claude for real, through your sign-in.
Stop it with Ctrl+C.

The practice project and its explanations live in your computer's temporary folder, not in your
project, and the code in them is made up. `--product` tries product mode (it needs `setup
--browser` first); `--port`, `--quiet` and `--no-open` work as they do for `serve`.

## Using it

### From Claude Code

Just ask: "explain this PR", "walk me through my staged changes", "explain lines 40 to 60 of
the parser and why it handles empty input that way". Claude picks the flags, runs it, opens the
page and tells you in a sentence or two what it covers. Follow-up questions work the same way.

### From the command line

```sh
node .claude/skills/explain-this-change/scripts/explain.mjs explain [which change] [which part] [extras]
```

| Which change | |
|---|---|
| (nothing) | this branch, against the main branch (the one GitHub calls the default, or else the first of `main`, `master`, `trunk`, `develop`; `--base` or `source → base` in settings picks another) |
| `--worktree` / `--staged` | what isn't committed yet / what is staged, each against the last commit |
| `--worktree --base main` | everything since `main`, committed or not |
| `--base main --head feature-x` | any two branches or commits |
| `--pr 42` | a pull request (needs `gh`) |
| `--diff change.diff` | a saved diff |

| Which part | |
|---|---|
| (nothing) | all of it |
| `--file src/retry.js` | one file |
| `--lines src/retry.js:10-20` | a line range (`before:src/retry.js:10-20` for the old version) |
| `--hunk h3` or `--hunk src/retry.js:34` | one hunk, by its id or by a line inside it |

New files that git isn't tracking yet are left out of `--worktree`, so a stray file with secrets
in it can't slip into an explanation; the message lists the ones it left out. To include one, run
`git add --intent-to-add <file>` and explain again.

| Extras | |
|---|---|
| `--question "Why retry 503s but not 404s?"` | answered first, before anything else |
| `--description pr.md` | the pull request's title and description, when GitHub isn't used |
| `--session file.jsonl` | Claude Code's notes of the session that wrote it, for why |
| `--product` | a plain-English recap instead (product mode, below) |
| `--fresh` | write it anew, even if it was explained before |
| `--json` | print the result as JSON, for another program: `{ ok: true, id, path, … }`, or on a refusal `{ ok: false, exitCode, problem, details }` |
| `--no-open` | don't open the page |

Other steps:

| Step | What it does |
|---|---|
| `ask <id> --question "…"` | answers a question about a kept explanation and adds it as a chapter. `--chapter d2` asks about one chapter: QUICK's chapters are `q1`, `q2`…, DEEP DIVE's `d1`, `d2`…, in the order the page's chapter list shows them, and answers are `a1`, `a2`… (a chapter that isn't there is refused, with the list). `--depth quick` or `deep` says which version you were in. A question needs at least three characters |
| `serve` | runs the helper the button and the page's question box talk to. `--port 4317` (`0` picks any free port), `--base main --head feature-x` (the change a button explains when it names none), `--quiet`, `--no-open` |
| `save <id>` | into the history, and as a pull request comment when switched on |
| `history` | every explanation for this project, newest first; `--search "retry #42"`, `--json`. A row holding a word that is on the never-show list today shows only its id and date |
| `doctor` | checks that everything is installed and set, and names the one thing to fix. It sends nothing, so whether Claude Code is signed in shows on the first explanation |
| `selftest` | proves every safeguard can refuse a bad explanation (offline, a few seconds) |
| `set-private NAME` | writes one line of `private.env` from standard input, without showing it |

Exit codes: **0** done · **1** something broke, or the request was wrong (an unknown option,
say) · **2** it needs you (a setting, a key, a sign-in) · **3** a check failed (the explanation
was refused; the message lists why).

### From code

The skill folder is also a package (`explain-this-change`, ES modules, Node 20+). It isn't on
npm: install it from the folder (`npm install ./path/to/explain-this-change`), or import it by
path.

```js
import { explain, ask, save, history } from 'explain-this-change'

const result = await explain(
  { kind: 'git', repo: '.', base: 'main' },                    // or { kind: 'github', number: 42 }, or { kind: 'diff', text }
  { kind: 'hunk', id: 'h2', question: 'Is it safe to retry?' }, // or { kind: 'whole' }, { kind: 'file', file }, { kind: 'lines', file, from, to }
  { project: '.', onProgress: (e) => console.log(e.message) },
)
result.html          // the self-contained page
result.presentation  // the same thing as data (format explain-this-change/1)
result.cached        // true when it was kept from before

const { answer } = await ask(result.id, { question: 'What if the carrier is down for good?', chapter: 'd2' }, { project: '.' })
```

`explain()` options: `project` (a folder with `explain-this-change/settings.yaml`), `settings`
(an object instead of the file), `store` (where to keep results; `null` keeps nothing), `writer`
(your own `async ({ purpose, system, prompt, schema }) => data`, to use another route to
Claude), `onProgress`, `neverShow` (extra words), `cache: false`, `mode: 'product'`. The full
list is in the comment above `explain()` in `index.mjs`. Errors are `NeedsYou` (fix a setting or
sign in), `CheckFailed` (refused; `.details` lists why) or `Problem`, each with a plain message
and an `exitCode`.

- **A writer of your own:** give the function a `cacheKey` string that names it
  (`myWriter.cacheKey = 'team-gateway'`). The writer is part of what a kept explanation is
  filed under, so one writer's explanation is never handed back for another's. Functions without
  one are filed under their function name.
- **`ask()`** answers by id (with `project` or `store`) and adds the answer to the kept page.
  Hand it the result object itself instead and you get the updated `presentation` back, but
  nothing is kept.
- **Ready-made answers, for tests:** `writer → service: fixture` with `fixture: answers.json`
  (found from the project's top folder; `{ "explain": [...], "ask": [...] }`) replays them in
  order, the last one repeating, and nothing is sent anywhere.

### The button, in any review app

1. Run the helper on the reviewer's computer:

   ```sh
   node .claude/skills/explain-this-change/scripts/explain.mjs serve
   ```

2. In `explain-this-change/settings.yaml`, find the `allow_origins` line under `server:` and list
   your review app's address on it (edit that line; a second `server:` block would replace the
   first):

   ```yaml
   server:
     port: 4317
     host: 127.0.0.1
     allow_origins: [http://localhost:3000]
   ```

3. Put the button wherever it belongs:

   ```html
   <script src="http://127.0.0.1:4317/button.js"></script>

   <explain-change></explain-change>                                  <!-- the whole change -->
   <explain-change file="src/retry.js"></explain-change>              <!-- one file -->
   <explain-change file="src/retry.js" line="34" ask></explain-change> <!-- the hunk around line 34, with a question box -->
   <explain-change hunk="h3" question="Why 3 tries?"></explain-change>
   ```

   Which change: `pr="42"`, or `base="main" head="feature-x"`, or set the element's `.diff`
   property to a diff's text, or its `.source` property to an object (`{ kind: 'github',
   number: 42 }`, `{ kind: 'git', base, head }` or `{ kind: 'diff', text }`); with none, the
   helper's default (its current branch, or what `serve --base --head` named). Other
   attributes: `from` + `to` (a line range), `side="before"` (a removed line), `label`,
   `server`, `token`. It plays the walkthrough in a window over your page.

   In React (set `.diff` or `.source` through the ref, `ref.current.diff = text`, since they are
   properties, not attributes):

   ```jsx
   import { useEffect, useRef } from 'react'

   export function ExplainButton({ file, line, question, onReady }) {
     const ref = useRef(null)
     useEffect(() => {
       const el = ref.current
       const ready = (e) => onReady?.(e.detail) // { id, url, title, cached, warnings }
       el.addEventListener('explain-change:ready', ready)
       return () => el.removeEventListener('explain-change:ready', ready)
     }, [onReady])
     return <explain-change ref={ref} file={file} line={line} question={question} ask="" />
   }
   ```

   Events (they bubble): `explain-change:progress` `{ stage, message }`, `explain-change:ready`
   `{ id, url, title, cached, warnings }` (`warnings` lists notes such as new files left out),
   `explain-change:error` `{ message, details }`. From script:
   `ExplainChange.explain({ server, token, source, scope, question, onProgress })`, then
   `ExplainChange.open(url)`. Style it with `--explain-accent`, `--explain-on-accent` (the
   button's text color) and `--explain-radius` on the element, or with `::part(button)`,
   `::part(input)` (the question box), `::part(status)` (the progress line) and
   `::part(dialog)` (the window it plays in).

4. If your app has its own Content Security Policy, allow the helper's address
   (`http://127.0.0.1:4317`) in `script-src`, `frame-src` and `connect-src`.

   Tested with review apps running on the same computer. A review app served over `https` from
   the internet, calling the helper at `http://127.0.0.1`, is untested: browsers differ here
   (some ask the reviewer's permission first, some refuse).

`examples/button/` holds a complete example review page (`review.html`, `review.js`,
`review.css`); `try` serves it.

### Who can use the helper

- It listens on `127.0.0.1` by default, so no other computer can reach it. Listening anywhere
  else requires a token (`EXPLAIN_SERVER_TOKEN` in `private.env`), and then every request must
  carry it.
- A web page can call it only from the helper's own address or one listed in
  `server → allow_origins`. It checks the request's `Origin` and accepts only JSON, so another
  site open in the same browser is refused.
- It must be reached as this computer (`127.0.0.1`, `localhost` or `[::1]`), which stops a site
  that points its own name at your computer.
- A request can't name a folder or a file to read: only a branch, a pull request number or a
  diff's text, always of the project's own repository.
- One explanation is written at a time; a few more can wait, and beyond that it says it's busy.

## The five extras

1. **Pause and ask.** Press A (or the question box) while it plays. The answer knows which
   chapter and line you were on, goes through the same fact-check, and is added to the page as
   a new chapter. It needs the page opened through the helper (`serve`, then `/x/<id>`); without
   it, use the `ask` step.
2. **Depth dial.** QUICK or DEEP DIVE (Q / D), switchable at any point. `depth` in settings picks
   where it starts.
3. **Show the proof.** A proof chapter and table list, row by row and labelled by source: the
   test files the change touches; changed code with no test changes of its own; the pull
   request's check results from GitHub (pass, fail or not finished, never guessed); and, with
   `run_tests: yes` and a `test_command`, your tests run on the code before and after the
   change, with a time limit (and `sample_command`, if you give one: a command whose output shows
  the change working, run the same way). With nothing run and nothing read, it says so in those
  words.
   Neither Claude nor the narration may say tests pass unless a row shows it.
4. **Claude's reasoning.** With `reasoning → read_sessions: yes` (or `--session`), the stretch of
   the Claude Code session that wrote the change is read on this computer, and any "why it was
   built this way" in the walkthrough must quote it word for word, labelled with its source.
   Plan files listed under `plan_notes` count as sources too. With no source, it says "Intent not
   stated." It is off by default because a session holds everything said in it.
5. **Save to the pull request, and history.** Off until `save_to_pr → enabled: yes`. Then the page
   gets a Save button and the `save` step works: one comment on the pull request (saving again
   updates it rather than adding another) with the title, summary, the answer to the question,
   what changed and why, the review focus, the proof rows exactly as found, and the questions
   asked with their answers. The history keeps a searchable record of each explanation on this
   computer: `history --search "timeout #42"`.

## Keyboard (on the page)

Space play/pause · ← → line by line · [ ] chapter by chapter · Q quick · D deep dive · A ask ·
T text only · ? all keys · Esc close. The speed control and chapter list are on screen, and the
text-only view reads the whole thing with the code, no audio needed.

## Voices

- **`browser`** (the default): free, the computer's own voices, nothing leaves the computer.
  How good they sound depends on the computer and the browser.
- **`google`**: more natural. Put your Google AI Studio key in `private.env` as
  `GOOGLE_VOICE_KEY` (a line named `GEMINI_API_KEY` is read too). Each explanation's narration is recorded once and kept with it, so playing
  it again costs nothing. Notes from testing:
  - Pick two different voices, one higher and one lower (the default is Kore and Charon). The
    captions find where each line starts from the pauses and from which voice is speaking; two
    similar voices leave only the pauses.
  - Measured on real recordings: short lines land within 0.1 to 0.2 seconds of their spot, long
    ones mostly within 0.1 to 0.4. Two known misses of about 1.5 seconds: a line whose words sit
    in the other narrator's pitch, and one narrator speaking twice in a row with no clear pause.
  - On a Mac nothing else is needed (it uses the Mac's own audio converter). Elsewhere, with
    `ffmpeg` installed the recording is compressed; without it, it is kept as WAV, which makes
    the page bigger.
  - If Google refuses (daily limit, no key, no answer), the page uses the computer's own voices
    and says why. A missing recording is made the next time the explanation is opened, so a
    used-up daily limit fixes itself the next day.
  - Safari prints a harmless line in the console about the speed control. Nothing breaks.
- **`none`**: text only.

`say_it_like` fixes words a voice gets wrong (`nginx: engine x`). Only the voice hears it.

## Product mode (for people who don't read code)

Off by default. It is the same engine with a different audience: no code on screen and no code
words in the narration, with pictures of your running app instead, the relevant part circled as
it is talked about. Useful for a product owner or a non-technical founder who wants to know what
a change did.

1. `setup --browser` once (about 150 MB).
2. In settings: `product → enabled: yes`, `app_url` (where your app runs, such as
   `http://localhost:3000`), optionally `pages` worth a picture and `audience`.
3. Sign-in: `none`; `form` (a **test** account with tidy, made-up data in `private.env` as
   `APP_TEST_EMAIL` and `APP_TEST_PASSWORD`, since anything in it can appear in a picture); or
   `by-hand` (a browser window opens the first time; sign in within five minutes, and the
   sign-in is kept in `output/product/` and asked for again only when it runs out).
4. Start your app, then `explain --product`.

Pictures are taken only of pages on `app_url`: the ones listed in `pages`, or, when none are
listed, the front page and any page the change (or the code around it) names, such as
`'/settings'`. They are taken after the script has passed its check. They stay on this computer, inside the page, and
never go into a pull request comment. The proof is said in plain words too ("Nothing here shows
the change working"), while Claude still gets the exact rows.

## How it keeps itself honest

- **The fact-check** reads every line of the script before you see it: the lines it lights must
  sit inside the change (or the context Claude was shown); every file must be one Claude was
  shown; every reason must name a real commit, the pull request, a shown issue, or say exactly
  "Intent not stated."; a question must be answered first; reasoning must be quoted word for
  word; no pass claim without a passing row; no never-show word. One round of fixes, then it
  refuses.
- **The page check** (in the tests, and in `selftest` once the hidden browser is downloaded)
  opens a finished page in a real browser, steps through every line, and confirms the lit lines
  are exactly the ones each sentence cites: side-by-side and unified, desktop and phone widths,
  light and dark.
- **`selftest`** feeds each safeguard a deliberately bad example (a line outside the hunk, a
  file never shown, a guessed reason, an unknown commit, a pass claim with no proof, a
  misquoted session, a never-show word, an unanswered question, a forbidden page, a failing test
  run, a page lighting the wrong lines) and confirms each is refused. A check that can't be shown
  failing would report "all passed" forever.

## What it can't do (yet)

- It explains what it is shown. A reason the author never wrote down comes out as "Intent not
  stated." That's deliberate.
- A change with more than about 200,000 characters of diff is too big for one go: it says so,
  and asks for one file (`--file`) or a range of lines (`--lines`) instead.
- Binary files are listed, not explained.
- One explanation is written at a time per helper.
- Untested so far:
  - the real format of Claude Code's session notes, beyond the practice files (the reader is
    written to skip anything it doesn't recognize, so the risk is missing reasoning, not wrong
    reasoning);
  - speech on a computer with no screen (the browser voices need a browser);
  - GitHub Enterprise hosts;
  - Google voices that sound alike, with very short pauses between narrators;
  - a one-word reply after a pause shorter than 60 ms may be lit about half a second late;
  - whether hooks or a personal `CLAUDE.md` you set up for every project change what the
    default writer writes (they are left on on purpose, so a company gateway keeps working);
  - a review app served over `https` from the internet calling the helper on `127.0.0.1`;
  - Windows and Linux (it was built and tested on a Mac; nothing in it is Mac-only on purpose);
  - product mode's sign-in against a real app: the `form` sign-in was tested on the practice
    app only, and `by-hand` with a script standing in for the person, not a person.

## If something goes wrong

Run `node .claude/skills/explain-this-change/scripts/explain.mjs doctor`. It checks Node, the
helpers, the settings, the private file, that Claude Code is installed, and whatever your
switched-on settings need, in that order, and stops at the first problem with the fix spelled
out. It sends nothing anywhere, so it can't tell whether Claude Code is signed in: that shows on
the first explanation ("Claude Code is not signed in", with the fix). Every other message
is written the same way: what happened, then what to do. If a check refuses an explanation
(exit 3), it lists why; try `--fresh`, or a smaller part of the change. If a check ever seems
wrong, run `selftest`.

## Tell us how it went

`FEEDBACK.md`, beside this README, is a short form. Ask Claude *"Help me fill in the
explain-this-change feedback form"* and it will ask the questions a few at a time and save your
answers as `explain-this-change/feedback.md` in your project. Send that file back.

## What's in this folder

```
explain-this-change/
  README.md             this file
  SKILL.md              the instructions Claude follows
  FEEDBACK.md           the feedback form
  LICENSE               MIT
  index.mjs             the library: explain, ask, save, history
  scripts/explain.mjs   the command
  scripts/lib/          the engine: reading the change, the writer, the fact-check, the proof,
                        reasoning, voices, pictures, the helper, saving and history
  player/               the page's own style and script (inlined into every page)
  templates/            the settings and private files that "new" copies into your project
  examples/button/      the <explain-change> button and an example review page
  examples/parcel-pigeon/  the made-up practice project, with ready-made answers
  test/                 the tests: npm test, from this folder (about a minute; nothing leaves the computer)
```

It installs two helpers (`highlight.js` for code colors, `yaml` for settings), plus two optional
ones: the Anthropic library (only for `writer → service: anthropic-api`) and Playwright (only for
product mode and the page check). Exact versions are pinned in `package-lock.json`.

MIT licensed: see `LICENSE`.
