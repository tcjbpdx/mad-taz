#!/usr/bin/env node
// The one command for Explain This Change. Claude runs it for you; you can run it too:
//
//   node .claude/skills/explain-this-change/scripts/explain.mjs <step>
//
// Run it with no step to see the list. It finishes with:
//   0 = done · 1 = something broke · 2 = it needs you (a setting, a key, a sign-in)
//   3 = a check failed (the explanation pointed at code that is not in the change, and was refused)

import { spawn } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { isAbsolute, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { CheckFailed, EXIT, findProject, NeedsYou, parseArgs, pathsFor, plural, Problem, suggest } from './lib/project.mjs'
import { loadPrivateEnv, redact } from './lib/secrets.mjs'

const STEPS = [
  ['setup', 'Installs the helpers into the skill\'s own folder. Once per copy of the skill. --browser also gets the hidden browser for product mode (a download once per computer).'],
  ['new', 'Starts the explain-this-change folder: settings and the private file. Never overwrites.'],
  ['doctor', 'Checks everything is ready and names the one thing to fix.'],
  ['explain', 'Explains a change and opens it. Which change: (nothing) this branch · --worktree · --staged · --base main --head feature · --pr 42 · --diff file.diff'],
  ['', '  Which part: (nothing) all of it · --file src/a.js · --lines src/a.js:10-20 · --hunk h3 or --hunk src/a.js:34 · --question "Why?"'],
  ['', '  --description pr.md: the pull request\'s title (first line) and description, when GitHub is not used (or a JSON file with title, body, issues)'],
  ['', '  --session file.jsonl: Claude Code\'s notes of the session that wrote it, for why it was built this way (read for this explanation only)'],
  ['', '  --product: a plain-English recap with pictures of the app instead (product mode, once it is switched on in settings.yaml)'],
  ['', '  --fresh writes it again even if it was explained before · --json prints the result for another program · --no-open'],
  ['ask', 'Asks a question about a kept explanation and prints the answer: ask <id> --question "What if…?" (--chapter d2)'],
  ['serve', 'Runs the explain button\'s helper on this computer, so pages can ask questions and review apps can use the button. Stop with Ctrl+C.'],
  ['', '  --port 4317 (0 picks any free port) · --base main and --head feature: the change a button explains when it names none · --quiet · --no-open'],
  ['try', 'A practice run on a made-up project, Parcel Pigeon: a review page with a button on every change. --offline uses ready-made answers (no Claude).'],
  ['', '  --product: every button makes a plain-English recap with pictures of Parcel Pigeon\'s tracking page (needs setup --browser) · --port · --quiet · --no-open'],
  ['save', 'Saves a kept explanation: save <id>. Into the searchable history, and as a comment on its pull request when save_to_pr is switched on.'],
  ['history', 'Lists the explanations for this project, newest first. --search "retry #42" keeps the ones with every word in them. --json'],
  ['set-private', 'Writes one line of the private file from what is piped in, never showing it: set-private ANTHROPIC_API_KEY'],
  ['selftest', 'Proves every safeguard can say no: hands each one a doctored explanation and checks it is refused. Offline, a few seconds.'],
]
const ALIASES = { init: 'new', install: 'setup', check: 'doctor', server: 'serve', start: 'serve', practice: 'try', demo: 'try', list: 'history', search: 'history', question: 'ask', 'self-test': 'selftest' }

// The options each step takes. Anything else stops with a message, so a typo (--flie) never quietly
// explains the whole change instead, and spends a request doing it.
const STEP_FLAGS = {
  help: [],
  setup: ['browser'],
  new: [],
  doctor: [],
  explain: ['worktree', 'staged', 'base', 'head', 'pr', 'diff', 'description', 'session', 'file', 'lines', 'hunk', 'question', 'product', 'fresh', 'json', 'no-open'],
  ask: ['id', 'question', 'chapter', 'depth'],
  serve: ['port', 'base', 'head', 'quiet', 'no-open'],
  try: ['offline', 'product', 'port', 'quiet', 'no-open'],
  save: [],
  history: ['search', 'json'],
  'set-private': [],
  selftest: [],
}
const ANY_STEP = ['project']
// Options that are nothing without a value after them (the others say so in their own words).
const NEEDS_VALUE = { project: '--project path/to/project', base: '--base main', head: '--head feature-x', pr: '--pr 42', chapter: '--chapter d2', depth: '--depth quick', port: '--port 4317', id: '--id <id>' }

function checkFlags(step, flags) {
  const own = STEP_FLAGS[step]
  if (!own) return // not a step: the step list says so
  const allowed = [...own, ...ANY_STEP]
  for (const name of Object.keys(flags)) {
    if (!allowed.includes(name)) {
      const near = suggest(name, allowed)
      const elsewhere = Object.keys(STEP_FLAGS).filter((k) => STEP_FLAGS[k].includes(name))
      const hint = near ? ` Did you mean --${near}?`
        : elsewhere.length ? ` It belongs to the ${elsewhere.join(' and ')} step.`
          : ` The ${step} step takes ${own.length ? own.map((f) => `--${f}`).join(' ') : 'no options'}.`
      throw new Problem(`--${name} is not an option of the ${step} step, so nothing was done.${hint}`)
    }
    if (flags[name] === true && NEEDS_VALUE[name]) throw new Problem(`--${name} needs a value after it, such as ${NEEDS_VALUE[name]}.`)
  }
}

const log = (s) => console.log(redact(String(s)))
// How to run this script from the project's top folder: the usual place, or wherever this copy is.
const SELF = (() => {
  const here = relative(process.cwd(), fileURLToPath(import.meta.url))
  return `node ${here && !here.startsWith('..') && !isAbsolute(here) ? here : '.claude/skills/explain-this-change/scripts/explain.mjs'}`
})()

function helpText() {
  const named = STEPS.filter(([s]) => s)
  const w = Math.max(...named.map(([s]) => s.length))
  return [
    'Explain a code change: a short narrated walkthrough with the lines lit up as they are talked about.',
    'The usual order: setup → new → doctor → explain (or try first, to see it on a practice project)',
    '',
    'Steps:',
    ...STEPS.map(([s, d]) => `  ${s.padEnd(w)}  ${d}`),
    '',
    `Run one with: ${SELF} <step>`,
    'Options for any step: --project <folder> (when running from somewhere else).',
  ].join('\n')
}

function openFile(target) {
  const cmd = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'explorer' : 'xdg-open'
  try {
    const p = spawn(cmd, [target], { stdio: 'ignore', detached: true })
    p.on('error', () => log(`(Could not open it by itself. Open this: ${target})`))
    p.unref()
  } catch {
    log(`(Could not open it by itself. Open this: ${target})`)
  }
}

/** The change the flags name. Nothing given: this branch against the main branch. */
function sourceFromFlags(flags, project) {
  const spec = changeFromFlags(flags, project)
  if (flags.session !== undefined) {
    if (flags.session === true) throw new Problem('--session needs the session file, such as --session ~/.claude/projects/<project>/<id>.jsonl.')
    const file = resolve(String(flags.session))
    if (!existsSync(file)) throw new Problem(`--session: there is no file "${flags.session}".`)
    spec.session = file
  }
  return spec
}

function changeFromFlags(flags, project) {
  const given = ['pr', 'diff', 'worktree', 'staged'].filter((k) => flags[k] !== undefined)
  if (given.length > 1) throw new Problem(`Name one change at a time: --${given.join(' and --')} were ${given.length > 2 ? 'all' : 'both'} given.`)
  if (flags.pr !== undefined) {
    const n = Number(flags.pr)
    if (!Number.isInteger(n) || n < 1) throw new Problem(`--pr should be a pull request number, such as --pr 42 (not "${flags.pr}").`)
    if (flags.description !== undefined) throw new Problem('--pr reads the description from GitHub, so --description is not needed with it.')
    return { kind: 'github', number: n }
  }
  if (flags.diff !== undefined) {
    if (flags.diff === true) throw new Problem('--diff needs the file holding the diff, such as --diff change.diff.')
    return { kind: 'diff', file: resolve(String(flags.diff)), ...(flags.description !== undefined ? { prInfo: descriptionFrom(flags.description) } : {}) }
  }
  const spec = { kind: 'git', repo: project }
  if (flags.description !== undefined) spec.prInfo = descriptionFrom(flags.description)
  if (typeof flags.base === 'string') spec.base = flags.base
  if (flags.worktree) spec.head = 'worktree'
  else if (flags.staged) spec.head = 'staged'
  else if (typeof flags.head === 'string') spec.head = flags.head
  return spec
}

/**
 * The pull request's description from a file, for when GitHub is not used: plain text or Markdown
 * (the first line is the title, the rest the description), or JSON with title, body and issues.
 */
function descriptionFrom(file) {
  if (file === true) throw new Problem('--description needs the file holding it, such as --description pr.md.')
  let text
  try { text = readFileSync(String(file), 'utf8') } catch { throw new Problem(`--description: there is no file "${file}".`) }
  if (/\.json$/i.test(String(file))) {
    let j
    try { j = JSON.parse(text) } catch (e) { throw new Problem(`--description: ${file} is not valid JSON (${e.message}).`) }
    if (!j || typeof j.title !== 'string') throw new Problem(`--description: ${file} needs at least a "title".`)
    const issues = Array.isArray(j.issues) ? j.issues.filter((i) => i && Number.isInteger(i.number)).map((i) => ({ number: i.number, title: String(i.title || ''), body: String(i.body || '') })) : []
    return { title: j.title, body: String(j.body || ''), issues, ...(Number.isInteger(j.number) ? { number: j.number } : {}) }
  }
  const [first, ...rest] = text.replace(/\r\n/g, '\n').split('\n')
  const title = first.replace(/^#+\s*/, '').trim()
  if (!title) throw new Problem(`--description: the first line of ${file} should be the title.`)
  return { title, body: rest.join('\n').trim(), issues: [] }
}

/** One progress line per stage, and the "still writing" ticks on the same footing. */
function progressLogger() {
  let last = ''
  return (p) => {
    if (!p || !p.message || p.message === last) return
    last = p.message
    log(`  ${p.message}${/still writing/.test(p.message) ? '' : '…'}`)
  }
}

function port(flags, settings) {
  if (flags.port === undefined) return settings.server.port
  const n = Number(flags.port)
  if (!Number.isInteger(n) || n < 0 || n > 65535) throw new Problem(`--port should be a number from 1 to 65535, or 0 for any free port (not "${flags.port}").`)
  return n
}

const untilStopped = () => new Promise((done) => { process.once('SIGINT', done); process.once('SIGTERM', done) })

async function run(step, flags) {
  const project = findProject(flags)
  let paths = pathsFor(project)
  loadPrivateEnv(paths.privateEnv)
  const where = (p) => { const r = relative(process.cwd(), p); return r && !r.startsWith('..') ? r : p }

  switch (step) {
    case 'help':
      log(helpText())
      return EXIT.ok

    case 'setup': {
      const { setup } = await import('./lib/setup.mjs')
      setup({ log, browser: Boolean(flags.browser) })
      log('Next: the "new" step starts the explain-this-change folder in your project.')
      return EXIT.ok
    }

    case 'new': {
      const { newProject } = await import('./lib/newproject.mjs')
      const r = newProject(paths)
      for (const f of r.made) log(`  made  ${where(f)}`)
      for (const f of r.kept) log(`  kept  ${where(f)} (already there, left as it was)`)
      log(r.ignore === 'added' ? '  added the private file, the output folder and the skill\'s installed helpers to .gitignore, so they are never committed' : '  .gitignore already keeps the private file, the output folder and the installed helpers out of git')
      log('Next: look over explain-this-change/settings.yaml (every line is optional), then run the doctor step.')
      return EXIT.ok
    }

    case 'doctor': {
      const { doctor, doctorStop } = await import('./lib/doctor.mjs')
      const d = await doctor({ paths, log })
      if (!d.ok) throw doctorStop(d.failed)
      log('Everything is ready.')
      return EXIT.ok
    }

    case 'explain': {
      const { explain } = await import('../index.mjs')
      const { scopeFromFlags } = await import('./lib/scope.mjs')
      const source = sourceFromFlags(flags, project)
      const scope = scopeFromFlags(flags)
      if (!flags.json) log('Explaining…')
      const mode = flags.product ? 'product' : undefined
      const r = await explain(source, scope, { project, mode, cache: !flags.fresh, onProgress: flags.json ? () => {} : progressLogger() })
      if (flags.json) {
        console.log(redact(JSON.stringify({ ok: true, id: r.id, title: r.presentation.title, path: r.path, cached: r.cached, warnings: r.warnings, usage: r.usage }, null, 2)))
        return EXIT.ok
      }
      log('')
      log(`"${r.presentation.title}"${r.cached ? ' (explained before: nothing was spent)' : ''}`)
      for (const w of r.warnings) log(`Note: ${w}`)
      if (!r.cached && r.usage) {
        const cost = typeof r.usage.usd === 'number' ? `about $${r.usage.usd.toFixed(2)}` : 'cost not reported'
        log(`Written by ${r.usage.model || 'Claude'} (${plural(r.usage.requests || 1, 'request')}, ${cost}).`)
      }
      log(`Kept as ${r.id}: ${where(r.path)}`)
      log(`To ask questions while it plays, open it through the helper: ${SELF} serve, then /x/${r.id}`)
      if (!flags['no-open']) openFile(r.path)
      return EXIT.ok
    }

    case 'ask': {
      const id = String(words[1] || flags.id || '').trim()
      if (!id) throw new Problem(`Say which explanation, by the id the explain step printed: ask <id> --question "…". The history step lists them.`)
      if (typeof flags.question !== 'string') throw new Problem('Add the question: --question "What happens when…?"')
      if (flags.depth !== undefined && flags.depth !== 'quick' && flags.depth !== 'deep') throw new Problem(`--depth is quick or deep (not "${flags.depth}").`)
      const { ask } = await import('../index.mjs')
      log('Asking…')
      const r = await ask(id, { question: flags.question, chapter: typeof flags.chapter === 'string' ? flags.chapter : null, depth: typeof flags.depth === 'string' ? flags.depth : null }, { project, onProgress: progressLogger() })
      const names = r.presentation.speakers || ['First voice', 'Second voice']
      log('')
      log(`${r.answer.chapter.title}${r.cached ? ' (asked before: nothing was spent)' : ''}`)
      for (const l of r.answer.chapter.lines) log(`  ${names[l.who] || names[0]}: ${l.say}`)
      for (const w of r.warnings) log(`Note: ${w}`)
      log(`Added to the explanation as a chapter under "Your questions".`)
      return EXIT.ok
    }

    case 'serve': {
      const { loadSettings } = await import('./lib/settings.mjs')
      const settings = await loadSettings(paths)
      paths = pathsFor(project, settings)
      const { NAMES, neverShowWords, secret } = await import('./lib/secrets.mjs')
      const { startServer } = await import('./lib/server.mjs')
      const token = secret(NAMES.serverToken)
      const defaults = {}
      if (typeof flags.base === 'string') defaults.base = flags.base
      if (typeof flags.head === 'string') defaults.head = flags.head
      const server = await startServer({
        project, settings, store: paths.explainers, port: port(flags, settings), token,
        sourceDefaults: defaults, neverShow: neverShowWords(settings), onLog: flags.quiet ? undefined : (l) => log(`  ${l}`),
      })
      const q = token ? '?token=…' : ''
      log(`The helper is running at ${server.url}`)
      log(`  ${server.url}/${q}            the explanations kept for this project`)
      log(`  ${server.url}/example${q}     a review page with a button on every change`)
      log(settings.server.allow_origins.length ? `  Review apps allowed to use the button: ${settings.server.allow_origins.join(', ')}` : '  Only the helper\'s own pages can use it (add review apps under server → allow_origins).')
      if (token) log(`  It needs the token from private.env (${NAMES.serverToken}) on every request.`)
      log('Stop it with Ctrl+C.')
      if (!flags['no-open']) openFile(`${server.url}/${token ? `?token=${encodeURIComponent(token)}` : ''}`)
      await untilStopped()
      await server.close()
      log('Stopped.')
      return EXIT.ok
    }

    case 'try': {
      const { buildSample } = await import('./lib/sample.mjs')
      const { loadSettings, settingsFromObject } = await import('./lib/settings.mjs')
      const { startServer } = await import('./lib/server.mjs')
      const own = await loadSettings(paths)
      const offline = Boolean(flags.offline)
      if (!offline && own.writer.service === 'fixture') throw new Problem('The try step uses Claude, and writer → service is fixture. Add --offline for the ready-made answers.')
      const product = Boolean(flags.product)
      const answers = await import('../examples/parcel-pigeon/answers.mjs')
      if (product) {
        const { browserReady } = await import('./lib/pictures.mjs')
        if (!(await browserReady())) throw new NeedsYou('Product mode takes pictures with a hidden browser, which is not downloaded yet. Run the setup step with --browser first (about 150 MB, once).')
      }
      const home = join(tmpdir(), 'explain-this-change-try')
      log('Building the practice project, Parcel Pigeon (made up, nothing real)…')
      const s = buildSample(join(home, 'parcel-pigeon'))
      let page = null
      if (product) {
        const { startSamplePage } = await import('./lib/sample.mjs')
        log('Starting its tracking page, with a pretend carrier (nothing is sent anywhere)…')
        page = await startSamplePage(s.dir)
        log(`  Parcel Pigeon's tracking page: ${page.url}`)
      }
      try {
        const settings = settingsFromObject({
          project_name: 'Parcel Pigeon', look: own.look, writer: own.writer, source: { use_github: false },
          ...(product ? { mode: 'product', product: { enabled: true, app_url: page.url, pages: answers.PRODUCT_PAGES } } : {}),
        })
        const writer = offline ? answers.offlineWriter() : undefined
        const server = await startServer({
          project: s.dir, settings, store: join(home, 'explainers'), port: port(flags, own), writer,
          sourceDefaults: { base: s.base, head: s.head, prInfo: s.prInfo, session: s.sessionFile }, onLog: flags.quiet ? undefined : (l) => log(`  ${l}`),
        })
        log(`The practice review page: ${server.url}/example`)
        if (product) log('Product mode: every button makes a plain-English recap, with pictures of the tracking page.')
        log(offline
          ? (product
            ? `Offline: ready-made answers, nothing is sent to Claude. One button has an answer: "Explain the whole change". In it, ask "${answers.PRODUCT_FOLLOW_UP}"`
            : `Offline: ready-made answers, nothing is sent. Two buttons have answers: "Explain the whole change", and the retry change in carrierClient.js with the question "${answers.H2_QUESTION}". In that one, ask "${answers.H2_FOLLOW_UP}"`)
          : `Each button sends that part of the made-up change to Claude (${own.writer.service === 'anthropic-api' ? 'the Anthropic API, with your key' : 'your Claude Code sign-in'}), which takes a minute or so.`)
        log('Stop it with Ctrl+C.')
        if (!flags['no-open']) openFile(`${server.url}/example`)
        await untilStopped()
        await server.close()
      } finally {
        if (page) await page.stop()
      }
      log('Stopped.')
      return EXIT.ok
    }

    case 'save': {
      const { save } = await import('../index.mjs')
      const id = words[1]
      if (!id) throw new Problem('Say which explanation to save: save <id>. The history step lists them.')
      const r = await save(String(id), { project, onProgress: (e) => log(`  ${e.message}`) })
      log(r.message)
      if (r.url) log(r.url)
      return EXIT.ok
    }

    case 'history': {
      const { history } = await import('../index.mjs')
      const search = flags.search === true ? '' : String(flags.search ?? words.slice(1).join(' '))
      const list = await history({ project, search })
      if (flags.json) { console.log(JSON.stringify(list, null, 2)); return EXIT.ok }
      if (!list.length) { log(search ? `Nothing matches "${search}".` : 'Nothing has been explained in this project yet.'); return EXIT.ok }
      for (const e of list) {
        log(`${e.id}  ${String(e.created).slice(0, 16).replace('T', ' ')}  ${e.title}`)
        const bits = [e.scope, e.question ? `asked: ${e.question}` : '', e.answers ? plural(e.answers, 'follow-up question') : '', e.pr ? `pull request #${e.pr.number}` : ''].filter(Boolean)
        if (bits.length) log(`    ${bits.join(' · ')}`)
        if (e.saved) log(`    saved to ${e.saved.to || 'the history'}${e.saved.url ? `: ${e.saved.url}` : ''}`)
        if (!e.kept) log('    in the history only: its page was cleared, so explain it again to open it')
      }
      if (search) log(`${plural(list.length, 'explanation')} with "${search}".`)
      return EXIT.ok
    }

    case 'selftest': {
      const { selftest } = await import('./lib/selftest.mjs')
      log('Checking that every safeguard can say no. Nothing leaves this computer.')
      const { results, failed } = await selftest({ log })
      const skipped = results.filter((r) => r.ok === null).length
      const passed = results.length - failed.length - skipped
      log('')
      if (failed.length) {
        log(`${plural(failed.length, 'safeguard')} did NOT catch what it should have. Explanations from this copy cannot be trusted until that is fixed.`)
        return EXIT.checkFailed
      }
      log(`All ${passed} passed${skipped ? `; ${skipped} skipped, named above` : ''}. Every safeguard was shown refusing a bad explanation.`)
      return EXIT.ok
    }

    case 'set-private': {
      const { PRIVATE_LINES, writePrivateLine } = await import('./lib/secrets.mjs')
      const name = String(words[1] || '').toUpperCase()
      if (!name) throw new Problem(`Name the line to write, for example: set-private ANTHROPIC_API_KEY. The lines are: ${PRIVATE_LINES.join(', ')}.`)
      if (process.stdin.isTTY) throw new Problem('Pipe the value in rather than typing it after the step name, so it never sits in the command.')
      const chunks = []
      for await (const c of process.stdin) chunks.push(c)
      const value = Buffer.concat(chunks).toString('utf8')
      if (!value.trim()) throw new Problem(`Nothing was piped in, so the ${name} line was left as it was.`)
      let how
      try { how = writePrivateLine(paths.privateEnv, name, value) } catch (e) { throw new Problem(e.message) }
      log(`${how === 'replaced' ? 'Replaced' : 'Added'} the ${name} line in the private file. The value was not shown anywhere.`)
      return EXIT.ok
    }

    default: {
      const names = [...STEPS.map(([s]) => s).filter(Boolean), 'help']
      const near = suggest(step, names)
      throw new Problem(near ? `"${step}" is not a step I know. Did you mean ${near}?` : `"${step}" is not a step I know.\n\n${helpText()}`)
    }
  }
}

const { words, flags } = parseArgs(process.argv.slice(2))
const asked = String(words[0] || 'help').toLowerCase()
const step = flags.help !== undefined || asked === '-h' ? 'help' : ALIASES[asked] || asked
delete flags.help

Promise.resolve().then(() => { checkFlags(step, flags); return run(step, flags) }).then(
  (code) => { process.exitCode = code ?? EXIT.ok },
  (e) => {
    const known = e && typeof e.exitCode === 'number'
    const code = known ? e.exitCode : EXIT.error
    const head = code === EXIT.needsYou ? 'Needs you:' : code === EXIT.checkFailed ? 'Check failed:' : 'Problem:'
    const msg = known ? e.message : `Something unexpected broke: ${String((e && e.message) || e).split('\n')[0]}`
    const details = e instanceof CheckFailed && e.details ? e.details.slice(0, 20) : []
    // A program reading --json gets its answer on stdout either way, and the exit code says which.
    if (flags.json) console.log(redact(JSON.stringify({ ok: false, exitCode: code, problem: msg, details }, null, 2)))
    console.error(`\n${head} ${redact(msg)}`)
    for (const d of details) console.error(`  • ${redact(d)}`)
    if (!known && process.env.EXPLAIN_DEBUG) console.error(redact(String(e && e.stack)))
    process.exitCode = code
    // Anything still holding the process open gets two seconds, then it ends.
    setTimeout(() => process.exit(code), 2000).unref()
  },
)
