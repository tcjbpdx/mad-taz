// Playback: the chapters in order, one line at a time, with the view, caption, transcript and track
// following along. The same lines play whether or not there is a voice.

const ROOT = $('etc')
const DEPTH_KEY = `explain-this-change:depth:${P.id}`
const SPEED_KEY = 'explain-this-change:speed'
let params = new URLSearchParams()
try { params = new URLSearchParams(window.location.search) } catch { /* a page with no address */ }

const S = { depth: 'deep', idx: 0, playing: false, ended: false, view: 'unified', whole: false, peek: null, speed: 1 }
let chapters = [] // this depth's chapters in play order, answers to questions included
let flow = [] // every line in play order: { chapter, line, ci }
let viewKey = ''

const hasDepth = (d) => ((P.depths && P.depths[d]) || []).some((c) => c.lines && c.lines.length)

function answerChapter(a) {
  const c = a.chapter || {}
  return { ...c, id: a.id, kind: 'answer', title: c.title || 'Your question', question: a.question, isAnswer: true, lines: c.lines || [] }
}

function buildFlow(depth) {
  const base = (P.depths && P.depths[depth]) || []
  const ids = new Set(base.map((c) => c.id))
  const answers = P.answers || []
  chapters = []
  for (const c of base) {
    chapters.push(c)
    for (const a of answers) if (a.after === c.id) chapters.push(answerChapter(a))
  }
  for (const a of answers) if (!a.after || !ids.has(a.after)) chapters.push(answerChapter(a))
  flow = []
  chapters.forEach((c, ci) => (c.lines || []).forEach((line) => flow.push({ chapter: c, line, ci })))
}

function firstDepth() {
  const ok = (d) => (d === 'quick' || d === 'deep') && hasDepth(d)
  for (const d of [params.get('depth'), store.get(DEPTH_KEY), P.player && P.player.depth, 'deep', 'quick']) if (ok(d)) return d
  return 'deep'
}

// ---- the fixed parts ----

function fillHeader() {
  const k = $('etc-kicker')
  const parts = []
  if (P.project && P.project.name) parts.push(P.project.name)
  const src = P.source || {}
  if (src.pr && src.pr.number) {
    const label = `Pull request #${src.pr.number}`
    parts.push(/^https:\/\//.test(src.pr.url || '') ? el('a', { href: src.pr.url, target: '_blank', rel: 'noopener noreferrer', text: label }) : label)
  } else if (src.label) parts.push(src.label)
  parts.push('Explain This Change')
  k.replaceChildren()
  parts.forEach((p, i) => { if (i) k.append(' · '); k.append(p) })
  $('etc-title').textContent = P.title || ''
  const sc = $('etc-scope')
  sc.replaceChildren((P.scope && P.scope.label) || '')
  if (P.scope && P.scope.question) sc.append(' · asked: ', el('q', { text: P.scope.question }))
  const all = (d) => ((P.depths && P.depths[d]) || []).flatMap((c) => c.lines || [])
  $('etc-q-len').textContent = hasDepth('quick') ? lengthLabel(all('quick')) : ''
  $('etc-d-len').textContent = hasDepth('deep') ? lengthLabel(all('deep')) : ''
  for (const b of document.querySelectorAll('.etc-dial button')) b.disabled = !hasDepth(b.dataset.depth)
}

function renderRail() {
  const list = $('etc-chapters'); const alist = $('etc-answer-list')
  list.replaceChildren(); alist.replaceChildren()
  let n = 0; let q = 0
  chapters.forEach((c, ci) => {
    const first = flow.findIndex((e) => e.ci === ci)
    if (first < 0) return
    const btn = el('button', { type: 'button', data: { ci: String(ci) }, onclick: () => go(first) },
      el('span', { class: 'n', text: c.isAnswer ? `Q${++q}` : String(++n) }),
      el('span', null, c.title, el('span', { class: 'k', text: KIND_LABEL[c.kind] || c.kind })))
    ;(c.isAnswer ? alist : list).append(el('li', null, btn))
  })
  $('etc-answers').hidden = !q
}

function renderTranscript() {
  const tx = $('etc-tx')
  tx.replaceChildren()
  let last = -1
  flow.forEach((e, i) => {
    if (e.ci !== last) { tx.append(el('li', { class: 'ch', text: e.chapter.title })); last = e.ci }
    tx.append(el('li', null, el('button', { type: 'button', data: { i: String(i) }, onclick: () => go(i) },
      el('b', { text: speakerName(e.line.who) }), e.line.say)))
  })
}

function renderTrack() {
  const t = $('etc-track')
  t.replaceChildren()
  flow.forEach((e, i) => t.append(el('span', { class: i && flow[i - 1].ci !== e.ci ? 'gap' : null, title: e.chapter.title, data: { i: String(i) } })))
}

function renderFocusPanel() {
  const items = P.focus || []
  $('etc-focus').replaceChildren(...(items.length ? items.map((it, i) => focusItem(it, i, false, peek)) : [el('li', { class: 'etc-notice', text: 'Nothing was flagged.' })]))
}

function keepInView(scroller, node) {
  if (!scroller || !node || scroller.offsetParent === null) return
  const a = scroller.getBoundingClientRect(); const b = node.getBoundingClientRect()
  if (scroller.scrollHeight > scroller.clientHeight && (b.top < a.top || b.bottom > a.bottom)) scroller.scrollTop += b.top - a.top - scroller.clientHeight / 3
  if (scroller.scrollWidth > scroller.clientWidth && (b.left < a.left || b.right > a.right)) scroller.scrollLeft += b.left - a.left - 12
}

function markCurrent() {
  const e = flow[S.idx]
  const ci = e ? e.ci : -1
  let railNow = null
  for (const b of document.querySelectorAll('.etc-rail button')) {
    const on = !S.ended && Number(b.dataset.ci) === ci
    if (on) { b.setAttribute('aria-current', 'step'); railNow = b } else b.removeAttribute('aria-current')
  }
  let txNow = null
  for (const b of document.querySelectorAll('#etc-tx button')) {
    const on = !S.ended && Number(b.dataset.i) === S.idx
    if (on) { b.setAttribute('aria-current', 'true'); txNow = b } else b.removeAttribute('aria-current')
  }
  $('etc-track').querySelectorAll('span').forEach((s, i) => {
    s.className = [s.classList.contains('gap') ? 'gap' : '', S.ended || i < S.idx ? 'done' : '', !S.ended && i === S.idx ? 'now' : ''].filter(Boolean).join(' ')
  })
  $('etc-pos').textContent = flow.length ? `${S.ended ? flow.length : S.idx + 1} / ${flow.length}` : ''
  for (const b of document.querySelectorAll('.etc-dial button')) b.setAttribute('aria-checked', String(b.dataset.depth === S.depth))
  const item = e && e.chapter.kind === 'focus' && e.line.show.type === 'card' ? e.line.show.item : -1
  for (const li of document.querySelectorAll('#etc-focus .etc-item')) li.classList.toggle('on', Number(li.dataset.i) === item)
  keepInView($('etc-p-tx'), txNow)
  keepInView($('etc-chapters'), railNow)
}

// ---- the stage ----

function caption(e) {
  const who = $('etc-who')
  if (S.peek) { who.hidden = true; $('etc-say').textContent = `Showing the ${S.peek.type === 'picture' ? 'picture' : 'code'} for this point. Press play to carry on.`; return }
  who.hidden = false
  who.textContent = speakerName(e.line.who)
  who.className = e.line.who ? 's1' : ''
  $('etc-say').textContent = e.line.say
}

function scrollToItem(scroller, smooth) {
  const on = scroller.querySelector('.etc-item.on, .etc-proof tr.lit, .etc-ring:not([hidden])')
  if (!on) { scroller.scrollTo({ top: 0 }); return }
  const a = scroller.getBoundingClientRect(); const b = on.getBoundingClientRect()
  const target = scroller.scrollTop + b.top - a.top - Math.max(12, (scroller.clientHeight - b.height) / 2)
  scroller.scrollTo({ top: Math.max(0, target), behavior: smooth && !reducedMotion() ? 'smooth' : 'auto' })
}

function renderStage(chapter, show) {
  const view = $('etc-view')
  const isCode = show.type === 'code'
  const pic = show.type === 'picture' ? (P.pictures || [])[show.item] : null
  const dia = !S.peek && chapter.kind === 'diagram' && (chapter.nodes || []).length > 0
  const key = isCode
    ? ['code', show.hunk && !S.whole ? show.hunk : show.file, show.side, S.view, S.whole, show.hunk || S.whole ? '' : `${show.from}-${show.to}`, dia ? `${chapter.id}:${show.fn}` : ''].join('|')
    : pic ? ['picture', show.item].join('|') : ['card', chapter.id, dia].join('|')
  const fresh = key !== viewKey
  if (fresh) {
    viewKey = key
    view.classList.toggle('card-mode', !isCode)
    view.classList.toggle('pic-mode', Boolean(pic))
    const parts = []
    if (dia) parts.push(el('div', { class: isCode ? 'etc-dia' : 'etc-dia full' }, diagramSvg(chapter, show)))
    if (isCode) parts.push(el('div', { class: 'etc-scroll' }, codeTable(show, S.view, S.whole)))
    else if (pic) parts.push(el('div', { class: 'etc-scroll' }, pictureView(pic, show.point_at)))
    else if (!dia) parts.push(el('div', { class: 'etc-scroll' }, chapterCard(chapter, show.item, peek)))
    view.replaceChildren(...parts)
  } else if (isCode) {
    const table = view.querySelector('.etc-code')
    if (table) relight(table, show)
  } else if (pic) {
    const fig = view.querySelector('.etc-pic')
    if (fig) placeRing(fig, pic, show.point_at)
  } else {
    for (const li of view.querySelectorAll('.etc-items > .etc-item')) li.classList.toggle('on', Number(li.dataset.i) === show.item)
    for (const tr of view.querySelectorAll('.etc-proof tbody tr')) tr.classList.toggle('lit', Number(tr.dataset.i) === show.item)
  }
  whereBar(show, chapter, { view: S.view, whole: S.whole, onView: setView, onWhole: setWhole })
  const scroller = view.querySelector('.etc-scroll')
  if (scroller) (isCode ? scrollToBand : scrollToItem)(scroller, !fresh)
}

// On a narrow screen the page scrolls, so after the first line, bring the code and its caption into
// view together (above the play bar) whenever the line changes.
let settled = false
function fitStage() {
  if (!settled || !window.matchMedia('(max-width: 980px)').matches) return
  const stage = ROOT.querySelector('.etc-stage')
  const bar = ROOT.querySelector('.etc-controls')
  if (!stage || !bar) return
  const s = stage.getBoundingClientRect()
  const cap = $('etc-caption').getBoundingClientRect()
  const limit = bar.getBoundingClientRect().top - 6
  if (s.top >= -1 && cap.bottom <= limit) return
  window.scrollTo({ top: Math.max(0, window.scrollY + s.top - 4), behavior: reducedMotion() ? 'auto' : 'smooth' })
}

function showLine() {
  const e = flow[S.idx]
  if (!e) {
    $('etc-view').replaceChildren(el('div', { class: 'etc-scroll' }, el('div', { class: 'etc-end' }, el('h3', { text: 'Nothing to play' }), el('p', { text: 'This explanation has no lines in this version.' }))))
    return
  }
  S.ended = false
  renderStage(e.chapter, S.peek || e.line.show)
  caption(e)
  markCurrent()
  fitStage()
  notifyHost('line', { lineId: e.line.id, chapterId: e.chapter.id, depth: S.depth })
}

function showEnd() {
  S.ended = true
  viewKey = 'end'
  const other = S.depth === 'deep' ? 'quick' : 'deep'
  const view = $('etc-view')
  view.classList.add('card-mode')
  view.replaceChildren(el('div', { class: 'etc-scroll' }, el('div', { class: 'etc-end' },
    el('h3', { text: 'That is the whole explanation' }),
    el('p', { text: `${chapters.length} chapter${chapters.length === 1 ? '' : 's'}, ${flow.length} line${flow.length === 1 ? '' : 's'}.` }),
    el('div', { class: 'row' },
      el('button', { type: 'button', class: 'etc-btn', onclick: () => { S.idx = 0; play() }, text: 'Play again' }),
      hasDepth(other) ? el('button', { type: 'button', class: 'etc-btn', onclick: () => setDepth(other, true), text: other === 'quick' ? 'Play the quick version' : 'Play the deep dive' }) : null,
      el('button', { type: 'button', class: 'etc-btn', onclick: openText, text: 'Read it as text' })))))
  $('etc-where').replaceChildren(el('span', { class: 'etc-tag', text: 'The end' }))
  $('etc-who').hidden = true
  $('etc-say').textContent = 'Press play to hear it again, or switch to the other version.'
  markCurrent()
  notifyHost('ended', { depth: S.depth })
}

// ---- playback ----

function setPlaying(on) {
  S.playing = on
  ROOT.classList.toggle('playing', on)
  $('etc-play').setAttribute('aria-label', on ? 'Pause' : 'Play')
}

function speakCurrent() {
  showLine()
  const e = flow[S.idx]
  if (!e) { setPlaying(false); return }
  Voice.speak(e.line.say, e.line.who, S.speed, () => {
    if (!S.playing) return
    if (S.idx + 1 < flow.length) { S.idx++; speakCurrent() } else { setPlaying(false); showEnd() }
  }, e.line.id)
}

function play() {
  if (!flow.length) return
  if (S.ended) S.idx = 0
  S.peek = null
  setPlaying(true)
  speakCurrent()
}

function pause() { Voice.stop(); setPlaying(false) }
function toggle() { if (S.playing) pause(); else play() }

/** Jumps to a line. Playing carries on from there; paused stays paused. */
function go(i) {
  if (!flow.length) return
  S.idx = Math.max(0, Math.min(flow.length - 1, i))
  S.peek = null
  if (S.playing) speakCurrent(); else showLine()
}

function step(dir) {
  if (S.ended && dir < 0) { go(flow.length - 1); return }
  if (S.ended) return
  if (dir > 0 && S.idx === flow.length - 1) { pause(); showEnd(); return }
  go(S.idx + dir)
}

function chapterStep(dir) {
  const e = flow[S.idx]
  if (!e) return
  if (S.ended) { if (dir < 0) go(flow.findIndex((x) => x.ci === flow[flow.length - 1].ci)); return }
  const firstOfThis = flow.findIndex((x) => x.ci === e.ci)
  if (dir < 0 && S.idx > firstOfThis) { go(firstOfThis); return }
  const target = flow.findIndex((x) => x.ci === e.ci + dir)
  if (target >= 0) go(target)
  else if (dir > 0) { pause(); showEnd() }
}

// The closest line in the new flow to one from the old. Where to carry on after the depth changes: the same line if it is in both, else the same kind of
// chapter showing the same lines, then the same lines anywhere, then the same change, then the
// same kind of chapter. (A one-change explainer shows that change in every chapter, so the kind of
// chapter has to come before the change, or the overview would jump back to the answer.)
const fileOfShow = (s) => s.file || (s.hunk && hunkById.get(s.hunk) ? hunkById.get(s.hunk).file : '')
const sameLines = (a, b) => a.type === 'code' && b.type === 'code' && fileOfShow(a) !== '' && fileOfShow(a) === fileOfShow(b) && a.side === b.side && a.from <= b.to && a.to >= b.from
const samePicture = (a, b) => a.type === 'picture' && b.type === 'picture' && a.item === b.item
const sameChange = (a, b) => a.type === 'code' && b.type === 'code' && Boolean(a.hunk) && a.hunk === b.hunk
function mapLine(from) {
  if (!from) return 0
  const s = from.line.show
  const sameKind = (e) => e.chapter.kind === from.chapter.kind
  const tries = [
    (e) => e.line.id === from.line.id,
    (e) => sameKind(e) && sameLines(e.line.show, s),
    (e) => sameLines(e.line.show, s),
    (e) => sameKind(e) && samePicture(e.line.show, s),
    (e) => samePicture(e.line.show, s),
    (e) => sameKind(e) && sameChange(e.line.show, s),
    (e) => sameChange(e.line.show, s),
    sameKind,
  ]
  for (const t of tries) { const i = flow.findIndex(t); if (i >= 0) return i }
  return 0
}

function rebuild() {
  buildFlow(S.depth)
  renderRail(); renderTranscript(); renderTrack()
  viewKey = ''
}

function setDepth(d, autoplay) {
  if (!hasDepth(d)) return
  if (d === S.depth && !S.ended) return
  const from = S.ended ? null : flow[S.idx]
  const resume = S.playing || Boolean(autoplay)
  pause()
  S.depth = d
  store.set(DEPTH_KEY, d)
  rebuild()
  S.idx = mapLine(from)
  S.ended = false
  S.peek = null
  if (resume) play(); else showLine()
}

function refreshStage() {
  if (S.ended) return
  viewKey = ''
  const e = flow[S.idx]
  if (e) renderStage(e.chapter, S.peek || e.line.show)
}
function setView(v) { if (v === 'unified' || v === 'split') { S.view = v; refreshStage() } }
function setWhole(w) { S.whole = Boolean(w); refreshStage() }

/** Shows the code a review-focus item points at, and pauses there. */
function peek(it) {
  if (it && PRODUCT && it.picture >= 0 && (P.pictures || [])[it.picture]) {
    pause()
    S.peek = { type: 'picture', item: it.picture, point_at: '' }
    S.ended = false
    showLine()
    return
  }
  if (!it || it.general) return
  pause()
  const h = it.hunk ? hunkById.get(it.hunk) : null
  S.peek = { type: 'code', hunk: it.hunk || '', file: it.file || (h && h.file) || '', side: it.side || 'after', from: it.from, to: it.to || it.from, item: -1, fn: '' }
  S.ended = false
  showLine()
}

function setTab(which) {
  const tx = which !== 'focus'
  $('etc-tab-tx').setAttribute('aria-selected', String(tx))
  $('etc-tab-focus').setAttribute('aria-selected', String(!tx))
  $('etc-p-tx').hidden = !tx
  $('etc-p-focus').hidden = tx
  if (tx) markCurrent()
}
