// Asking, saving, the text-only view, help, keys, and start-up.
//
// Asking needs something that can reach Claude: either the skill's own local server (its address is
// in the page's config) or a host app that has embedded this player in a frame and said it answers
// questions. A saved copy on its own can't ask, and says so rather than pretending.

const inFrame = (() => { try { return window.parent && window.parent !== window } catch { return true } })()
let hostOrigin = null
let hostAsk = false
let handshakeWait = inFrame && !CONFIG.ask
const pending = new Map()
let asking = false

function notifyHost(kind, extra) {
  if (!hostOrigin) return
  try { window.parent.postMessage({ type: `explain-this-change:${kind}`, id: P.id, ...extra }, hostOrigin === 'null' ? '*' : hostOrigin) } catch { /* the host went away */ }
}

const askMode = () => (CONFIG.ask ? 'endpoint' : hostAsk ? 'host' : 'none')
const NO_ASK = "Asking needs this explainer opened by the skill's own server (its serve step), or inside a review app that answers questions. This saved copy can't reach Claude on its own."

function note(text, bad) {
  const n = $('etc-ask-note')
  n.textContent = text
  n.className = bad ? 'note bad' : 'note'
}

function updateAsk() {
  const mode = askMode()
  const off = mode === 'none'
  $('etc-go').disabled = off || asking
  $('etc-q').disabled = off
  if (!asking) note(off && !handshakeWait ? NO_ASK : '', false)
}

function headers() {
  const h = { 'content-type': 'application/json' }
  if (CONFIG.token) h['x-explain-token'] = CONFIG.token
  return h
}

async function askEndpoint(body) {
  const r = await fetch(CONFIG.ask, { method: 'POST', headers: headers(), body: JSON.stringify(body) })
  const j = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(j.error || `The server could not answer (${r.status}).`)
  return j
}

function askHost(body) {
  return new Promise((resolve, reject) => {
    const requestId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`
    const timer = setTimeout(() => { pending.delete(requestId); reject(new Error('No answer came back after three minutes.')) }, 180000)
    pending.set(requestId, { resolve: (v) => { clearTimeout(timer); resolve(v) }, reject: (e) => { clearTimeout(timer); reject(e) } })
    notifyHost('ask', { requestId, question: body.question, chapterId: body.chapter, lineId: body.line, depth: body.depth })
  })
}

/** Adds an answer (and any code it shows) as a chapter after the one it was asked in, and plays it. */
function addAnswer(answer, extra) {
  for (const f of (extra && extra.files) || []) {
    const i = P.files.findIndex((x) => x.path === f.path)
    if (i >= 0) P.files[i] = f; else P.files.push(f)
  }
  for (const h of (extra && extra.hunks) || []) if (!P.hunks.some((x) => x.id === h.id)) P.hunks.push(h)
  // The answer's own recording, when the explanation is voiced by Google.
  if (extra && extra.audio) Voice.addTrack(answer.id, extra.audio)
  indexData()
  P.answers = P.answers || []
  if (!P.answers.some((a) => a.id === answer.id)) P.answers.push(answer)
  const from = flow[S.idx]
  rebuild()
  const i = flow.findIndex((e) => e.chapter.id === answer.id)
  S.idx = i >= 0 ? i : mapLine(from)
  S.ended = false
  play()
}

async function onAsk(ev) {
  ev.preventDefault()
  if (asking || askMode() === 'none') return
  const question = $('etc-q').value.trim()
  if (question.length < 3) { note('Type a question first.', true); return }
  const e = flow[S.idx]
  pause()
  asking = true
  updateAsk()
  note('Asking Claude about this part. It usually takes under a minute.', false)
  const body = { id: P.id, chapter: e ? e.chapter.id : null, line: e ? e.line.id : null, depth: S.depth, question }
  try {
    const res = askMode() === 'endpoint' ? await askEndpoint(body) : await askHost(body)
    if (!res || !res.answer || !res.answer.chapter) throw new Error((res && res.error) || 'No answer came back.')
    $('etc-q').value = ''
    asking = false
    updateAsk()
    note('Answered. It is now a chapter under "Your questions".', false)
    addAnswer(res.answer, res)
  } catch (err) {
    asking = false
    updateAsk()
    note(err && err.message ? err.message : 'That question could not be answered.', true)
  }
}

window.addEventListener('message', (ev) => {
  if (!inFrame || ev.source !== window.parent) return
  const d = ev.data
  if (!d || typeof d !== 'object' || typeof d.type !== 'string') return
  if (d.type === 'explain-this-change:host') {
    if (hostOrigin && hostOrigin !== ev.origin) return
    hostOrigin = ev.origin
    hostAsk = Boolean(d.ask)
    handshakeWait = false
    updateAsk()
    const e = flow[S.idx]
    if (e && !S.ended) notifyHost('line', { lineId: e.line.id, chapterId: e.chapter.id, depth: S.depth })
    return
  }
  if (ev.origin !== hostOrigin) return
  if (d.type === 'explain-this-change:answer') {
    const p = pending.get(d.requestId)
    if (!p) return
    pending.delete(d.requestId)
    if (d.error) p.reject(new Error(String(d.error))); else p.resolve(d)
  } else if (d.type === 'explain-this-change:control') {
    if (d.action === 'play') play()
    else if (d.action === 'pause') pause()
    else if (d.action === 'depth') setDepth(d.depth)
  }
})

// ---- save (to the history, and to the pull request when that is switched on) ----

/** Said to screen readers: what the save did. */
function announce(text) { const n = $('etc-save-note'); if (n) n.textContent = text }

function wireSave() {
  if (!CONFIG.save) return
  const b = $('etc-save')
  const link = $('etc-saved')
  const label = CONFIG.saveLabel || 'Save'
  b.textContent = label
  b.hidden = false
  b.addEventListener('click', async () => {
    b.disabled = true
    b.textContent = 'Saving…'
    try {
      const r = await fetch(CONFIG.save, { method: 'POST', headers: headers(), body: JSON.stringify({ id: P.id }) })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(j.error || `Not saved (${r.status}).`)
      b.textContent = j.label || 'Saved'
      b.title = `${j.message || ''} Save again to bring it up to date.`.trim()
      announce(j.message || 'Saved')
      // Only a link to GitHub's own page for the comment is offered, opened outside the player.
      if (link && typeof j.url === 'string' && /^https:\/\/[^/]+\/.+/.test(j.url)) {
        link.href = j.url
        link.hidden = false
      }
    } catch (err) {
      b.textContent = 'Not saved: try again'
      b.title = err && err.message ? err.message : ''
      announce(`Not saved. ${b.title}`)
    }
    b.disabled = false
  })
}

// ---- text only ----

function codeBlock(s) {
  const head = `${s.file}${s.fn ? ` · ${s.fn}()` : ''} · ${s.side === 'before' ? 'before' : 'after'}, ${linesLabel(s.from, s.to)}`
  return el('div', { class: 'code' }, el('div', { class: 'head', text: head }), codeTable(s, 'unified', false))
}

function buildText() {
  const a = $('etc-textbody')
  a.replaceChildren(
    el('h1', { text: P.title }),
    el('p', { class: 'meta', text: [P.scope && P.scope.label, P.source && P.source.label, S.depth === 'quick' ? 'Quick version' : 'Deep dive'].filter(Boolean).join(' · ') }),
    el('p', { text: P.summary }))
  for (const c of chapters) {
    a.append(el('h2', { text: c.title }), el('p', { class: 'meta', text: KIND_LABEL[c.kind] || c.kind }))
    if (c.kind === 'answer' && c.question) a.append(el('p', { class: 'meta' }, 'Question: ', el('q', { text: c.question })))
    if (c.kind === 'change') {
      a.append(el('dl', { class: 'etc-grid' },
        el('dt', { text: 'Before' }), el('dd', { text: c.before || '' }),
        el('dt', { text: 'After' }), el('dd', { text: c.after || '' }),
        el('dt', { text: 'Why' }), el('dd', null, c.why_source === 'none' ? '' : (c.why || ''), chip(c.why_source)),
        PRODUCT ? null : [el('dt', { text: 'Affects' }), el('dd', { text: c.affects || '' })]))
    }
    if (c.kind === 'diagram' && (c.nodes || []).length) a.append(el('div', { class: 'code' }, diagramSvg(c, null)))
    const seen = new Set()
    for (const l of c.lines || []) {
      const s = l.show
      if (s.type === 'code') {
        const k = [s.hunk, s.file, s.side, s.from, s.to].join('|')
        if (!seen.has(k)) { seen.add(k); a.append(codeBlock(s)) }
      }
      const pic = s.type === 'picture' ? (P.pictures || [])[s.item] : null
      if (pic && !seen.has(`picture|${s.item}`)) { seen.add(`picture|${s.item}`); a.append(el('div', { class: 'pic' }, pictureView(pic, ''))) }
      a.append(el('p', { class: 'l' }, el('b', { text: `${speakerName(l.who)}:` }), l.say))
    }
    if (c.kind === 'focus') a.append(el('ol', { class: 'etc-items' }, (P.focus || []).map((it, i) => focusItem(it, i, false, null))))
    if (c.kind === 'reasoning') a.append(el('ol', { class: 'etc-items' }, (P.reasoning || []).map((r, i) => reasoningItem(r, i, false))))
    if (c.kind === 'proof') a.append(proofTable(-1))
  }
  if ((P.warnings || []).length) a.append(el('h2', { text: 'Notes from the checker' }), el('ul', null, P.warnings.map((w) => el('li', { text: w }))))
}

let lastFocus = null
function openText() {
  pause()
  buildText()
  lastFocus = document.activeElement
  $('etc-textview').hidden = false
  $('etc-textbtn').setAttribute('aria-pressed', 'true')
  $('etc-textclose').focus()
}
function closeText() {
  $('etc-textview').hidden = true
  $('etc-textbtn').setAttribute('aria-pressed', 'false')
  ;(lastFocus && lastFocus.focus ? lastFocus : $('etc-textbtn')).focus()
}

function openHelp() { lastFocus = document.activeElement; $('etc-help').hidden = false; $('etc-helpclose').focus() }
function closeHelp() { $('etc-help').hidden = true; if (lastFocus && lastFocus.focus) lastFocus.focus() }

// ---- keys ----

function onKey(ev) {
  if (ev.metaKey || ev.ctrlKey || ev.altKey) return
  const t = ev.target
  const typing = t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.tagName === 'SELECT' || t.isContentEditable)
  if (ev.key === 'Escape') {
    if (!$('etc-help').hidden) closeHelp()
    else if (!$('etc-textview').hidden) closeText()
    else if (typing) t.blur()
    return
  }
  if (typing || !$('etc-help').hidden) return
  const textOpen = !$('etc-textview').hidden
  const k = ev.key
  if (k === 't' || k === 'T') { ev.preventDefault(); if (textOpen) closeText(); else openText(); return }
  if (textOpen) return
  if (k === ' ') { if (t && t.tagName === 'BUTTON') return; ev.preventDefault(); toggle() }
  else if (k === 'ArrowRight') { ev.preventDefault(); step(1) }
  else if (k === 'ArrowLeft') { ev.preventDefault(); step(-1) }
  else if (k === ']') chapterStep(1)
  else if (k === '[') chapterStep(-1)
  else if (k === 'q' || k === 'Q') setDepth('quick')
  else if (k === 'd' || k === 'D') setDepth('deep')
  else if (k === 'a' || k === 'A') { if (!$('etc-q').disabled) { ev.preventDefault(); $('etc-q').focus() } }
  else if (k === '?') openHelp()
}

// ---- the hook the automatic check uses ----

window.__etc = {
  state: () => ({ depth: S.depth, idx: S.idx, playing: S.playing, ended: S.ended, lineId: flow[S.idx] ? flow[S.idx].line.id : null, chapterId: flow[S.idx] ? flow[S.idx].chapter.id : null, view: S.view, whole: S.whole, count: flow.length, voice: Voice.active, ask: askMode() }),
  lineIds: () => flow.map((e) => e.line.id),
  goTo(id) { const i = flow.findIndex((e) => e.line.id === id); if (i < 0) return false; go(i); return true },
  setDepth(d) { setDepth(d); return S.depth },
  setView(v) { setView(v); return S.view },
  setWhole(w) { setWhole(w); return S.whole },
  bandLines() {
    const view = $('etc-view')
    const scroller = view.querySelector('.etc-scroll')
    const tag = $('etc-where').querySelector('.etc-tag[data-side]')
    const side = tag ? tag.dataset.side : null
    const col = side === 'before' ? 'o' : 'n'
    const lines = [...view.querySelectorAll(`tr.lit td.no.${col}, td.no.${col}.lit-cell`)].map((td) => Number(td.textContent)).filter((n) => n > 0)
    const first = view.querySelector('tr.lit, td.lit-cell, .etc-item.on, .etc-ring:not([hidden])')
    let visible = false
    if (first && scroller) {
      const a = scroller.getBoundingClientRect(); const b = first.getBoundingClientRect()
      visible = b.bottom > a.top + 1 && b.top < a.bottom - 1 && b.right > a.left + 1 && b.left < a.right - 1
    }
    // On screen means inside the code panel, inside the window, and not under the play bar.
    const barTop = ROOT.querySelector('.etc-controls').getBoundingClientRect().top
    if (first && visible) { const b = first.getBoundingClientRect(); visible = b.top < Math.min(window.innerHeight, barTop) - 1 && b.bottom > 1 }
    const cap = $('etc-caption').getBoundingClientRect()
    const path = $('etc-where').querySelector('.etc-path')
    return {
      captionVisible: cap.height > 0 && cap.top >= -1 && cap.bottom <= Math.min(window.innerHeight, barTop) + 1,
      file: path ? path.title : null, side, lines, visible,
      items: [...view.querySelectorAll('.etc-item.on')].map((n) => Number(n.dataset.i)),
      proofRow: view.querySelector('.etc-proof tbody tr.lit') ? Number(view.querySelector('.etc-proof tbody tr.lit').dataset.i) : -1,
      diagram: Boolean(view.querySelector('.etc-diagram')),
      card: Boolean(view.querySelector('.etc-card')),
      picture: view.querySelector('.etc-pic figcaption') ? view.querySelector('.etc-pic figcaption').textContent : null,
      pictureShown: (() => { const img = view.querySelector('.etc-pic img'); return Boolean(img && img.complete && img.naturalWidth > 0) })(),
      ring: (() => {
        const r = view.querySelector('.etc-ring:not([hidden])'); const img = view.querySelector('.etc-pic img')
        if (!r || !img) return null
        const a = img.getBoundingClientRect(); const b = r.getBoundingClientRect()
        return { left: (b.left - a.left) / a.width, top: (b.top - a.top) / a.height, width: b.width / a.width, height: b.height / a.height }
      })(),
      who: $('etc-who').hidden ? '' : $('etc-who').textContent,
      say: $('etc-say').textContent,
    }
  },
}

// ---- start ----

function init() {
  const th = params.get('theme')
  if (th === 'light' || th === 'dark') document.documentElement.dataset.theme = th
  const sp = Number(store.get(SPEED_KEY))
  if ([0.75, 1, 1.25, 1.5, 2].includes(sp)) { S.speed = sp; $('etc-speed').value = String(sp) }
  S.depth = firstDepth()
  if (PRODUCT) {
    $('etc-tab-focus').textContent = 'What to check'
    $('etc-q').placeholder = 'e.g. What will people notice first?'
  }
  fillHeader()
  renderFocusPanel()
  rebuild()

  $('etc-play').addEventListener('click', toggle)
  $('etc-prev').addEventListener('click', () => step(-1))
  $('etc-next').addEventListener('click', () => step(1))
  $('etc-track').addEventListener('click', (ev) => { const s = ev.target.closest('span[data-i]'); if (s) go(Number(s.dataset.i)) })
  $('etc-speed').addEventListener('change', (ev) => {
    S.speed = Number(ev.target.value) || 1
    store.set(SPEED_KEY, String(S.speed))
    if (S.playing) speakCurrent()
  })
  for (const b of document.querySelectorAll('.etc-dial button')) b.addEventListener('click', () => setDepth(b.dataset.depth))
  $('etc-tab-tx').addEventListener('click', () => setTab('tx'))
  $('etc-tab-focus').addEventListener('click', () => setTab('focus'))
  // Wired to the button and the Enter key, not the form's submit: a host that frames the player
  // in a sandbox without allow-forms blocks submitting before any handler runs.
  $('etc-ask').addEventListener('submit', (ev) => ev.preventDefault())
  $('etc-go').addEventListener('click', onAsk)
  $('etc-q').addEventListener('keydown', (ev) => { if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) onAsk(ev) })
  $('etc-textbtn').addEventListener('click', openText)
  $('etc-textclose').addEventListener('click', closeText)
  $('etc-helpbtn').addEventListener('click', openHelp)
  $('etc-helpclose').addEventListener('click', closeHelp)
  $('etc-help').addEventListener('click', (ev) => { if (ev.target === $('etc-help')) closeHelp() })
  document.addEventListener('keydown', onKey)
  let resizeTimer = 0
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer)
    resizeTimer = setTimeout(() => { const s = $('etc-view').querySelector('.etc-scroll'); if (s && !S.ended) (s.querySelector('.etc-code') ? scrollToBand : scrollToItem)(s, false) }, 120)
  })
  Voice.onStatus((s) => { const v = $('etc-voice'); v.textContent = s; v.title = s })
  wireSave()
  updateAsk()
  // Tell a host frame the player is here (only the id goes out; nothing else until it answers).
  if (inFrame) { try { window.parent.postMessage({ type: 'explain-this-change:ready', id: P.id }, '*') } catch { /* no parent */ } }
  if (handshakeWait) setTimeout(() => { handshakeWait = false; updateAsk() }, 800)
  S.idx = 0
  showLine()
  // From here on, a new line brings its code and caption into view on a narrow screen (the first
  // line leaves the title showing).
  settled = true
}

init()
