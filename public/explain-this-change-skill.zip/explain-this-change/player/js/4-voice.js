// The voice. By default it is the browser's own speech, and only voices that run on this computer:
// a "network" voice would send the narration to the browser maker's servers, so those stay off unless
// the settings allow them. With no usable voice the captions still advance on a reading-pace timer.
//
// With voice → service: google, the explanation may carry a recording of each version (P.audio),
// with where every line starts in it. Those lines play from the recording, one line after another
// without a gap; anything not recorded (or a recording the browser will not play) falls back to the
// browser's own speech, then to the timer.

const Voice = (() => {
  const cfg = (P.player && P.player.voice) || {}
  const synth = typeof window.speechSynthesis !== 'undefined' ? window.speechSynthesis : null
  const wanted = cfg.service !== 'none' && Boolean(synth)
  let chosen = [null, null]
  let pitch = [1, 1]
  let status = ''
  let current = 0 // token of the line being spoken; older callbacks are ignored
  let timers = []

  const sayLike = Object.entries(cfg.say_it_like || {}).filter(([w, s]) => w && typeof s === 'string')
  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const rules = sayLike.map(([w, s]) => [new RegExp(`(?<![\\w])${escapeRe(w)}(?![\\w])`, 'gi'), s])
  const spoken = (text) => rules.reduce((t, [re, s]) => t.replace(re, s), String(text || ''))

  const NOVELTY = /^(Albert|Bad News|Bahh|Bells|Boing|Bubbles|Cellos|Good News|Jester|Organ|Superstar|Trinoids|Whisper|Wobble|Zarvox|Fred|Junior|Kathy|Ralph|Eddy|Flo|Grandma|Grandpa|Reed|Rocko|Sandy|Shelley)\b/i
  const person = (v) => v.name.replace(/\s*\(.*\)\s*$/, '').trim().toLowerCase()
  const here = (typeof navigator !== 'undefined' && navigator.language) || 'en-US'
  // Better-sounding first: the higher-quality downloads, then the reader's own accent, then the default.
  const score = (v) => (/(premium|enhanced|natural|neural)/i.test(v.name) ? 4 : 0)
    + (v.lang.replace('_', '-').toLowerCase() === here.toLowerCase() ? 2 : 0) + (v.default ? 1 : 0)

  function pick() {
    if (!wanted) { status = cfg.service === 'none' ? 'Text only' : 'No voice in this browser: captions only'; return }
    const all = synth.getVoices() || []
    const list = cfg.allow_network_voices ? all : all.filter((v) => v.localService)
    const en = list.filter((v) => /^en([-_]|$)/i.test(v.lang))
    const usable = en.length ? en : list
    // Joke and robot voices some computers ship with are a last resort, not a narrator.
    const plain = usable.filter((v) => !NOVELTY.test(v.name))
    const pool = (plain.length ? plain : usable).slice().sort((x, y) => score(y) - score(x))
    if (!pool.length) { chosen = [null, null]; status = all.length ? 'No on-device voice: captions only' : 'Looking for a voice…'; return }
    const first = pool[0]
    // A different person, not the same voice in a better quality.
    const others = pool.filter((v) => person(v) !== person(first))
    const second = others.find((v) => v.lang.slice(0, 2) === first.lang.slice(0, 2)) || others[0]
    chosen = [first, second || first]
    pitch = second ? [1, 1] : [0.92, 1.12]
    const where = cfg.allow_network_voices && (!first.localService || (second && !second.localService)) ? 'may use the network' : 'on this computer'
    status = `Voice: ${first.name}${second ? ` + ${second.name}` : ''} (${where})`
  }

  // ---- the recording ----
  const recorded = cfg.service === 'google' && P.audio ? P.audio : null
  const tracks = {}
  const marks = new Map() // line id → { key, s, e } in seconds
  let audio = null // one element for every track: a phone allows sound from an element once it has been tapped to play
  let loaded = null // which track it holds
  let broken = false // the browser would not play a recording: speech from then on

  function addTrack(key, t) {
    if (!t || typeof t.src !== 'string' || !/^data:audio\//.test(t.src) || !t.marks) return
    tracks[key] = t
    for (const [id, m] of Object.entries(t.marks)) if (Array.isArray(m) && m[1] > m[0]) marks.set(id, { key, s: m[0], e: m[1] })
    refresh()
  }
  const playsRecorded = () => !broken && marks.size > 0
  const recordedStatus = () => {
    const names = (recorded && recorded.voices) || []
    return `Voice: Google${names.length ? ` ${names.join(' + ')}` : ''} (recorded)`
  }

  const listeners = []
  function onStatus(fn) { listeners.push(fn); fn(shown()) }
  function shown() {
    if (playsRecorded()) return recordedStatus()
    if (recorded && recorded.note) return `${status} · ${recorded.note}`
    if (broken) return `${status} · this browser would not play the recording`
    return status
  }
  function refresh() { pick(); for (const fn of listeners) fn(shown()) }
  if (wanted) {
    refresh()
    synth.addEventListener ? synth.addEventListener('voiceschanged', refresh) : (synth.onvoiceschanged = refresh)
    // Some browsers fill the list late and never say so.
    setTimeout(() => { if (!chosen[0]) { pick(); if (!chosen[0]) status = 'No voice found: captions only'; for (const fn of listeners) fn(shown()) } }, 1500)
  } else pick()

  function halt(keepPlaying) {
    current++
    clearTimers()
    if (synth && (synth.speaking || synth.pending)) synth.cancel()
    if (audio && !keepPlaying && !audio.paused) audio.pause()
  }
  function stop() { halt(false) }

  /** Plays one line from its recording; false when it cannot, so the line is spoken instead. */
  function playMark(m, rate, token, finish, instead) {
    const t = tracks[m.key]
    if (!t) return false
    if (!audio) {
      try { audio = new Audio() } catch { broken = true; return false }
      audio.preload = 'auto'
    }
    // Carrying straight on from the line before: no seek, so there is no click and no gap.
    const carryOn = loaded === m.key && !audio.paused && Math.abs(audio.currentTime - m.s) < 0.35
    if (loaded !== m.key) { audio.src = t.src; loaded = m.key }
    const seek = () => { try { audio.currentTime = m.s } catch { /* not seekable yet */ } }
    if (!carryOn) {
      if (audio.readyState >= 1) seek()
      else audio.addEventListener('loadedmetadata', seek, { once: true })
    }
    audio.playbackRate = Math.max(0.5, Math.min(2.5, rate))
    if ('preservesPitch' in audio) audio.preservesPitch = true
    const p = audio.play()
    if (p && p.catch) {
      p.catch((err) => {
        if (token !== current) return
        // A phone refuses sound that did not start from a tap, and a play cut short by a pause is
        // "aborted"; neither is the recording's fault. Anything else, it is never tried again.
        if (!(err && (err.name === 'NotAllowedError' || err.name === 'AbortError'))) broken = true
        for (const fn of listeners) fn(shown())
        instead()
      })
    }
    const ends = () => audio.ended || audio.currentTime >= m.e - 0.03
    timers.push(setInterval(() => { if (ends()) finish(true) }, 40))
    // A stalled recording (a slow phone, a broken file) moves on rather than hanging the captions.
    timers.push(setTimeout(() => finish(false), (((m.e - m.s) / audio.playbackRate) * 2 + 5) * 1000))
    return true
  }

  /**
   * Speaks one line, then calls done() once (unless something newer started first). lineId says
   * which recorded line it is, when there is a recording.
   */
  function speak(text, who, rate, done, lineId) {
    const m = lineId && playsRecorded() ? marks.get(lineId) : null
    // When this line carries on in the recording that is already playing, it keeps playing.
    halt(Boolean(m && audio && loaded === m.key && !audio.paused))
    const token = current
    let finished = false
    const finish = (fromRecording) => {
      if (finished || token !== current) return
      finished = true
      clearTimers()
      // Paused a moment later unless the next line carries straight on (the end of a version, a jump).
      if (fromRecording && audio) timers.push(setTimeout(() => { if (token === current && audio && !audio.paused) audio.pause() }, 250))
      done()
    }
    const viaSpeech = () => speakAloud(text, who, rate, token, () => finish(false))
    if (m && playMark(m, rate, token, finish, () => { clearTimers(); viaSpeech() })) return
    viaSpeech()
  }

  function speakAloud(text, who, rate, token, finish) {
    const voice = chosen[who ? 1 : 0]
    const fallback = readSeconds(text) / rate
    if (!wanted || !voice) { timers.push(setTimeout(finish, fallback * 1000)); return }
    const u = new SpeechSynthesisUtterance(spoken(text))
    u.voice = voice
    u.lang = voice.lang
    u.rate = Math.max(0.5, Math.min(2.5, rate))
    u.pitch = pitch[who ? 1 : 0]
    u.onend = finish
    u.onerror = (e) => { if (e && (e.error === 'interrupted' || e.error === 'canceled')) return; finish() }
    // Some browsers never fire "end". Move on when the line has had far longer than it needs.
    timers.push(setTimeout(finish, (fallback * 2.2 + 4) * 1000))
    // Speaking straight after a cancel can be dropped; a short pause avoids that.
    timers.push(setTimeout(() => { if (token === current) synth.speak(u) }, 40))
  }

  function clearTimers() { for (const t of timers) { clearTimeout(t); clearInterval(t) } timers = [] }

  if (recorded) for (const [key, t] of Object.entries(recorded.tracks || {})) addTrack(key, t)

  return { speak, stop, onStatus, addTrack, get active() { return playsRecorded() || (wanted && Boolean(chosen[0])) } }
})()
