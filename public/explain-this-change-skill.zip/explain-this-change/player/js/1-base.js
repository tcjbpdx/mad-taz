// Shared helpers and the presentation itself. The player is plain JavaScript in one closure, joined
// from the numbered files in this folder at build time (see scripts/lib/render.mjs). Nothing here
// loads anything from the network: the page's security policy would refuse it anyway.

const $ = (id) => document.getElementById(id)

/** el('p', { class: 'x', text: 'hi' }, child, …) — text is always set as text, never as HTML. */
function el(tag, attrs, ...kids) {
  const n = document.createElement(tag)
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue
    if (k === 'text') n.textContent = v
    else if (k === 'html') n.innerHTML = v // only ever code the engine highlighted and escaped at build time
    else if (k === 'class') n.className = v
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v)
    else if (k === 'data') for (const [dk, dv] of Object.entries(v)) n.dataset[dk] = dv
    else n.setAttribute(k, v === true ? '' : v)
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) n.append(kid)
  return n
}

const SVG = 'http://www.w3.org/2000/svg'
function svg(tag, attrs, ...kids) {
  const n = document.createElementNS(SVG, tag)
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'text') n.textContent = v
    else if (k === 'class') n.setAttribute('class', v)
    else n.setAttribute(k, v)
  }
  for (const kid of kids.flat()) if (kid) n.append(kid)
  return n
}

const P = JSON.parse($('etc-data').textContent)
let CONFIG = {}
try { CONFIG = JSON.parse($('etc-config').textContent || '{}') || {} } catch { CONFIG = {} }

const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches

/** Browser storage can be missing or refuse (private windows, blocked site data). Never rely on it. */
const store = {
  get(k) { try { return window.localStorage.getItem(k) } catch { return null } },
  set(k, v) { try { window.localStorage.setItem(k, v) } catch { /* fine without it */ } },
}

const KIND_LABEL = {
  answer: 'Your question', overview: 'Overview', change: 'Change', diagram: 'How it connects',
  focus: 'Review focus', reasoning: "Claude's reasoning", proof: 'Proof',
}
const FOCUS_LABEL = {
  risk: 'Risk', edge_case: 'Edge case', behaviour_change: 'Behavior change', tests: 'Tests',
  migration: 'Migration', security: 'Security', performance: 'Performance',
}
// Product mode: a plain-English recap that shows pictures of the app instead of code.
const PRODUCT = P.mode === 'product'
if (PRODUCT) {
  Object.assign(KIND_LABEL, { change: 'What changed', focus: 'What to check', proof: 'What was checked' })
  Object.assign(FOCUS_LABEL, { try_it: 'Try this', looks_different: 'Looks different', watch_out: 'Watch out', not_checked: 'Not checked yet' })
}
const REASON_LABEL = { asked: 'Asked', approach: 'Approach', alternative: 'Alternative considered', tradeoff: 'Trade-off' }
const STATUS_LABEL = { pass: 'Passed', fail: 'Failed', unknown: 'No result', info: 'Note' }

const fileByPath = new Map()
const hunkById = new Map()
function indexData() {
  fileByPath.clear(); hunkById.clear()
  for (const f of P.files || []) fileByPath.set(f.path, f)
  for (const h of P.hunks || []) hunkById.set(h.id, h)
}
indexData()

const speakerName = (who) => (P.speakers && P.speakers[who]) || (who ? 'Second voice' : 'First voice')
const baseName = (p) => String(p || '').split('/').pop()
const dash = '–'
const linesLabel = (from, to) => (to && to !== from ? `lines ${from}${dash}${to}` : `line ${from}`)
const words = (s) => String(s || '').trim().split(/\s+/).filter(Boolean).length

/** Seconds a line takes at normal speed with no voice: a fair reading pace. */
const readSeconds = (say) => Math.max(1.6, words(say) / 2.6)

function lengthLabel(lines) {
  const s = lines.reduce((n, l) => n + readSeconds(l.say) + 0.35, 0)
  if (s < 55) return `~${Math.max(10, Math.round(s / 5) * 5)} s`
  return `~${Math.max(1, Math.round(s / 60))} min`
}

/** Where a chapter's "why" came from, as a short chip label. */
function sourceChip(src) {
  const s = String(src || '')
  if (!s || s === 'none') return { label: 'Intent not stated', none: true }
  if (s === 'pr') return { label: PRODUCT ? 'From the notes with this change' : 'From the pull request' }
  let m = s.match(/^issue:(\d+)$/)
  if (m) return { label: `From issue #${m[1]}` }
  m = s.match(/^commit:([0-9a-f]{4,40})$/i)
  if (m) {
    const c = (P.source.commits || []).find((x) => x.sha.startsWith(m[1]) || x.short === m[1])
    return { label: PRODUCT ? 'From the change history' : `From commit ${m[1].slice(0, 7)}`, title: c ? c.subject : '' }
  }
  if (s === 'session' || s.startsWith('session')) return { label: 'From the Claude Code session' }
  if (s.startsWith('plan')) return { label: 'From the plan notes' }
  const r = (P.reasoning || []).find((x) => x.source === s)
  return { label: r && r.label ? `From ${r.label}` : `From ${s}` }
}

/** The changed lines of a file on one side, from the hunks: after = added lines, before = removed. */
function changedLines(path, side) {
  const set = new Set()
  for (const h of P.hunks || []) {
    if (h.file !== path) continue
    for (const r of h.rows) {
      if (side === 'after' && r.t === 'add') set.add(r.new)
      if (side === 'before' && r.t === 'del') set.add(r.old)
    }
  }
  return set
}

/** A line's text (already highlighted HTML) on one side, or null when the file did not keep it. */
function lineHtml(path, side, n) {
  const f = fileByPath.get(path)
  if (!f) return null
  const arr = side === 'before' ? f.before : f.after
  const v = arr && arr[n - 1]
  return v == null ? null : v
}
