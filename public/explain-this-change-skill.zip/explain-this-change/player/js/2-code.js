// The code view: a hunk as a unified or side-by-side diff, or a window of one file, with the lines
// the narration is talking about lit as a band. Every line's text was highlighted and escaped by the
// engine at build time, so it goes in as HTML; numbers and marks go in as text.

const MARK = { add: '+', del: '−', ctx: ' ' }

function inRange(n, show) { return n != null && n >= show.from && n <= show.to }

function gapRow(text, cols) {
  return el('tr', { class: 'gap' }, el('td', { colspan: String(cols), text }))
}

function hunkHeader(h) {
  const head = `@@ −${h.oldStart},${h.oldLines} +${h.newStart},${h.newLines} @@`
  return h.fn ? `${head}  ${h.fn}()` : head
}

function rowHtml(h, r) {
  const html = r.t === 'del' ? lineHtml(h.file, 'before', r.old) : lineHtml(h.file, 'after', r.new)
  return html == null ? '' : html
}

/** A hunk as one column of old and new numbers, with + and − marks. */
function unifiedHunk(h, show) {
  const t = el('table', { class: 'etc-code' })
  const body = el('tbody')
  body.append(gapRow(hunkHeader(h), 4))
  for (const r of h.rows) {
    const lit = show && (show.side === 'before' ? r.t !== 'add' && inRange(r.old, show) : r.t !== 'del' && inRange(r.new, show))
    body.append(el('tr', { class: [r.t === 'ctx' ? '' : r.t, lit ? 'lit' : ''].filter(Boolean).join(' ') || null },
      el('td', { class: 'no o', text: r.old == null ? '' : String(r.old) }),
      el('td', { class: 'no n', text: r.new == null ? '' : String(r.new) }),
      el('td', { class: 'mk', text: MARK[r.t] || ' ', 'aria-hidden': 'true' }),
      el('td', { class: 'src', html: rowHtml(h, r) })))
  }
  t.append(body)
  return t
}

/** A hunk side by side: removed lines on the left, added on the right, unchanged on both. */
function splitHunk(h, show) {
  // Fixed columns, so a long line on one side wraps instead of pushing the other side out of view.
  const t = el('table', { class: 'etc-code split' },
    el('colgroup', null, el('col', { class: 'c-no' }), el('col', { class: 'c-src' }), el('col', { class: 'c-no' }), el('col', { class: 'c-src' })))
  const body = el('tbody')
  body.append(gapRow(hunkHeader(h), 4))
  const pairs = []
  const rows = h.rows
  for (let i = 0; i < rows.length;) {
    if (rows[i].t === 'ctx') { pairs.push([rows[i], rows[i]]); i++; continue }
    const dels = []; const adds = []
    while (i < rows.length && rows[i].t === 'del') dels.push(rows[i++])
    while (i < rows.length && rows[i].t === 'add') adds.push(rows[i++])
    for (let k = 0; k < Math.max(dels.length, adds.length); k++) pairs.push([dels[k] || null, adds[k] || null])
  }
  for (const [l, r] of pairs) {
    const litL = show && show.side === 'before' && l && inRange(l.old, show)
    const litR = show && show.side === 'after' && r && inRange(r.new, show)
    const tint = (row) => (row && row.t !== 'ctx' ? row.t : '')
    const cls = (base, row, lit) => [base, tint(row), lit ? 'lit-cell' : ''].filter(Boolean).join(' ')
    body.append(el('tr', null,
      el('td', { class: cls('no o', l, litL), text: l ? String(l.old) : '' }),
      el('td', { class: l ? cls('src', l, litL) : 'src empty', html: l ? lineHtml(h.file, 'before', l.old) || '' : '' }),
      el('td', { class: cls('no n half', r, litR), text: r ? String(r.new) : '' }),
      el('td', { class: r ? cls('src', r, litR) : 'src empty', html: r ? lineHtml(h.file, 'after', r.new) || '' : '' })))
  }
  t.append(body)
  return t
}

/** A stretch of one file on one side (or all of it), changed lines tinted, the band lit. */
function fileWindow(path, side, show, whole) {
  const f = fileByPath.get(path)
  const arr = f ? (side === 'before' ? f.before : f.after) : []
  const t = el('table', { class: 'etc-code' })
  const body = el('tbody')
  if (!arr || !arr.length) {
    body.append(gapRow(side === 'before' ? 'This file did not exist before the change.' : 'This file was removed by the change.', 3))
    t.append(body)
    return t
  }
  const changed = changedLines(path, side)
  const pad = 8
  const from = whole ? 1 : Math.max(1, (show ? show.from : 1) - pad)
  const to = whole ? arr.length : Math.min(arr.length, (show ? show.to : 1) + pad)
  if (from > 1) body.append(gapRow(`… ${from - 1} line${from === 2 ? '' : 's'} above`, 3))
  let gap = false
  for (let n = from; n <= to; n++) {
    const html = arr[n - 1]
    if (html == null) { if (!gap) body.append(gapRow('…', 3)); gap = true; continue }
    gap = false
    const ch = changed.has(n)
    const kind = ch ? (side === 'before' ? 'del' : 'add') : ''
    const lit = show && inRange(n, show)
    body.append(el('tr', { class: [kind, lit ? 'lit' : ''].filter(Boolean).join(' ') || null },
      el('td', { class: side === 'before' ? 'no o' : 'no n', text: String(n) }),
      el('td', { class: 'mk', text: ch ? MARK[kind] : ' ', 'aria-hidden': 'true' }),
      el('td', { class: 'src', html })))
  }
  if (to < arr.length) body.append(gapRow(`… ${arr.length - to} line${arr.length - to === 1 ? '' : 's'} below`, 3))
  t.append(body)
  return t
}

/** The table for a code show, in the chosen view. */
function codeTable(show, view, whole) {
  const h = show.hunk ? hunkById.get(show.hunk) : null
  let t
  if (h && !whole) t = view === 'split' ? splitHunk(h, show) : unifiedHunk(h, show)
  else t = fileWindow(show.file || (h && h.file), show.side, show, whole)
  if (t.querySelector('tr.lit, td.lit-cell')) t.classList.add('has-lit')
  // Short views get slightly bigger type, fixed for the whole view so nothing jumps between lines.
  t.style.setProperty('--code-scale', t.rows.length <= 14 ? '1.12' : '1')
  return t
}

/** Moves the band to the middle of the scroller (or its top, when the band is taller than the view). */
function scrollToBand(scroller, smooth) {
  const lit = scroller.querySelectorAll('tr.lit, td.lit-cell')
  if (!lit.length) { scroller.scrollTo({ top: 0, left: 0 }); return }
  const first = lit[0].closest('tr'); const last = lit[lit.length - 1].closest('tr')
  const box = scroller.getBoundingClientRect()
  const top = first.getBoundingClientRect().top - box.top + scroller.scrollTop
  const bottom = last.getBoundingClientRect().bottom - box.top + scroller.scrollTop
  const room = scroller.clientHeight
  const band = bottom - top
  const target = band > room - 24 ? top - 12 : top - (room - band) / 2
  scroller.scrollTo({ top: Math.max(0, Math.round(target)), left: 0, behavior: smooth && !reducedMotion() ? 'smooth' : 'auto' })
}

/** Moves only the lit rows of a table already on screen (same hunk, same side, same view). */
function relight(table, show) {
  const split = table.classList.contains('split')
  for (const td of table.querySelectorAll('td.lit-cell')) td.classList.remove('lit-cell')
  for (const tr of table.querySelectorAll('tr.lit')) tr.classList.remove('lit')
  for (const tr of table.rows) {
    if (tr.classList.contains('gap')) continue
    if (split) {
      const cells = show.side === 'before' ? [tr.cells[0], tr.cells[1]] : [tr.cells[2], tr.cells[3]]
      const n = Number(cells[0].textContent)
      if (cells[0].textContent && inRange(n, show)) for (const c of cells) c.classList.add('lit-cell')
    } else {
      const no = tr.querySelector(show.side === 'before' ? 'td.no.o' : 'td.no.n')
      const isAdd = tr.classList.contains('add'); const isDel = tr.classList.contains('del')
      const wrongSide = show.side === 'before' ? isAdd : isDel
      if (no && no.textContent && !wrongSide && inRange(Number(no.textContent), show)) tr.classList.add('lit')
    }
  }
  table.classList.toggle('has-lit', Boolean(table.querySelector('tr.lit, td.lit-cell')))
}

/** The bar above the view: file, function, side and lines, and the view switches for code. */
function whereBar(show, chapter, opts) {
  const bar = $('etc-where')
  bar.replaceChildren()
  if (show && show.type === 'picture') {
    const pic = (P.pictures || [])[show.item]
    bar.append(el('span', { class: 'etc-tag', text: 'Picture' }))
    if (pic) bar.append(el('span', { class: 'etc-path', title: pic.page, text: pic.label }), el('span', { class: 'etc-fn', text: pic.page }))
    return
  }
  if (!show || show.type !== 'code') {
    bar.append(el('span', { class: 'etc-tag', text: KIND_LABEL[chapter.kind] || chapter.kind }))
    const n = chapter.kind === 'focus' ? (P.focus || []).length
      : chapter.kind === 'reasoning' ? (P.reasoning || []).length
        : chapter.kind === 'proof' ? ((P.proof && P.proof.items) || []).length
          : chapter.kind === 'overview' ? (PRODUCT ? (P.pictures || []).filter(Boolean) : P.files || []).length : 0
    const unit = chapter.kind === 'overview' ? (PRODUCT ? 'picture' : 'file') : chapter.kind === 'proof' ? 'check' : 'point'
    if (n) bar.append(el('span', { class: 'etc-count', text: `${n} ${unit}${n === 1 ? '' : 's'}` }))
    return
  }
  const f = fileByPath.get(show.file)
  const path = show.side === 'before' && f && f.oldPath ? f.oldPath : show.file
  const dir = path.includes('/') ? path.slice(0, path.lastIndexOf('/') + 1) : ''
  bar.append(el('span', { class: 'etc-path', title: path }, dir ? el('span', { class: 'from', text: dir }) : null, baseName(path)))
  if (show.fn) bar.append(el('span', { class: 'etc-fn' }, el('b', { text: show.fn }), '()'))
  bar.append(el('span', { class: `etc-tag ${show.side}`, data: { side: show.side }, text: show.side === 'before' ? 'Before' : 'After' }))
  bar.append(el('span', { class: 'etc-fn', text: linesLabel(show.from, show.to) }))
  bar.append(el('span', { class: 'spacer' }))
  if (show.hunk && !opts.whole) {
    bar.append(el('span', { class: 'etc-seg', role: 'group', 'aria-label': 'Diff view' },
      el('button', { type: 'button', 'aria-pressed': String(opts.view === 'unified'), onclick: () => opts.onView('unified'), text: 'Unified' }),
      el('button', { type: 'button', 'aria-pressed': String(opts.view === 'split'), onclick: () => opts.onView('split'), text: 'Split' })))
  }
  if (f && (f.before.length || f.after.length)) {
    bar.append(el('button', { type: 'button', class: 'etc-btn', 'aria-pressed': String(Boolean(opts.whole)), onclick: () => opts.onWhole(!opts.whole), text: 'Whole file' }))
  }
}
