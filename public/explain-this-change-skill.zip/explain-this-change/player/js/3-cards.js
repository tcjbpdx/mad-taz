// Cards (what a line shows when it is not code) and the flow diagram.

function chip(src) {
  const c = sourceChip(src)
  return el('span', { class: c.none ? 'etc-src none' : 'etc-src', title: c.title || null, text: c.label })
}

function fileList() {
  const byFile = new Map()
  for (const h of P.hunks || []) {
    const n = byFile.get(h.file) || { add: 0, del: 0 }
    for (const r of h.rows) { if (r.t === 'add') n.add++; if (r.t === 'del') n.del++ }
    byFile.set(h.file, n)
  }
  return el('ul', { class: 'etc-files' }, [...byFile].map(([path, n]) => {
    const f = fileByPath.get(path)
    const st = f && f.status && !['modified', 'unchanged'].includes(f.status) ? f.status : ''
    return el('li', null, el('span', { class: 'p', text: `+${n.add}` }), el('span', { class: 'm', text: `−${n.del}` }),
      el('span', { text: path }), st ? el('span', { class: 'st', text: st }) : null)
  }))
}

/** Product mode's overview: a small picture of each page the recap shows. */
function pictureThumbs() {
  const pics = (P.pictures || []).filter(Boolean)
  if (!pics.length) return el('p', { class: 'etc-notice', text: 'No pictures of the app were taken for this recap.' })
  return el('ul', { class: 'etc-thumbs' }, pics.map((p) => el('li', null,
    el('img', { src: p.src, alt: '', width: p.width, height: p.height, decoding: 'async', loading: 'lazy' }),
    el('span', { text: p.label }))))
}

/**
 * A picture of the app, with a ring around the words a line points at. The ring is placed in
 * percentages of the picture, so it stays on its words at any size. Without words, no ring.
 */
function pictureView(pic, point) {
  const ring = el('div', { class: 'etc-ring', 'aria-hidden': 'true' })
  const frame = el('div', { class: 'frame' }, el('img', { src: pic.src, alt: `${pic.label}, the page at ${pic.page}`, width: pic.width, height: pic.height, decoding: 'async' }), ring)
  frame.style.maxWidth = `${pic.width}px`
  const fig = el('figure', { class: 'etc-pic' }, frame, el('figcaption', { text: pic.label }))
  placeRing(fig, pic, point)
  return fig
}

function placeRing(fig, pic, point) {
  const ring = fig.querySelector('.etc-ring')
  const b = point && pic.boxes ? pic.boxes[point] : null
  ring.hidden = !b
  if (!b) return
  const pad = 6
  const pct = (v, of) => `${(v / of) * 100}%`
  ring.style.left = pct(b.x - pad, pic.width)
  ring.style.top = pct(b.y - pad, pic.height)
  ring.style.width = pct(b.w + pad * 2, pic.width)
  ring.style.height = pct(b.h + pad * 2, pic.height)
}

function locLabel(it) {
  const f = it.file || (it.hunk && hunkById.get(it.hunk) && hunkById.get(it.hunk).file) || ''
  return `${baseName(f)}:${it.to && it.to !== it.from ? `${it.from}${dash}${it.to}` : it.from}`
}

/** One review-focus item. onLoc (optional) peeks at its code. */
function focusItem(it, i, on, onLoc) {
  return el('li', { class: on ? 'etc-item on' : 'etc-item', data: { i: String(i) } },
    el('header', null,
      el('span', { class: `etc-sev ${it.severity}`, text: it.severity }),
      el('span', { class: 'etc-kind', text: FOCUS_LABEL[it.kind] || it.kind }),
      !it.general && onLoc ? el('button', { type: 'button', class: 'etc-loc', onclick: () => onLoc(it), text: locLabel(it), title: 'Show this code' }) : null,
      PRODUCT && onLoc && it.picture >= 0 && (P.pictures || [])[it.picture] ? el('button', { type: 'button', class: 'etc-loc', onclick: () => onLoc(it), text: P.pictures[it.picture].label, title: 'Show this picture' }) : null),
    el('p', { text: it.text }))
}

function reasoningItem(r, i, on) {
  return el('li', { class: on ? 'etc-item on' : 'etc-item', data: { i: String(i) } },
    el('header', null, el('span', { class: 'etc-kind', text: REASON_LABEL[r.kind] || r.kind }),
      el('span', { class: 'etc-src', text: r.label ? `From ${r.label}` : 'Source not named' })),
    el('p', { text: r.text }),
    r.quote ? el('blockquote', { text: r.quote }) : null)
}

function proofTable(item) {
  const items = (P.proof && P.proof.items) || []
  if (!items.length) return el('p', { class: 'etc-notice', text: 'No evidence was gathered, so nothing here says the change works or passes its tests.' })
  return el('table', { class: 'etc-proof' },
    el('thead', null, el('tr', null, el('th', { text: 'Check' }), el('th', { text: 'Result' }), el('th', { text: 'Evidence' }))),
    el('tbody', null, items.map((p, i) => el('tr', { class: i === item ? 'lit' : null, data: { i: String(i) } },
      el('td', { text: p.label }),
      el('td', null, el('span', { class: `etc-status ${p.status}`, text: STATUS_LABEL[p.status] || p.status })),
      el('td', { text: p.detail || '' })))))
}

/** The card for a chapter (an answer, the overview, a change, the focus list, reasoning or proof). */
function chapterCard(chapter, item, onLoc) {
  const card = el('div', { class: 'etc-card' })
  // Like card.append, but a missing piece (null) is left out instead of printed as "null".
  const add = (...kids) => { for (const k of kids.flat()) if (k != null && k !== false) card.append(k) }
  const kind = KIND_LABEL[chapter.kind] || chapter.kind
  // The small label above the title, unless it would just repeat the title.
  const eyebrow = String(chapter.title || '').trim().toLowerCase() === kind.toLowerCase() ? null : el('p', { class: 'eyebrow', text: kind })
  const title = el('h3', { text: chapter.title })
  switch (chapter.kind) {
    case 'answer': {
      const q = chapter.question || (P.scope && P.scope.question) || ''
      add(eyebrow, q ? el('p', { class: 'question', text: q }) : null, title)
      break
    }
    case 'overview':
      add(eyebrow, el('h3', { text: P.title }), el('p', { text: P.summary }), PRODUCT ? pictureThumbs() : fileList())
      break
    case 'change':
      add(eyebrow, title, el('dl', { class: 'etc-grid' },
        el('dt', { text: 'Before' }), el('dd', { text: chapter.before || '' }),
        el('dt', { text: 'After' }), el('dd', { text: chapter.after || '' }),
        el('dt', { text: 'Why' }), el('dd', null, chapter.why_source === 'none' ? '' : (chapter.why || ''), chip(chapter.why_source)),
        PRODUCT ? null : [el('dt', { text: 'Affects' }), el('dd', { text: chapter.affects || '' })]))
      break
    case 'focus':
      add(eyebrow, title, el('ol', { class: 'etc-items' }, (P.focus || []).map((it, i) => focusItem(it, i, i === item, onLoc))))
      break
    case 'reasoning':
      add(eyebrow, title, el('ol', { class: 'etc-items' }, (P.reasoning || []).map((r, i) => reasoningItem(r, i, i === item))))
      break
    case 'proof':
      add(eyebrow, title, chapter.summary ? el('p', { text: chapter.summary }) : null, proofTable(item))
      break
    default:
      add(eyebrow, title)
  }
  return card
}

// ---- diagram ----

const fnOf = (label) => String(label || '').replace(/\(.*$/, '').trim()

/** Lays the nodes out left to right by longest path, and draws curved, labelled edges. */
function diagramSvg(chapter, show) {
  const nodes = chapter.nodes || []
  const edges = (chapter.edges || []).filter((e) => nodes.some((n) => n.id === e.from) && nodes.some((n) => n.id === e.to))
  const level = new Map(nodes.map((n) => [n.id, 0]))
  for (let pass = 0; pass < nodes.length; pass++) {
    let moved = false
    for (const e of edges) {
      const want = level.get(e.from) + 1
      if (want > level.get(e.to) && want < nodes.length) { level.set(e.to, want); moved = true }
    }
    if (!moved) break
  }
  const cols = []
  for (const n of nodes) { const l = level.get(n.id); (cols[l] = cols[l] || []).push(n) }
  const size = (n) => ({ w: Math.max(n.label.length * 8.3, baseName(n.file).length * 6.8, 90) + 28, h: n.file ? 50 : 36 })
  const GAPX = 78; const GAPY = 22; const PAD = 20
  const pos = new Map()
  let x = PAD
  const colH = cols.map((c) => (c || []).reduce((s, n) => s + size(n).h, 0) + GAPY * Math.max(0, (c || []).length - 1))
  const H = Math.max(...colH, 60) + PAD * 2 + 40
  for (const c of cols) {
    if (!c) continue
    const w = Math.max(...c.map((n) => size(n).w))
    const total = c.reduce((s, n) => s + size(n).h, 0) + GAPY * (c.length - 1)
    let y = (H - 40 - total) / 2
    for (const n of c) { const s = size(n); pos.set(n.id, { x: x + (w - s.w) / 2, y, w: s.w, h: s.h }); y += s.h + GAPY }
    x += w + GAPX
  }
  const W = x - GAPX + PAD
  const mid = `etc-arrow-${Math.random().toString(36).slice(2, 8)}`
  const changedFiles = new Set((P.hunks || []).map((h) => h.file))
  const root = svg('svg', { class: 'etc-diagram', viewBox: `0 0 ${Math.ceil(W)} ${Math.ceil(H)}`, role: 'img', 'aria-label': `Diagram: ${chapter.title}`, preserveAspectRatio: 'xMidYMid meet' },
    svg('defs', null, svg('marker', { id: mid, viewBox: '0 0 10 10', refX: '9', refY: '5', markerWidth: '7', markerHeight: '7', orient: 'auto-start-reverse' }, svg('path', { d: 'M0 0L10 5L0 10z' }))))
  for (const e of edges) {
    const a = pos.get(e.from); const b = pos.get(e.to)
    let d; let lx; let ly
    if (level.get(e.to) > level.get(e.from)) {
      const x1 = a.x + a.w; const y1 = a.y + a.h / 2; const x2 = b.x - 2; const y2 = b.y + b.h / 2; const k = (x2 - x1) / 2
      d = `M${x1} ${y1} C${x1 + k} ${y1} ${x2 - k} ${y2} ${x2} ${y2}`
      lx = (x1 + x2) / 2; ly = (y1 + y2) / 2 - 6
    } else {
      const x1 = a.x + a.w / 2; const y1 = a.y + a.h; const x2 = b.x + b.w / 2; const y2 = b.y + b.h + 2; const drop = 34
      d = `M${x1} ${y1} C${x1} ${y1 + drop} ${x2} ${y2 + drop} ${x2} ${y2}`
      lx = (x1 + x2) / 2; ly = Math.max(y1, y2) + drop * 0.75 + 4
    }
    root.append(svg('g', { class: 'edge' }, svg('path', { d, 'marker-end': `url(#${mid})` }),
      e.label ? svg('text', { x: String(lx), y: String(ly), 'text-anchor': 'middle', text: e.label }) : null))
  }
  for (const n of nodes) {
    const p = pos.get(n.id)
    const on = show && show.type === 'code' && show.fn && fnOf(n.label) === show.fn && (!n.file || n.file === show.file)
    const cls = ['node', changedFiles.has(n.file) ? 'changed' : '', on ? 'on' : ''].filter(Boolean).join(' ')
    root.append(svg('g', { class: cls },
      svg('rect', { x: String(p.x), y: String(p.y), width: String(p.w), height: String(p.h), rx: '9' }),
      svg('text', { x: String(p.x + p.w / 2), y: String(p.y + (n.file ? 21 : 23)), 'text-anchor': 'middle', text: n.label }),
      n.file ? svg('text', { class: 'file', x: String(p.x + p.w / 2), y: String(p.y + 38), 'text-anchor': 'middle', text: baseName(n.file) }) : null))
  }
  return root
}
